// ===== Progresso salvo (mini banco de dados no navegador) =====
// O jogo é salvo no marco de descanso (menu do banco: Salvar / Salvar e sair) e o "Continuar" da tela de início
// volta para o último marco salvo, com moedas, espadas, habilidades, diário, épocas visitadas e trechos vencidos.
// Guarda no IndexedDB (um banco de dados do próprio navegador). Se ele não existir ou falhar, usa o localStorage;
// e se nem isso der (aba anônima bloqueada), vale até fechar a página.
// Nas Crônicas do Fim, morrer apaga o jogo salvo daquele modo.

// o nome do banco e da reserva levam a identidade do arquivo: cada cópia do jogo tem o seu próprio jogo salvo (config.js)
const BANCO = { nome: chaveLocal('reliquias_das_eras'), antigo: 'reliquias_das_eras', loja: 'progresso', chave: 'jogo', reserva: chaveLocal('reliquias_salvo') };
let SALVO = null;            // resumo do jogo salvo (ou null); undefined enquanto ainda está lendo
let SALVO_MEMORIA = null;    // último recurso, se o navegador não deixar guardar nada

function abrirBancoDados(nome) {
  return new Promise((ok, erro) => {
    try {
      if (typeof indexedDB == 'undefined' || !indexedDB) return erro(new Error('sem IndexedDB'));
      const r = indexedDB.open(nome || BANCO.nome, 1);
      r.onupgradeneeded = () => { const db = r.result; if (!db.objectStoreNames.contains(BANCO.loja)) db.createObjectStore(BANCO.loja); };
      r.onsuccess = () => ok(r.result); r.onerror = () => erro(r.error || new Error('IndexedDB')); r.onblocked = () => erro(new Error('bloqueado'));
    } catch (e) { erro(e); }
  });
}
function operacao(modo, fazer, nome) {
  return abrirBancoDados(nome).then(db => new Promise((ok, erro) => {
    const tx = db.transaction(BANCO.loja, modo), loja = tx.objectStore(BANCO.loja); let res;
    const r = fazer(loja); if (r) r.onsuccess = () => { res = r.result; };
    tx.oncomplete = () => { db.close(); ok(res); }; tx.onerror = tx.onabort = () => { db.close(); erro(tx.error); };
  }));
}
function lerReserva() { try { const s = localStorage.getItem(BANCO.reserva); if (s) return JSON.parse(s); } catch (_) { } return SALVO_MEMORIA; }
function gravarReserva(d) { SALVO_MEMORIA = d; try { if (d) localStorage.setItem(BANCO.reserva, JSON.stringify(d)); else localStorage.removeItem(BANCO.reserva); } catch (_) { } }

function lerSalvo() {
  return operacao('readonly', l => l.get(BANCO.chave)).then(d => d || lerReserva(), () => lerReserva())
    .then(d => { SALVO = d && d.v ? d : null; return SALVO; });
}
function gravarSalvo(d) {
  SALVO = d;
  return operacao('readwrite', l => l.put(d, BANCO.chave)).then(() => { gravarReserva(null); SALVO_MEMORIA = d; }, () => gravarReserva(d)).then(() => d);
}
function apagarSalvo() {
  SALVO = null; gravarReserva(null); SALVO_MEMORIA = null;
  return operacao('readwrite', l => l.delete(BANCO.chave)).catch(() => { });
}

// ---------------- o que vai para o banco ----------------
const copia = o => JSON.parse(JSON.stringify(o == null ? null : o));
function estadoDoJogo() {
  const ri = G.bench.ri;
  return {
    v: 1, quando: Date.now(), tempo: Math.round(G.tempoJogo || 0), ri, era: ERAS[ri].n, cronicas: !!G.cronicas,
    coins: G.coins, runes: G.runes, vis: copia(G.vis), RS: copia(G.RS), mortos: copia(G.mortos), diario: G.diario ? 1 : 0,
    echo: copia(G.echo), dicaLoja: G.dicaLoja ? 1 : 0,
    p: { mhp: p.mhp, wp: p.wp, ab: copia(p.ab), soul: Math.round(p.soul) }
  };
}
function aplicarSalvo(s) {
  MODO_CRONICAS = !!s.cronicas; newGame();
  G.cronicas = !!s.cronicas; G.coins = s.coins | 0; G.runes = s.runes | 0; G.vis = s.vis || {}; G.RS = s.RS || {};
  G.mortos = s.mortos || {}; G.diario = s.diario ? 1 : 0; G.echo = s.echo || null; G.dicaLoja = s.dicaLoja ? 1 : 0;
  G.tempoJogo = s.tempo || 0; G.bench.ri = s.ri | 0;
  if (s.p) { p.mhp = s.p.mhp || 5; p.wp = clamp(s.p.wp | 0, 0, SW.length - 1); Object.assign(p.ab, s.p.ab || {}); p.soul = s.p.soul || 0; }
  p.hp = p.mhp;
  ROOMS.length = 0;
  G.mode = 'trans'; G.fade = 1; G.fdir = -1; enterRoom(G.bench.ri, 'bench');
}

// ---------------- ícone de salvar/carregar (cristal girando no canto) ----------------
let ICONE = null;            // fica fora de G: continua aparecendo quando o jogo carregado substitui o G
function mostrarIcone(texto, depois) { ICONE = { t: 0, texto, fim: null, depois }; }
function iconePronto(texto) { if (ICONE) { ICONE.fim = ICONE.t; ICONE.textoFim = texto; } }
function atualizarIcone(dt) {
  const I = ICONE; if (!I) return;
  I.t += dt;
  if (I.fim != null && I.t > Math.max(I.fim, 1.1) + .9) { ICONE = null; if (I.depois) I.depois(); }
}
function desenharIcone() {
  const I = ICONE; if (!I) return;
  const H = INTERFACE && INTERFACE.hud && INTERFACE.hud.cristal, im = H && imgInterface(H.arquivo);
  const pronto = I.fim != null && I.t > Math.max(I.fim, 1.1), sai = pronto ? clamp((I.t - Math.max(I.fim, 1.1)) / .9, 0, 1) : 0;
  const x = VW - 70, y = VH - 64, a = clamp(I.t * 4, 0, 1) * (1 - Math.max(0, sai - .5) * 2);
  g.save(); g.globalAlpha = a;
  glow(45, x, y, 46, .25 + .08 * Math.sin(G.time * 6), 60);
  if (im) {
    const [w, h] = H.quadro, an = pronto ? H.parado : H.gira, q = an[0] + Math.floor(I.t * H.fps) % an[1], esc = .62;
    g.imageSmoothingEnabled = false; g.drawImage(im, q * w, 0, w, h, Math.round(x - w * esc / 2), Math.round(y - h * esc * .55), Math.round(w * esc), Math.round(h * esc));
  } else { g.fillStyle = '#ffd36e'; g.beginPath(); g.arc(x, y, 12, 0, 7); g.fill(); }
  textoPixel(pronto ? (I.textoFim || I.texto) : I.texto, x - 44, y + 14, 2, '#f4f1e6', 'right', true);
  g.restore();
}

// ---------------- ações do menu ----------------
function salvarJogo(depois) {
  if (ICONE) return;
  mostrarIcone('Salvando...', depois);
  gravarSalvo(estadoDoJogo()).then(() => iconePronto('Jogo salvo'), () => iconePronto('Salvo só nesta aba'));
}
function continuarJogo() {
  if (!SALVO || ICONE) return;
  const s = SALVO; mostrarIcone('Carregando...', () => { });
  setTimeoutSeguro(() => { aplicarSalvo(s); iconePronto('Pronto'); }, 700);
}
// setTimeout que também funciona nos testes (Node): o jogo checa a fila a cada quadro
const ESPERAS = [];
function setTimeoutSeguro(f, ms) { ESPERAS.push({ f, t: ms / 1000 }); }
function atualizarEsperas(dt) { for (let i = ESPERAS.length - 1; i >= 0; i--) { ESPERAS[i].t -= dt; if (ESPERAS[i].t <= 0) { const e = ESPERAS.splice(i, 1)[0]; e.f(); } } }

// jogo salvo de antes da separação por cópia (banco sem a identidade do arquivo): passa para esta cópia se ela ainda
// não tiver um, e sai do banco antigo — assim só a primeira cópia que abrir fica com ele
function migrarBancoAntigo() {
  return operacao('readonly', l => l.get(BANCO.chave), BANCO.antigo).then(antigo => {
    if (!antigo) return;
    return operacao('readonly', l => l.get(BANCO.chave)).then(atual => atual ? null : operacao('readwrite', l => l.put(antigo, BANCO.chave)))
      .then(() => operacao('readwrite', l => l.delete(BANCO.chave), BANCO.antigo));
  }).catch(() => { });
}
migrarBancoAntigo().then(lerSalvo).catch(() => { SALVO = null; });
