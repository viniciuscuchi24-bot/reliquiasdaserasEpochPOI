// ===== Cenário =====
// Desenha terreno, plataformas, objetos, fundo e camadas usando o estilo atual.
// Nada aqui tem arte própria: tudo vem de assets/estilos/<estilo>/estilo.js e das imagens da pasta.
let EST = null;   // estilo atual

function escolherEstilo(id) {
  EST = ESTILOS[id] || ESTILOS[ORDEM_ESTILOS[0]];
  for (const k in EST.imagens) carregarImagem(EST.pasta + EST.imagens[k]);
  if (CONFIG.lembrarEstilo) { try { localStorage.setItem(chaveLocal('eras_estilo'), EST.id); } catch (_) {} }
  if (typeof G != 'undefined' && G && G.rm) { sortearObjetos(G.rm); carregarImagem(caminhoFundo(G.rm.i)); }
}

function trocarEstilo() {
  const i = ORDEM_ESTILOS.indexOf(EST.id);
  escolherEstilo(ORDEM_ESTILOS[(i + 1) % ORDEM_ESTILOS.length]);
  if (typeof toast == 'function') toast('Estilo: ' + EST.nome, 2.4);
}

(function estiloInicial() {
  let id = CONFIG.estiloInicial;
  try { const m = /[?&#]estilo=(\w+)/.exec(location.href); if (m) id = m[1]; else if (CONFIG.lembrarEstilo) id = localStorage.getItem(chaveLocal('eras_estilo')) || id; } catch (_) {}
  escolherEstilo(ESTILOS[id] ? id : CONFIG.estiloInicial);
})();
if (typeof window != 'undefined') window.trocarEstilo = trocarEstilo;

// ---------- utilidades de desenho (pixel art: sem suavizar) ----------
function imgE(apelido) {
  const im = carregarImagem(EST.pasta + EST.imagens[apelido]);
  return imagemPronta(im) ? im : null;
}

// desenha o recorte r=[x,y,l,a] da imagem 'apelido' em (x,y) com escala esc
function recorte(apelido, r, x, y, esc, virarX, virarY, largDestino) {
  const im = imgE(apelido); if (!im) return false;
  const dw = largDestino == null ? r[2] * esc : largDestino, dh = r[3] * esc;
  x = Math.round(x); y = Math.round(y);
  g.imageSmoothingEnabled = false;
  if (virarX || virarY) {
    g.save(); g.translate(x + (virarX ? dw : 0), y + (virarY ? dh : 0)); g.scale(virarX ? -1 : 1, virarY ? -1 : 1);
    g.drawImage(im, r[0], r[1], r[2], r[3], 0, 0, Math.round(dw), Math.round(dh)); g.restore();
  } else g.drawImage(im, r[0], r[1], r[2], r[3], x, y, Math.round(dw), Math.round(dh));
  return true;
}

// repete um recorte na horizontal ocupando a largura w
function faixa(apelido, r, x, y, w, esc, virarY) {
  const tw = r[2] * esc;
  for (let tx = 0; tx < w; tx += tw) {
    const dw = Math.min(tw, w - tx), sw = Math.max(1, Math.round(r[2] * dw / tw));
    recorte(apelido, [r[0], r[1], sw, r[3]], x + tx, y, esc, false, virarY, dw + (tx + dw < w ? 1 : 0));
  }
}

// ---------- terreno ----------
// Maciço de terra/pedra: recheio + faixa de cima (topo) + laterais repetidas na vertical
// nas beiradas dos fossos e nas torres + quinas opcionais + borda de baixo (blocos suspensos).
// cfg = EST.chao (chão) ou EST.bloco (torres e blocos; se o estilo não tiver, usa o chão).
function desenharMacico(cfg, x, y, w, h, semente, esq, dir, baixo, semTopo) {
  const c = cfg, e = c.escala, sb = c.subir || 0, ov = c.sobra == null ? 6 : c.sobra;
  x = Math.round(x); y = Math.round(y);
  g.fillStyle = c.recheio; g.fillRect(x, y, w, h);
  g.save(); g.beginPath(); g.rect(x - ov - 2, y - sb - 48, w + 2 * ov + 4, h + sb + 48); g.clip();
  const n0 = Math.floor(semente), xa = x - (esq ? ov : 0), xb = x + w + (dir ? ov : 0);
  // faixa de cima
  if (!semTopo) {
    const tw = c.topo[0][2] * e;
    for (let tx = xa, k = 0; tx < xb; tx += tw, k++) {
      const t = c.topo[(n0 + k) % c.topo.length], dw = Math.min(tw, xb - tx);
      recorte(c.img, [t[0], t[1], Math.max(1, Math.round(t[2] * dw / tw)), t[3]], tx, y - sb, e, false, false, dw + (tx + dw < xb ? 1 : 0));
    }
  }
  // laterais (paredes de pedra/tijolo) repetidas na vertical
  let lw = esq && c.ladoEsq ? c.ladoEsq[0][2] * e : 0, rw = dir && c.ladoDir ? c.ladoDir[0][2] * e : 0;
  if (lw + rw > xb - xa) { const k = (xb - xa) / (lw + rw); lw = Math.floor(lw * k / e) * e; rw = Math.floor(rw * k / e) * e; }
  const ini = semTopo ? y : y - sb + (c.ladoInicio || 0), iE = n0 % (c.ladoEsq || [0]).length, iD = (n0 + 1) % (c.ladoDir || [0]).length;
  const lado = (t, xx, lw2, daDireita) => { for (let ty = ini; ty < y + h; ty += t[3] * e) recorte(c.img, [daDireita ? t[0] + t[2] - lw2 / e : t[0], t[1], lw2 / e, t[3]], xx, ty, e); };
  if (lw) lado(c.ladoEsq[iE], xa, lw, false);
  if (rw) lado(c.ladoDir[iD], xb - rw, rw, true);
  // quinas (opcional: lajes de pedra nas beiradas)
  if (!semTopo) {
    const ps = c.pontaSubir == null ? sb : c.pontaSubir;
    if (esq && c.pontaEsq) { const t = c.pontaEsq[0], pw = Math.min(t[2], Math.floor((xb - xa) / 2 / e)); recorte(c.img, [t[0], t[1], pw, t[3]], xa, y - ps, e); }
    if (dir && c.pontaDir) { const t = c.pontaDir[0], pw = Math.min(t[2], Math.floor((xb - xa) / 2 / e)); recorte(c.img, [t[0] + t[2] - pw, t[1], pw, t[3]], xb - pw * e, y - ps, e); }
  }
  g.restore();
  if (baixo && EST.teto.borda) { const t = EST.teto, bh = t.borda[3] * t.escala; faixa(t.img, t.borda, x - 2, y + h - bh + 4, w + 4, t.escala, !!t.virarBorda); }
}

function desenharChao(x, y, w, h, semente, esq, dir) { desenharMacico(EST.chao, x, y, w, h, semente, esq, dir, false); }
function desenharBloco(x, y, w, h, semente, suspenso) { desenharMacico(EST.bloco || EST.chao, x, y, w, h, semente, true, true, suspenso); }
function desenharPendurado(x, y, w, h, semente) {   // bloco preso no teto
  const c = EST.bloco || EST.chao;
  desenharMacico(c, x, y, w, h, semente, true, true, true, true);
}

function desenharTeto(x, y, w, h) {
  const c = EST.teto;
  g.fillStyle = c.recheio; g.fillRect(x, y, w, h);
  const bh = c.borda ? c.borda[3] * c.escala : 0;
  if (c.tijolo) {
    g.save(); g.beginPath(); g.rect(x, y, w, h - bh + 2); g.clip();
    for (let ty = y - 4; ty < y + h - bh; ty += c.tijolo[3] * c.escala) faixa(c.img, c.tijolo, x, ty, w, c.escala, false);
    g.restore();
  }
  if (c.borda) faixa(c.img, c.borda, x, y + h - bh + 2, w, c.escala, !!c.virarBorda);
}

function desenharPlataforma(x, y, w, h) {
  const c = EST.plataforma, e = c.escala, s = c.sobra == null ? 4 : c.sobra, yy = y - (c.subir || 0);
  const le = c.esquerda[2] * e, ld = c.direita[2] * e;
  recorte(c.img, c.esquerda, x - s, yy, e);
  recorte(c.img, c.direita, x + w + s - ld, yy, e);
  const meioW = w + 2 * s - le - ld;
  if (meioW > 0) faixa(c.img, c.meio, x - s + le, yy, meioW, e, false);
}

// ---------- objetos do jogo em pixel art (assets/objetos: runas, fragmentos, alavancas, portões...) ----------
// desenha o recorte 'nome' de objetos.png centralizado em cx, com a base em 'base'
function obj(nome, cx, base, esc, virarX, virarY) {
  if (typeof OBJETOS == 'undefined') return false;
  const r = OBJETOS.r[nome]; if (!r) return false;
  const im = carregarImagem(OBJETOS.imagem); if (!imagemPronta(im)) return false;
  esc = esc || OBJETOS.escala;
  const w = Math.round(r[2] * esc), h = Math.round(r[3] * esc), x = Math.round(cx - w / 2), y = Math.round(base - h);
  g.imageSmoothingEnabled = false;
  if (virarX || virarY) { g.save(); g.translate(x + (virarX ? w : 0), y + (virarY ? h : 0)); g.scale(virarX ? -1 : 1, virarY ? -1 : 1); g.drawImage(im, r[0], r[1], r[2], r[3], 0, 0, w, h); g.restore(); }
  else g.drawImage(im, r[0], r[1], r[2], r[3], x, y, w, h);
  return true;
}
const balanco = (v, amp) => Math.round(Math.sin(G.time * 2.2 + v) * amp / 2) * 2;   // sobe e desce de 2 em 2 px

// ---------- objetos do chão ----------
function sortearObjetos(R) {
  R.dec = R.dec || {};
  const rnd = mul(R.i * 977 + 13 + EST.id.length * 31), lista = Object.entries(EST.objetos);
  const tot = lista.reduce((a, o) => a + (o[1].peso || 1), 0), out = [];
  const ex = R.excl.slice();   // lugares livres (runa, marco, portões, alavancas...) definidos em fases.js
  R.secs.forEach(s => { if (s.mech) ex.push(s.mech.x); (s.alvos || []).forEach(o => ex.push(o.x)); });
  for (const sg of R.segs) {
    let x = sg[0] * T + 22 + rnd() * 40; const xe = (sg[0] + sg[1]) * T - 26;
    while (x < xe) {
      if (ex.some(e => Math.abs(e - x) < 44) || R.secs.some(s => s.casco && x > s.casco[0] * T - 40 && x < s.casco[1] * T + 20)) { x += 60; continue; }
      if (rnd() < .75) {
        let r = rnd() * tot, pick = lista[0];
        for (const o of lista) { if (r < (o[1].peso || 1)) { pick = o; break; } r -= (o[1].peso || 1); }
        out.push({ n: pick[0], x, s: .85 + rnd() * .3, v: rnd(), z: rnd() < .3 ? 1 : 0 });
      }
      x += 60 + rnd() * 90;
    }
  }
  out.sort((a, b) => b.z - a.z);
  R.dec[EST.id] = out;
}

function desenharObjetos() {
  const R = G.rm, lista = R.dec && R.dec[EST.id]; if (!lista) return;
  const yb = FY * T - cam.y + 2;
  for (const d of lista) {
    const o = EST.objetos[d.n]; if (!o) continue;
    const esc = o.escala * d.s * (d.z ? .8 : 1), w = o.r[2] * esc, h = o.r[3] * esc, sx = d.x - cam.x;
    if (sx + w / 2 < -20 || sx - w / 2 > VW + 20) continue;
    const bal = o.balanca ? Math.sin(G.time * 1.6 + d.v * 30) * 1.2 : 0;
    g.globalAlpha = d.z ? .7 : 1;
    recorte(o.img, o.r, sx - w / 2, yb - h + bal, esc, d.v > .5);
    g.globalAlpha = 1;
  }
}

// ---------- fundo da época e camadas com parallax ----------
function caminhoFundo(era) { return EST.pasta + EST.fundos.replace('{era}', era); }

function desenharFundo(era) {
  const R = G.rm, im = carregarImagem(caminhoFundo(era));
  if (era + 1 < NR) preCarregar(caminhoFundo(era + 1));
  g.fillStyle = EST.corCeu; g.fillRect(-30, -30, VW + 60, VH + 60);
  if (imagemPronta(im)) {
    const w = im.naturalWidth * VH / im.naturalHeight, roomW = R ? R.W * T : VW;
    const par = Math.max(0, (w - VW) / Math.max(1, roomW - VW)), x = -Math.min(cam.x * par, w - VW);
    g.imageSmoothingEnabled = false; g.drawImage(im, Math.round(x), 0, Math.round(w), VH);
  }
  const e = EST.escurecer || [0, 0, 0], gr = g.createLinearGradient(0, 0, 0, VH);
  gr.addColorStop(0, 'rgba(4,5,10,' + e[0] + ')'); gr.addColorStop(.6, 'rgba(4,5,10,' + e[1] + ')'); gr.addColorStop(1, 'rgba(4,5,10,' + e[2] + ')');
  g.fillStyle = gr; g.fillRect(-30, -30, VW + 60, VH + 60);
}

function desenharCamadas() {
  for (const c of EST.camadas || []) {
    const im = imgE(c.img); if (!im) continue;
    const r = c.recorte || [0, 0, im.naturalWidth, im.naturalHeight], esc = c.escala || 1;
    const w = r[2] * esc, h = r[3] * esc, y = c.base - h, base = cam.x * c.parallax;
    g.globalAlpha = c.alfa == null ? 1 : c.alfa;
    if (c.repetir == 'espaco') {
      const per = c.espaco, n0 = Math.floor((base - (c.x0 || 0) - w) / per);
      for (let n = n0; n <= n0 + Math.ceil((VW + w) / per) + 1; n++) {
        const x = (c.x0 || 0) + n * per - base; if (x > VW || x + w < 0) continue;
        recorte(c.img, r, x, y, esc, !!c.espelhar);
      }
    } else {
      const n0 = Math.floor(base / w), x0 = -(base - n0 * w);
      for (let q = 0; q < Math.ceil(VW / w) + 2; q++) {
        const n = n0 + q, x = x0 + q * w; if (x > VW || x + w < 0) continue;
        recorte(c.img, r, x, y, esc, c.repetir == 'espelho' && ((n % 2) + 2) % 2 == 1);
      }
    }
    g.globalAlpha = 1;
  }
}

// chamado pelo núcleo ao entrar numa sala
function prepararSala(R) {
  sortearObjetos(R);
  prepararEfeitos(R);
}
