// ===== Carregador de imagens (assets) =====
// Cada imagem é pedida uma vez e guardada. O jogo desenha só quando ela terminou de carregar.
// preCarregar() pede uma imagem com antecedência (ex.: o fundo da próxima era); ela só passa a contar como
// "em uso" quando o desenho pedir por carregarImagem(). A troca de sala espera as imagens em uso (carregando.js).
const IMG_CACHE = {};

// Caminho de um arquivo do jogo. Na versão de arquivo único (ferramentas/montar_arquivo_unico.py) as imagens e
// sons vêm embutidos em window.EMBUTIDO; na versão normal é o próprio caminho.
function arquivo(caminho) {
  const E = typeof window != 'undefined' && window.EMBUTIDO;
  if (!E || !caminho) return caminho;
  const partes = [];
  for (const p of String(caminho).split('/')) { if (p == '..') partes.pop(); else if (p && p != '.') partes.push(p); }
  return E[partes.join('/')] || caminho;
}

function carregarImagem(caminho, antecipada) {
  if (typeof Image == 'undefined' || !caminho) return null;
  let im = IMG_CACHE[caminho];
  if (!im) {
    try { im = new Image(); im.src = arquivo(caminho); }
    catch (e) { im = { complete: true, naturalWidth: 0 }; }
    im.antecipada = !!antecipada;
    IMG_CACHE[caminho] = im;
  } else if (!antecipada && im.antecipada) im.antecipada = false;
  return im;
}
const preCarregar = caminho => carregarImagem(caminho, true);
// quantas imagens em uso ainda estão baixando
function imagensBaixando() { let n = 0; for (const k in IMG_CACHE) { const im = IMG_CACHE[k]; if (!im.antecipada && !im.complete) n++; } return n; }

function imagemPronta(im) {
  return !!(im && im.complete && im.naturalWidth > 0);
}
