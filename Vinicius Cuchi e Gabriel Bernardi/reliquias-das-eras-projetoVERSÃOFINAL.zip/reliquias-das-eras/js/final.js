// ===== Final do jogo, créditos e o modo Crônicas do Fim =====
// Ao sair da última época: créditos rolando sobre a pintura (assets/interface/creditos_fundo.webp),
// a mensagem final e, na primeira vez que alguém termina o jogo, o desbloqueio do modo Crônicas do Fim
// (fica guardado no navegador). Nesse modo: morreu, acabou; os chefes têm mais vida e cada golpe deles tira duas lanternas de vida.

const CREDITOS = [
  ['Diretor Executivo', 'Ântoni Ozecoski'],
  ['Diretor do Projeto', 'Gabriel Nass'],
  ['Diretor do Jogo', 'Gabriel Bernardi'],
  ['Marketing e Relações Públicas', 'Ântoni Ozecoski e Gabriel Bernardi'],
  ['Direção', 'Vinícius Cuchi, Ântoni Ozecoski, Gabriel Bernardi,', 'Gabriel Nass e Eduardo Bohm'],
  ['Arte e Animação', 'Vinícius Cuchi e Eduardo Bohm'],
  ['Desenvolvedores', 'Vinícius Cuchi e Gabriel Bernardi'],
  ['Trilha Sonora', 'Eduardo Bohm'],
  ['Acessibilidade', 'Ântoni Ozecoski e Gabriel Nass'],
  ['Agradecimentos Especiais', 'Anderson Martins, Lara Zambiasi, Grazieli Rutz']
];
const MENSAGEM_FINAL = [
  'Você apagou os erros.',
  'Restaurou as civilizações.',
  'Salvou a linha do tempo.',
  'Ou foi isso que acreditou.',
  'A história nunca esteve quebrada.',
  'Até você chegar.'
];
// chave própria do Relíquias das Eras: marcas antigas (do tempo em que o jogo se chamava Eras Perdidas, ou de testes)
// não contam — o modo só aparece depois de zerar esta versão neste navegador
const CHAVE_CRONICAS = chaveLocal('reliquias_cronicas_do_fim');   // por cópia do jogo (config.js)
const VEL_CREDITOS = 46;            // px por segundo
let MODO_CRONICAS = false;          // o jogo atual é no modo Crônicas do Fim?

let cronicasNaMemoria = false;     // se o navegador não deixar guardar, vale só até fechar a página
function cronicasLiberadas() { try { if (localStorage.getItem(CHAVE_CRONICAS) == '1') return true; } catch (_) { } return cronicasNaMemoria; }
function liberarCronicas() { const ja = cronicasLiberadas(); cronicasNaMemoria = true; try { localStorage.setItem(CHAVE_CRONICAS, '1'); } catch (_) { } return !ja; }

// a tela de início (Novo jogo / Continuar / Opções e a escolha do modo) fica em js/menus.js

// ---------------- fim do jogo ----------------
function iniciarFim() {
  G.mode = 'fim'; G.fim = { fase: 'creditos', t: 0, novo: false, cronicas: !!G.cronicas };
  if (!G.cronicas) G.fim.novo = liberarCronicas();
  pegarClique();
}
function alturaCreditos() { return 230 + CREDITOS.reduce((a, c) => a + 34 + (c.length - 1) * 30 + 26, 0) + 120; }
function updFim(dt) {
  const F = G.fim; F.t += dt; const toque = kp('Enter', 'Space', 'KeyE', 'KeyX', 'Mouse0') || !!pegarClique();
  if (F.fase == 'creditos') {
    const dur = (alturaCreditos() + VH) / VEL_CREDITOS;
    if (F.t >= dur || (toque && F.t > 1.5)) { F.fase = 'mensagem'; F.t = 0; }
  } else if (F.fase == 'mensagem') {
    const n = MENSAGEM_FINAL.length, total = n * 2.6 + 1.6;
    if (toque && F.t > .6) F.t = Math.max(F.t, (Math.floor(F.t / 2.6) + 1) * 2.6);   // toque: mostra a próxima frase
    if (F.t >= total) { F.fase = F.novo ? 'desbloqueio' : (F.cronicas ? 'vitoria' : 'fim'); F.t = 0; }
  } else {
    if (toque && F.t > 1.5) { G.fim = null; voltarAoTitulo(); }   // volta para o título
  }
}
function desenharFim() {
  const F = G.fim; g.fillStyle = '#030304'; g.fillRect(0, 0, VW, VH);
  if (F.fase == 'creditos') {
    const im = carregarImagem(INTERFACE.pasta + 'creditos_fundo.webp'), H = alturaCreditos(), rol = F.t * VEL_CREDITOS, prog = clamp(rol / (H + VH), 0, 1);
    if (imagemPronta(im)) {   // a pintura desce devagar (do céu até as ruínas) junto com os créditos
      const k = VW / im.naturalWidth, ih = im.naturalHeight * k;
      g.save(); g.imageSmoothingEnabled = true; g.globalAlpha = Math.min(1, F.t / 2);
      g.drawImage(im, 0, Math.round(-prog * (ih - VH)), VW, ih); g.restore();
    }
    const gr = g.createLinearGradient(0, 0, 0, VH); gr.addColorStop(0, 'rgba(0,0,0,.55)'); gr.addColorStop(.18, 'rgba(0,0,0,0)'); gr.addColorStop(.82, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,0,.55)');
    g.fillStyle = gr; g.fillRect(0, 0, VW, VH);
    let y = VH + 40 - rol;
    const texto = (s, yy, fonte, cor) => { g.font = fonte; g.textAlign = 'center'; g.fillStyle = 'rgba(0,0,0,.8)'; g.fillText(s, VW / 2 + 2, yy + 2); g.fillStyle = cor; g.fillText(s, VW / 2, yy); };
    texto('Relíquias das Eras', y + 40, 'italic 64px Georgia,serif', '#f2eee2');
    texto('uma jornada pelas eras da história', y + 82, 'italic 18px Georgia,serif', 'rgba(242,238,226,.75)');
    y += 230;
    for (const c of CREDITOS) {
      texto(c[0], y, 'italic 17px Georgia,serif', '#d8b47a'); y += 34;
      for (let j = 1; j < c.length; j++) { texto(c[j], y, '24px Georgia,serif', '#f2eee2'); y += 30; }
      y += 26;
    }
    texto('Sprites, fotos históricas e efeitos de terceiros: lista completa em creditos.html', y + 30, '13px Georgia,serif', 'rgba(242,238,226,.55)');
    if (F.t > 1.5) { g.font = '12px sans-serif'; g.fillStyle = 'rgba(242,238,226,.35)'; g.textAlign = 'right'; g.fillText('Enter / toque: pular', VW - 16, VH - 14); }
    return;
  }
  if (F.fase == 'mensagem') {
    const n = MENSAGEM_FINAL.length;
    MENSAGEM_FINAL.forEach((s, i) => {
      const t0 = i * 2.6, a = clamp((F.t - t0) / 1.1, 0, 1); if (a <= 0) return;
      const ultimas = i >= 3, y = 150 + i * 46;
      g.globalAlpha = a; g.textAlign = 'center'; g.font = (ultimas ? 'italic ' : '') + '28px Georgia,serif';
      g.fillStyle = i == n - 1 ? '#ff8a6a' : ultimas ? '#e0c8b8' : '#f2eee2'; g.fillText(s, VW / 2, y);
    });
    g.globalAlpha = 1; return;
  }
  const a = clamp(F.t / 1.2, 0, 1); g.globalAlpha = a; g.textAlign = 'center';
  if (F.fase == 'desbloqueio') {
    glow(8, VW / 2, 220, 260, .25, 60);
    g.font = '18px Georgia,serif'; g.fillStyle = 'rgba(242,238,226,.8)'; g.fillText('Você desbloqueou o modo', VW / 2, 180);
    g.font = 'italic 54px Georgia,serif'; g.fillStyle = '#ff8a6a'; g.fillText('Crônicas do Fim', VW / 2, 246);
    g.font = '17px Georgia,serif'; g.fillStyle = '#e8dcd0';
    g.fillText('Se você morrer, não pode reviver.', VW / 2, 306);
    g.fillText('Os chefes têm mais vida, e cada golpe deles quebra duas lanternas.', VW / 2, 334);
    g.font = '14px sans-serif'; g.fillStyle = 'rgba(242,238,226,.6)'; g.fillText('Escolha o modo na tela de início.', VW / 2, 380);
  } else if (F.fase == 'vitoria') {
    g.font = 'italic 46px Georgia,serif'; g.fillStyle = '#ff8a6a'; g.fillText('Crônicas do Fim concluídas', VW / 2, 230);
    g.font = '18px Georgia,serif'; g.fillStyle = '#e8dcd0'; g.fillText('Você atravessou todas as eras sem cair uma única vez.', VW / 2, 284);
  } else {
    g.font = 'italic 46px Georgia,serif'; g.fillStyle = '#f2eee2'; g.fillText('Fim', VW / 2, 240);
    g.font = '17px Georgia,serif'; g.fillStyle = 'rgba(242,238,226,.75)'; g.fillText('Runas lidas: ' + G.runes + ' / ' + NR * 2 + '   ·   Moedas: ' + G.coins, VW / 2, 290);
  }
  if (F.t > 1.5) { g.globalAlpha = .55 + .35 * Math.sin(G.time * 3); g.font = '16px Georgia,serif'; g.fillStyle = '#f2eee2'; g.fillText('Pressione ENTER ou toque para voltar ao início', VW / 2, 460); }
  g.globalAlpha = 1;
}

// ---------------- morte nas Crônicas do Fim ----------------
function fimDaCronica() {
  G.mode = 'cronicaPerdida'; G.fimT = 0; G.ban.t = 0; G.dica = null; pegarClique();
  if (SALVO && SALVO.cronicas) apagarSalvo();     // nas Crônicas do Fim o jogo salvo também se perde
}
function updCronicaPerdida(dt) {
  G.fimT += dt;
  if (G.fimT > 1.5 && (kp('Enter', 'Space', 'KeyE', 'KeyX', 'Mouse0') || pegarClique())) voltarAoTitulo();
}
function desenharCronicaPerdida() {
  g.fillStyle = 'rgba(4,2,2,' + Math.min(.92, G.fimT) + ')'; g.fillRect(0, 0, VW, VH);
  const a = clamp(G.fimT - .4, 0, 1); g.globalAlpha = a; g.textAlign = 'center';
  g.font = 'italic 52px Georgia,serif'; g.fillStyle = '#ff7a5a'; g.fillText('A crônica terminou', VW / 2, 220);
  g.font = '18px Georgia,serif'; g.fillStyle = '#e8dcd0'; g.fillText('Nas Crônicas do Fim não há volta. Você caiu em ' + G.rm.E.n + '.', VW / 2, 272);
  if (G.fimT > 1.5) { g.globalAlpha = .55 + .35 * Math.sin(G.time * 3); g.font = '16px Georgia,serif'; g.fillStyle = '#f2eee2'; g.fillText('Pressione ENTER ou toque para voltar ao início', VW / 2, 420); }
  g.globalAlpha = 1;
}
