// ===== Tela de carregamento =====
// Pela internet, na primeira vez, as imagens ainda estão baixando quando o jogo começa a desenhar; enquanto uma
// imagem não chega o jogo usaria o desenho simples feito por código e depois trocaria (o "piscar").
// Por isso, antes da tela de título, o jogo baixa as imagens que aparecem logo de cara (interface, fonte, título,
// Hallokin, monstros, objetos, cenário e o fundo da primeira era) mostrando o cristal e uma barra. As imagens dos
// chefes e do outro estilo continuam baixando por trás enquanto se joga.
// Ao trocar de sala a tela fica preta até as imagens da sala nova chegarem (salaPronta, usada em nucleo.js).
// Da segunda vez o navegador já tem tudo guardado e a tela de carregamento nem aparece.

const CARGA = { ativa: false, t: 0, lista: [], prontas: 0, fila: [], baixando: [], saida: 0 };
const CARGA_MOSTRA = .2;      // segundos antes de mostrar a tela (se carregar antes disso, ela nem aparece)
const CARGA_LIMITE = 25;      // segundos: depois disso começa mesmo sem tudo (internet muito lenta ou arquivo faltando)

// imagens do jogo: 'ja' = antes do título; 'depois' = por trás, durante o jogo
function imagensDoJogo() {
  const ja = [], depois = [], add = (l, c) => { if (c && !l.includes(c)) l.push(c); };
  const I = typeof INTERFACE != 'undefined' && INTERFACE;
  if (I) {
    if (I.fonte) add(ja, I.pasta + I.fonte.arquivo);
    if (I.hud) for (const k in I.hud) { const h = I.hud[k]; if (h && h.arquivo) add(ja, I.pasta + h.arquivo); if (h && h.vidro) add(ja, I.pasta + h.vidro); }
    if (I.titulo) { add(ja, I.titulo.pasta + I.titulo.cena); add(ja, I.titulo.pasta + I.titulo.logo); }
    if (I.caixa) add(ja, I.pasta + I.caixa.imagem);
    if (I.vida) { add(ja, I.pasta + I.vida.moldura); add(ja, I.pasta + I.vida.barra); }
    add(ja, I.pasta + 'espadas.png');
  }
  const P = typeof PERSONAGEM != 'undefined' && PERSONAGEM;
  if (P) { add(ja, P.pasta + P.arquivo); for (const k in P) if (P[k] && typeof P[k] == 'object' && typeof P[k].arquivo == 'string') add(ja, P.pasta + P[k].arquivo); }
  const M = typeof MONSTROS != 'undefined' && MONSTROS;
  if (M) for (const k in M) { const m = M[k]; if (m && m.anim) for (const a in m.anim) add(ja, M.pasta + m.pasta + m.anim[a][0]); }
  if (typeof OBJETOS != 'undefined' && OBJETOS) add(ja, OBJETOS.imagem);
  if (typeof EST != 'undefined' && EST) { for (const k in EST.imagens) add(ja, EST.pasta + EST.imagens[k]); add(ja, caminhoFundo(0)); }
  const C = typeof CHEFES_ARTE != 'undefined' && CHEFES_ARTE;
  if (C) for (const id in C) if (id != 'pasta') for (const c of arquivosChefe(id)) add(depois, c);
  if (typeof ESTILOS != 'undefined') for (const id in ESTILOS) { const E = ESTILOS[id]; for (const k in E.imagens) add(depois, E.pasta + E.imagens[k]); }
  return { ja, depois: depois.filter(c => !ja.includes(c)) };
}
function arquivosChefe(id) {
  const C = typeof CHEFES_ARTE != 'undefined' && CHEFES_ARTE, A = C && C[id], l = []; if (!A) return l;
  for (const gr of ['anim', 'extra']) for (const k in (A[gr] || {})) if (A[gr][k].arquivo) l.push(C.pasta + id + '/' + A[gr][k].arquivo);
  if (A.retrato) l.push(C.pasta + id + '/' + A.retrato);
  return l;
}

// começa na abertura do jogo (só no navegador; nos testes em Node não há página)
function iniciarCarga() {
  if (typeof document == 'undefined' || !document.body || typeof Image == 'undefined') return;
  const { ja, depois } = imagensDoJogo();
  // a fonte e o cristal primeiro: a própria tela de carregamento usa os dois
  CARGA.lista = ja.map(c => carregarImagem(c));
  CARGA.fila = depois.slice(); CARGA.ativa = true; CARGA.t = 0;
}
function atualizarCarga(dt) {
  // fila de fundo: até 3 imagens baixando ao mesmo tempo, para não disputar a internet com o jogo
  CARGA.baixando = CARGA.baixando.filter(im => !im.complete);
  while (CARGA.baixando.length < 3 && CARGA.fila.length && !CARGA.ativa) CARGA.baixando.push(preCarregar(CARGA.fila.shift()));
  if (CARGA.saida > 0) CARGA.saida = Math.max(0, CARGA.saida - dt);
  if (!CARGA.ativa) return;
  CARGA.t += dt;
  CARGA.prontas = CARGA.lista.filter(im => !im || im.complete).length;
  if (CARGA.prontas >= CARGA.lista.length || CARGA.t > CARGA_LIMITE) {
    CARGA.ativa = false;
    if (CARGA.t > CARGA_MOSTRA) CARGA.saida = .35;   // a tela de carregamento apareceu: o título entra devagar
  }
}
function desenharCarga() {
  g.fillStyle = '#050806'; g.fillRect(0, 0, VW, VH);
  if (CARGA.t < CARGA_MOSTRA) return;
  const f = CARGA.lista.length ? CARGA.prontas / CARGA.lista.length : 1, a = clamp((CARGA.t - CARGA_MOSTRA) * 4, 0, 1);
  const cx = VW / 2, cy = VH / 2 - 26;
  g.save(); g.globalAlpha = a;
  const H = INTERFACE && INTERFACE.hud && INTERFACE.hud.cristal, im = H && imgInterface(H.arquivo);
  if (im) {
    glow(45, cx, cy, 60, .22 + .08 * Math.sin(CARGA.t * 5), 70);
    const [w, h] = H.quadro, q = H.gira[0] + Math.floor(CARGA.t * H.fps) % H.gira[1], esc = .9;
    g.imageSmoothingEnabled = false; g.drawImage(im, q * w, 0, w, h, Math.round(cx - w * esc / 2), Math.round(cy - h * esc * .55), Math.round(w * esc), Math.round(h * esc));
  }
  const bw = 240, bx = Math.round(cx - bw / 2), by = cy + 78;
  g.fillStyle = 'rgba(255,255,255,.08)'; g.fillRect(bx, by, bw, 6);
  g.fillStyle = '#d9c98a'; g.fillRect(bx, by, Math.round(bw * f), 6);
  if (fontePintada('#cfd8c4')) textoPixel('Carregando ' + Math.round(f * 100) + '%', cx, by + 34, 2, '#cfd8c4', 'center', true);
  g.restore();
}
function desenharSaidaCarga() { if (CARGA.saida > 0) { g.fillStyle = 'rgba(5,8,6,' + CARGA.saida / .35 + ')'; g.fillRect(0, 0, VW, VH); } }

// a sala nova está pronta para aparecer? (fundo da era, chefe da sala e o que o último quadro desenhado pediu)
function salaPronta() {
  const R = G.rm; if (!R) return true;
  if (typeof EST != 'undefined' && EST) carregarImagem(caminhoFundo(R.i));
  const b = R.es && R.es.find(e => e.k == 'B');
  if (b && b.id) for (const c of arquivosChefe(b.id)) carregarImagem(c);
  return imagensBaixando() == 0;
}
