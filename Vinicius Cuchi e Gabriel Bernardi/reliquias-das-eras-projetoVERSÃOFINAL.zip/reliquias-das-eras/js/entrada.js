// ===== Entrada (teclado, mouse, controle) e opções do jogo =====
// O jogo não olha a tecla física: cada AÇÃO tem um "rótulo" (o código que o resto do jogo verifica, ex.: 'Space'
// para pular) e as teclas e o botão do controle de cada ação podem ser trocados no menu Opções > Controles.
// Teclado, controle e botões de toque ligam e desligam os rótulos em K (segurando) e P (apertou neste quadro).
// As opções (vídeo, FPS, brilho, som, controles) ficam guardadas no navegador.

// id, nome no menu, rótulo, teclas padrão, botão padrão do controle (mapeamento padrão do navegador)
const ACOES = [
  ['esquerda', 'Esquerda', 'ArrowLeft', ['ArrowLeft', 'KeyA'], 14],
  ['direita', 'Direita', 'ArrowRight', ['ArrowRight', 'KeyD'], 15],
  ['cima', 'Cima', 'ArrowUp', ['ArrowUp', 'KeyW'], 12],
  ['baixo', 'Baixo', 'ArrowDown', ['ArrowDown', 'KeyS'], 13],
  ['pular', 'Pular', 'Space', ['Space', 'KeyC'], 0],
  ['golpe', 'Golpe', 'KeyX', ['KeyX', 'KeyJ'], 2],
  ['esquiva', 'Esquiva', 'KeyZ', ['KeyZ', 'KeyK', 'ShiftLeft', 'ShiftRight'], 1],
  ['curar', 'Curar', 'KeyF', ['KeyF', 'KeyH'], 3],
  ['cabeca', 'Cabeça', 'KeyR', ['KeyR'], 5],
  ['interagir', 'Interagir', 'KeyE', ['KeyE'], 4],
  ['mapa', 'Mapa', 'KeyM', ['KeyM', 'ControlLeft', 'ControlRight'], 8],
  ['diario', 'Diário', 'KeyB', ['KeyB', 'Tab'], 6],
  ['pausa', 'Pausa', 'Escape', ['Escape', 'KeyP'], 9]
].map(a => ({ id: a[0], nome: a[1], rot: a[2], teclas: a[3], botao: a[4] }));
const ACAO = {}; for (const a of ACOES) ACAO[a.id] = a;
// teclas que funcionam mesmo sem estar ligadas a uma ação (confirmar nos menus, música, estilo)
const TECLAS_FIXAS = ['Enter', 'Escape', 'KeyN', 'KeyV', 'NumpadEnter'];

// ---------------- opções ----------------
const CHAVE_OPCOES = chaveLocal('reliquias_opcoes');   // por cópia do jogo (config.js)
const OPC_PADRAO = { brilho: 100, fps: 60, verFps: false, nitido: true, tremor: true, toque: 'auto', transp: 0, musica: 80, efeitos: 100, teclas: null, botoes: null };
let OPC = Object.assign({}, OPC_PADRAO);
try { const s = localStorage.getItem(CHAVE_OPCOES); if (s) Object.assign(OPC, JSON.parse(s)); } catch (_) { }
function salvarOpcoes() { try { localStorage.setItem(CHAVE_OPCOES, JSON.stringify(OPC)); } catch (_) { } aplicarOpcoes(); }
const teclasDe = a => (OPC.teclas && OPC.teclas[a.id]) || a.teclas;
const botaoDe = a => (OPC.botoes && OPC.botoes[a.id] != null) ? OPC.botoes[a.id] : a.botao;
function restaurarControles() { OPC.teclas = null; OPC.botoes = null; salvarOpcoes(); }
// tecla física -> rótulos das ações ligadas a ela
let TECLA_ROT = {};
function montarMapaTeclas() {
  TECLA_ROT = {};
  for (const a of ACOES) for (const t of teclasDe(a)) (TECLA_ROT[t] = TECLA_ROT[t] || []).push(a.rot);
}
function ligarTecla(acao, tecla) {   // a tecla passa a ser só desta ação
  OPC.teclas = OPC.teclas || {};
  for (const a of ACOES) { const l = teclasDe(a).filter(t => t != tecla); if (a.id != acao) OPC.teclas[a.id] = l; }
  OPC.teclas[acao] = [tecla];
  salvarOpcoes();
}
function ligarBotao(acao, b) {
  OPC.botoes = OPC.botoes || {};
  for (const a of ACOES) if (a.id != acao && botaoDe(a) == b) OPC.botoes[a.id] = -1;   // tira o botão de quem usava
  OPC.botoes[acao] = b; salvarOpcoes();
}
// aplica as opções que mexem na página (brilho, nitidez, botões de toque, volume)
function aplicarOpcoes() {
  montarMapaTeclas();
  try {
    if (cv.style) {
      cv.style.filter = OPC.brilho != 100 ? 'brightness(' + OPC.brilho / 100 + ')' : '';
      cv.style.imageRendering = OPC.nitido ? 'pixelated' : 'auto';
    }
    if (typeof document != 'undefined' && document.body && document.body.classList) {
      const b = document.body, auto = typeof TOQUE_AUTO != 'undefined' ? TOQUE_AUTO : b.classList.contains('touch');
      b.classList.toggle('touch', OPC.toque == 'sempre' || (OPC.toque == 'auto' && auto));
      if (window.ajustarTela) ajustarTela();
      document.documentElement.style.setProperty('--op', String(1 - clamp(OPC.transp, 0, 80) / 100));   // transparência dos botões de toque
    }
    if (typeof window != 'undefined' && window.__mus) window.__mus.volume = Math.min(1, OPC.musica / 100);
  } catch (_) { }
}
montarMapaTeclas();

// ---------------- teclado e mouse ----------------
// cada fonte (teclado, controle, toque) segura seus rótulos; K[rótulo] fica ligado se alguma estiver segurando
const SEGURA = { tecl: {}, pad: {}, toque: {} };
function mudarEntrada(fonte, rot, on) {
  const antes = !!K[rot];
  SEGURA[fonte][rot] = on ? 1 : 0;
  const agora = !!(SEGURA.tecl[rot] || SEGURA.pad[rot] || SEGURA.toque[rot]);
  if (agora && !antes) P[rot] = 1;
  K[rot] = agora ? 1 : 0;
}
const FISICAS = {};              // rótulo -> teclas físicas seguradas agora (duas teclas podem dar a mesma ação)
let CAPTURA = null;              // { tipo:'tecla'|'botao', acao, fim } enquanto o menu espera uma tecla nova
function rotulosDaTecla(code) { return TECLA_ROT[code] || (TECLAS_FIXAS.includes(code) ? [code == 'NumpadEnter' ? 'Enter' : code] : []); }
addEventListener('keydown', e => {
  if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Tab'].includes(e.code)) e.preventDefault();
  if (CAPTURA && CAPTURA.tipo == 'tecla') {
    e.preventDefault();
    if (e.code != 'Escape') ligarTecla(CAPTURA.acao, e.code);
    const c = CAPTURA; CAPTURA = null; if (c.fim) c.fim(e.code != 'Escape'); return;
  }
  for (const r of rotulosDaTecla(e.code)) { (FISICAS[r] = FISICAS[r] || new Set()).add(e.code); mudarEntrada('tecl', r, true); }
});
addEventListener('keyup', e => {
  for (const r of rotulosDaTecla(e.code)) { const s = FISICAS[r]; if (s) s.delete(e.code); if (!s || !s.size) mudarEntrada('tecl', r, false); }
});
function soltarTudo() { for (const f in SEGURA) for (const r in SEGURA[f]) if (SEGURA[f][r]) mudarEntrada(f, r, false); for (const r in FISICAS) FISICAS[r].clear(); }
addEventListener('blur', soltarTudo);
addEventListener('pointerdown', e => {
  if (e.pointerType !== 'mouse') return;
  if (e.target && e.target.closest && e.target.closest('#tc,.tb')) return;   // controles de toque (mesmo usados com o mouse) não contam como clique de golpe
  if (e.button === 0) mudarEntrada('tecl', 'Mouse0', true); else if (e.button === 2) mudarEntrada('tecl', 'Mouse2', true);
});
addEventListener('pointerup', e => { if (e.button === 0) mudarEntrada('tecl', 'Mouse0', false); else if (e.button === 2) mudarEntrada('tecl', 'Mouse2', false); });
addEventListener('contextmenu', e => e.preventDefault());

// ---------------- controle (gamepad) ----------------
const NOMES_BOTOES = ['A', 'B', 'X', 'Y', 'LB', 'RB', 'LT', 'RT', 'Select', 'Start', 'L3', 'R3', 'Dir. cima', 'Dir. baixo', 'Dir. esq.', 'Dir. dir.', 'Home'];
const CONTROLE = { nome: '', ant: [] };
function lerControle() {
  let gp = null;
  try { const l = navigator.getGamepads ? navigator.getGamepads() : []; for (const x of l) if (x && x.connected) { gp = x; break; } } catch (_) { }
  if (!gp) { if (CONTROLE.nome) { CONTROLE.nome = ''; for (const r in SEGURA.pad) if (SEGURA.pad[r]) mudarEntrada('pad', r, false); } return; }
  CONTROLE.nome = gp.id || 'Controle';
  const apertado = i => { const b = gp.buttons[i]; return !!b && (b.pressed || b.value > .5); };
  const ag = gp.buttons.map((_, i) => apertado(i));
  if (CAPTURA && CAPTURA.tipo == 'botao') {
    for (let i = 0; i < ag.length; i++) if (ag[i] && !CONTROLE.ant[i]) { ligarBotao(CAPTURA.acao, i); const c = CAPTURA; CAPTURA = null; if (c.fim) c.fim(true); break; }
    CONTROLE.ant = ag; return;
  }
  CONTROLE.ant = ag;
  const ax = gp.axes || [], sx = ax[0] || 0, sy = ax[1] || 0, z = .5;
  const extra = { esquerda: sx < -z, direita: sx > z, cima: sy < -z && Math.abs(sy) > Math.abs(sx), baixo: sy > z && Math.abs(sy) > Math.abs(sx) };
  for (const a of ACOES) { const b = botaoDe(a); mudarEntrada('pad', a.rot, (b >= 0 && ag[b]) || !!extra[a.id]); }
}

// nomes curtos para mostrar no menu
function nomeTecla(c) {
  if (!c) return '-';
  const M = { Space: 'Espaço', ArrowLeft: 'Seta esq.', ArrowRight: 'Seta dir.', ArrowUp: 'Seta cima', ArrowDown: 'Seta baixo', ShiftLeft: 'Shift', ShiftRight: 'Shift dir.',
    ControlLeft: 'Ctrl', ControlRight: 'Ctrl dir.', AltLeft: 'Alt', AltRight: 'Alt Gr', Escape: 'Esc', Enter: 'Enter', Tab: 'Tab', Backspace: 'Apagar', CapsLock: 'Caps',
    Semicolon: 'Ç', Quote: '~', BracketLeft: '´', BracketRight: '[', Comma: ',', Period: '.', Slash: ';', Minus: '-', Equal: '=', Backquote: "'", IntlBackslash: '\\', Backslash: ']' };
  if (M[c]) return M[c];
  if (c.startsWith('Key')) return c.slice(3);
  if (c.startsWith('Digit')) return c.slice(5);
  if (c.startsWith('Numpad')) return 'Num ' + c.slice(6);
  return c;
}
const nomeBotao = b => b < 0 || b == null ? '-' : (NOMES_BOTOES[b] || 'Botão ' + b);
