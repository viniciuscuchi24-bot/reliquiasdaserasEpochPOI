// ===== Configuração do jogo =====
// Mude aqui o estilo visual que abre primeiro. No jogo, a tecla V (ou o botão "Estilo") troca.
const CONFIG = {
  estiloInicial: 'pantano',            // 'pantano' ou 'cemiterio' (nomes das pastas em assets/estilos)
  lembrarEstilo: true,                 // guarda no navegador o último estilo escolhido
  audio: {
    musica: 'assets/audio/musica.mp3',
    pulo: 'assets/audio/pulo.mp3',
    esquiva: 'assets/audio/esquiva.mp3',
    // música própria de cada fase (opcional): número da fase -> arquivo.
    // Fases sem música aqui tocam a música principal. Exemplo:
    //   musicasPorFase: { 1: 'assets/audio/fases/paleolitico.mp3', 5: 'assets/audio/fases/nilo.mp3' }
    musicasPorFase: {},
    // música da luta contra cada chefe (toca enquanto ele está acordado; quando ele cai, volta a música da fase)
    musicasChefes: {
      legionario: 'assets/audio/chefes/estudo.mp3',     // 1º chefe — Legionário de Pedra
      espectro: 'assets/audio/chefes/espirito.mp3',     // 2º chefe — Espectro da Caravela
      colosso: 'assets/audio/chefes/industria.mp3',     // 3º chefe — Colosso a Vapor
      enigma: 'assets/audio/chefes/sinistro.mp3'        // último chefe — Máquina Enigma
    }
  }
};

// ===== Cada cópia do jogo guarda o seu próprio progresso =====
// O navegador guarda os dados por "site", e todos os arquivos abertos do próprio aparelho (file://) contam como o
// mesmo site: duas cópias do jogo dividiriam o mesmo jogo salvo. Por isso cada chave leva a identidade do arquivo
// (o endereço dele): uma cópia em outra pasta ou com outro nome tem o seu próprio jogo salvo, opções e desbloqueios.
const ID_ARQUIVO = (() => {
  try {
    const l = location, base = ((l.protocol == 'http:' || l.protocol == 'https:') ? l.origin + l.pathname : l.href.split('#')[0].split('?')[0]).replace(/\/index\.html?$/, '/');   // '/jogar/' e '/jogar/index.html' são o mesmo jogo
    let h = 5381; for (let i = 0; i < base.length; i++) h = ((h << 5) + h + base.charCodeAt(i)) | 0;
    return (h >>> 0).toString(36);
  } catch (_) { return 'local'; }
})();
const chaveLocal = nome => nome + '@' + ID_ARQUIVO;
// dados de antes desta separação (que eram de todas as cópias) ficam com a primeira cópia que abrir; depois somem
(function migrarDadosLocais() {
  try {
    for (const k of ['reliquias_opcoes', 'reliquias_cronicas_do_fim', 'reliquias_salvo', 'eras_estilo']) {
      const v = localStorage.getItem(k); if (v == null) continue;
      const n = chaveLocal(k); if (localStorage.getItem(n) == null) localStorage.setItem(n, v);
      localStorage.removeItem(k);
    }
  } catch (_) { }
})();

// Registros preenchidos pelos arquivos de assets (assets/estilos/*/estilo.js, assets/personagem/personagem.js
// e assets/monstros/monstros.js)
const ESTILOS = {};
const ORDEM_ESTILOS = [];
function registrarEstilo(e) { if (!ESTILOS[e.id]) ORDEM_ESTILOS.push(e.id); ESTILOS[e.id] = e; }
let PERSONAGEM = null;
function registrarPersonagem(p) { PERSONAGEM = p; }
let MONSTROS = null;
function registrarMonstros(m) { MONSTROS = Object.assign(MONSTROS || {}, m); }
// monstros extras (assets/monstros/monstros_era.js): entram junto com os outros; 'temas' diz em que épocas aparecem
function registrarMonstrosExtra(m) { MONSTROS = MONSTROS || { pasta: 'assets/monstros/' }; const t = m.temas; delete m.temas; Object.assign(MONSTROS, m); MONSTROS.temas = Object.assign(MONSTROS.temas || {}, t || {}); }
let CHEFES_ARTE = null;
function registrarChefes(c) { CHEFES_ARTE = c; }
let INTERFACE = null;
function registrarInterface(i) { INTERFACE = Object.assign(INTERFACE || {}, i); }   // vários arquivos juntam suas partes (interface.js, hud.js, fonte.js, titulo.js)
