// ===== Controles de toque (celular), música e efeitos sonoros =====
(function(){
 const body=document.body,cvs=document.getElementById('c');
 const coarse=!!(window.matchMedia&&(matchMedia('(pointer:coarse)').matches||(navigator.maxTouchPoints>0&&matchMedia('(hover:none)').matches)));
 const relayout=()=>{if(window.ajustarTela)ajustarTela()};
 // botões de toque: automático (aparecem em tela de toque), sempre ou nunca (Opções > Vídeo) — aplicarOpcoes em entrada.js
 window.TOQUE_AUTO=coarse;aplicarOpcoes();
 addEventListener('touchstart',()=>{if(!window.TOQUE_AUTO){window.TOQUE_AUTO=true;aplicarOpcoes()}},{once:true,passive:true});
 relayout();
 document.addEventListener('contextmenu',e=>e.preventDefault());
 const press=c=>mudarEntrada('toque',c,true),release=c=>mudarEntrada('toque',c,false);   // entrada.js
 // --- botões redondos: cada dedo segura um botão
 const active=new Map();
 function up(e){
  const cur=active.get(e.pointerId);
  if(cur){release(cur.el.dataset.k);cur.el.classList.remove('on');active.delete(e.pointerId)}
 }
 document.querySelectorAll('.tb[data-k]').forEach(b=>{
  b.addEventListener('pointerdown',e=>{e.preventDefault();try{b.setPointerCapture(e.pointerId)}catch(_){}
   up(e);press(b.dataset.k);b.classList.add('on');active.set(e.pointerId,{el:b})});
  b.addEventListener('pointerup',up);b.addEventListener('pointercancel',up);b.addEventListener('lostpointercapture',up);
 });
 // --- joystick: esquerda/direita andam; para cima/baixo só mudam a direção do golpe (não atacam nem interagem)
 const stick=document.getElementById('stick'),knob=stick&&stick.querySelector('.knob');
 const dirs={ArrowLeft:0,ArrowRight:0,StickUp:0,StickDown:0};let dedo=null,caixa=null,kx=0,ky=0,pedido=0;
 const liga=(c,on)=>{if(!!dirs[c]===on)return;dirs[c]=on?1:0;on?press(c):release(c)};
 // a bolinha é desenhada no máximo uma vez por quadro (o dedo manda muito mais eventos que isso)
 const pinta=()=>{pedido=0;knob.style.transform='translate3d('+kx.toFixed(1)+'px,'+ky.toFixed(1)+'px,0)'};
 function mexe(e){
  if(!caixa)caixa=stick.getBoundingClientRect();         // medido só quando o dedo encosta (medir a cada movimento força a página a recalcular)
  const R=caixa.width/2,m=R*.6;
  let dx=e.clientX-(caixa.left+R),dy=e.clientY-(caixa.top+R);const d=Math.hypot(dx,dy);if(d>m){dx*=m/d;dy*=m/d}
  kx=dx;ky=dy;if(!pedido)pedido=requestAnimationFrame(pinta);
  const nx=dx/m,ny=dy/m;
  const vert=Math.abs(ny)>Math.abs(nx)*1.2;           // cima/baixo só quando o dedo está bem na vertical
  liga('ArrowLeft',nx<-.3);liga('ArrowRight',nx>.3);liga('StickUp',vert&&ny<-.55);liga('StickDown',vert&&ny>.55);
 }
 function solta(e){if(e&&e.pointerId!==dedo)return;dedo=null;caixa=null;kx=ky=0;if(knob&&!pedido)pedido=requestAnimationFrame(pinta);if(stick)stick.classList.remove('on');for(const c in dirs)liga(c,false)}
 if(stick&&knob){
  stick.addEventListener('pointerdown',e=>{e.preventDefault();dedo=e.pointerId;caixa=null;try{stick.setPointerCapture(dedo)}catch(_){}stick.classList.add('on');mexe(e)});
  stick.addEventListener('pointermove',e=>{if(e.pointerId===dedo)mexe(e)});
  ['pointerup','pointercancel','lostpointercapture'].forEach(t=>stick.addEventListener(t,solta));
 }
 // --- tela cheia (botão no canto de cima e na linha de instruções). No Android também deita a tela.
 const raiz=document.documentElement,msg=document.getElementById('msg');let tMsg=0;
 const avisa=t=>{if(!msg)return;msg.textContent=t;msg.style.display='block';clearTimeout(tMsg);tMsg=setTimeout(()=>{msg.style.display='none'},5000)};
 const naTela=()=>!!(document.fullscreenElement||document.webkitFullscreenElement);
 const pede=raiz.requestFullscreen||raiz.webkitRequestFullscreen,sai=document.exitFullscreen||document.webkitExitFullscreen;
 const iOS=/iPhone|iPad|iPod/.test(navigator.userAgent)||(navigator.platform=='MacIntel'&&navigator.maxTouchPoints>1);
 const instalado=!!(window.matchMedia&&matchMedia('(display-mode: standalone),(display-mode: fullscreen)').matches)||navigator.standalone;
 const falhou=()=>avisa(iOS?'No iPhone o navegador não deixa tela cheia em páginas: toque em Compartilhar e depois em "Adicionar à Tela de Início" e abra o jogo pelo ícone.'
  :'Aqui não deu para abrir em tela cheia (o aplicativo bloqueia). Abra o jogo direto no Chrome, ou o arquivo reliquias-das-eras.html.');
 const ICO_ENTRA='<svg viewBox="0 0 24 24"><path d="M4 9V4h5M15 4h5v5M20 15v5h-5M9 20H4v-5"/></svg>',ICO_SAI='<svg viewBox="0 0 24 24"><path d="M9 4v5H4M20 9h-5V4M15 20v-5h5M4 15h5v5"/></svg>';
 function telaCheia(){
  if(naTela()){try{const r=sai.call(document);if(r&&r.catch)r.catch(()=>{})}catch(_){}return}
  if(!pede){if(instalado)return;return falhou()}
  let r;try{r=pede.call(raiz,{navigationUI:'hide'})}catch(_){return falhou()}
  const deita=()=>{try{if(screen.orientation&&screen.orientation.lock)screen.orientation.lock('landscape').catch(()=>{})}catch(_){}};
  if(r&&r.then)r.then(deita).catch(falhou);else setTimeout(()=>{if(naTela())deita();else falhou()},400);
 }
 function mudouTela(){
  const c=naTela();body.classList.toggle('cheia',c);
  const b=document.getElementById('b-tela');if(b)b.innerHTML=c?ICO_SAI:ICO_ENTRA;
  const t=document.getElementById('tela');if(t)t.textContent=c?'Sair da tela cheia':'Tela cheia';
  setTimeout(relayout,60);relayout();
 }
 window.telaCheia=telaCheia;
 document.addEventListener('fullscreenchange',mudouTela);document.addEventListener('webkitfullscreenchange',mudouTela);
 for(const id of ['b-tela','tela']){const el=document.getElementById(id);if(el)el.addEventListener('click',e=>{e.preventDefault();telaCheia()})}
 if(instalado){const b=document.getElementById('b-tela');if(b)b.style.display='none'}
 // botão da cabeça de abóbora aceso só com o tanque de energia cheio; nas telas de menu (loja, diário, mapa, final)
 // os controles somem para os toques irem direto para a tela (no título ficam só os botões pequenos de cima)
 const bCab=document.getElementById('b-cab');
 setInterval(()=>{try{const m=G&&G.mode;if(bCab)bCab.classList.toggle('vazio',!(p&&p.soul>=99));
  body.classList.toggle('menu',['loja','diario','map','fim','cronicaPerdida','banco','pausa'].includes(m));body.classList.toggle('titulo',m=='title');body.classList.toggle('previa',typeof emPreviaToque=='function'&&emPreviaToque())}catch(_){}},150);
 window.addEventListener('blur',()=>{active.forEach(c=>{release(c.el.dataset.k);c.el.classList.remove('on')});active.clear();solta()});
 cvs.addEventListener('pointerdown',()=>{
  const m=G&&G.mode;
  if(m=='dialog')P.Enter=1;else if(m=='map')P.KeyM=1;   // título, final e loja usam o ponto tocado (CLIQUE em loja.js)
 });
 const mus=new Audio(arquivo(CONFIG.audio.musica));mus.loop=true;mus.volume=OPC.musica/100;mus.preload='auto';
 let muted=false,started=false;
 function startMusic(){if(started||muted)return;const pr=mus.play();if(pr&&pr.then)pr.then(()=>{started=true}).catch(()=>{})}
 ['pointerdown','keydown','touchstart'].forEach(t=>addEventListener(t,startMusic,{passive:true}));
 window.toggleMusic=()=>{muted=!muted;if(muted){mus.pause();started=false}else startMusic();if(window.toast)toast(muted?'Música desligada':'Música ligada',1.5)};
 window.__mus=mus;
 // troca de música: a da fase (CONFIG.audio.musicasPorFase) ou a do chefe durante a luta (CONFIG.audio.musicasChefes).
 // A troca é suave (abaixa, troca, sobe). A música da fase continua de onde parou; a do chefe começa do início.
 let faixa=CONFIG.audio.musica,trocando=false;const posicao={};
 const volMus=()=>OPC.musica/100;
 function rampa(de,ate,ms,fim){const t0=performance.now();const id=setInterval(()=>{const u=Math.min(1,(performance.now()-t0)/ms);mus.volume=Math.max(0,Math.min(1,(de+(ate-de)*u)*volMus()));if(u>=1){clearInterval(id);if(fim)fim()}},30)}
 function musicaQuerida(){
  if(typeof G=='undefined'||!G||!G.rm)return CONFIG.audio.musica;
  const b=G.rm.es&&G.rm.es.find(e=>e.k=='B'&&e.on&&!e.dead),chefes=CONFIG.audio.musicasChefes||{};
  if(b&&chefes[b.id]&&G.mode!='fim')return chefes[b.id];
  return (CONFIG.audio.musicasPorFase||{})[G.ri+1]||CONFIG.audio.musica;
 }
 function trocar(quer){
  const ehChefe=Object.values(CONFIG.audio.musicasChefes||{}).includes(quer),tocava=started&&!mus.paused&&!muted;
  trocando=true;
  const fazer=()=>{
   if(!Object.values(CONFIG.audio.musicasChefes||{}).includes(faixa))posicao[faixa]=mus.currentTime;
   faixa=quer;mus.src=arquivo(quer);mus.load();
   const pos=ehChefe?0:(posicao[quer]||0);
   if(pos)mus.addEventListener('loadedmetadata',()=>{try{mus.currentTime=pos%(mus.duration||1e9)}catch(_){}},{once:true});
   if(tocava){mus.volume=0;const pr=mus.play();if(pr&&pr.catch)pr.catch(()=>{});rampa(0,1,700,()=>{trocando=false})}else{mus.volume=volMus();trocando=false}
  };
  if(tocava)rampa(1,0,450,fazer);else fazer();
 }
 setInterval(()=>{if(trocando)return;const quer=musicaQuerida();if(quer!==faixa)trocar(quer)},250);
 window.__faixa=()=>faixa;
 const SF={j:new Audio(arquivo(CONFIG.audio.pulo)),d:new Audio(arquivo(CONFIG.audio.esquiva))};
 for(const k in SF){SF[k].preload='auto';SF[k].volume=k=='j'?.7:.8}
 const volEf=()=>OPC.efeitos/100;
 // corte e acerto: sons feitos na hora (ruído filtrado), sem arquivo
 let AC=null;const sint=k=>{try{AC=AC||new (window.AudioContext||window.webkitAudioContext)();const t=AC.currentTime,d=k=='corte'?.16:k=='boom'?.55:k=='menu'?.06:.12,n=Math.floor(AC.sampleRate*d),buf=AC.createBuffer(1,n,AC.sampleRate),x=buf.getChannelData(0);for(let i=0;i<n;i++){const u=i/n;x[i]=(Math.random()*2-1)*(k=='corte'?Math.sin(u*Math.PI):Math.pow(1-u,k=='boom'?2:3))}
  const src=AC.createBufferSource();src.buffer=buf;const f=AC.createBiquadFilter();f.type=k=='corte'||k=='menu'?'bandpass':'lowpass';f.Q.value=k=='corte'?1.4:k=='menu'?6:.8;f.frequency.setValueAtTime(k=='corte'?900:k=='boom'?1100:k=='menu'?2400:1400,t);f.frequency.exponentialRampToValueAtTime(k=='corte'?3400:k=='boom'?60:k=='menu'?1800:220,t+d);
  const gn=AC.createGain();gn.gain.value=(k=='corte'?.22:k=='boom'?.95:k=='menu'?.35:.5)*volEf();src.connect(f);f.connect(gn);gn.connect(AC.destination);src.start(t)}catch(_){}};
 window.sfx=k=>{if(k=='corte'||k=='acerto'||k=='boom'||k=='menu')return sint(k);if(!SF[k])return;try{const a=SF[k].cloneNode();a.volume=SF[k].volume*volEf();const pr=a.play();if(pr&&pr.catch)pr.catch(()=>{})}catch(_){}};
})();
