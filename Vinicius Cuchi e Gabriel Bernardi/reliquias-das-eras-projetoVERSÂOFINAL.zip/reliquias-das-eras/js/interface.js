// ===== Interface: caixa de texto em pergaminho e barra de vida dos chefes =====
// As imagens e medidas ficam em assets/interface (interface.js). Se uma imagem ainda não carregou,
// o jogo desenha a caixa preta simples de antes.

function imgInterface(nome) {
  if (typeof INTERFACE == 'undefined' || !INTERFACE) return null;
  const im = carregarImagem(INTERFACE.pasta + nome);
  return imagemPronta(im) ? im : null;
}

// Desenha o pergaminho com moldura ocupando o retângulo (x, y, w, h), esticando só o meio (9 partes).
// Devolve o espaço interno onde o texto cabe { x, y, w, h, k } ou null se a imagem não carregou.
function caixaPergaminho(x, y, w, h, escala) {
  const C = INTERFACE && INTERFACE.caixa, im = C && imgInterface(C.imagem); if (!im) return null;
  const [me, mc, md, mb] = C.margens, W = im.naturalWidth, H = im.naturalHeight;
  const k = escala || clamp(h / 360, .1, .5);
  const e = me * k, c = mc * k, d = md * k, b = mb * k;
  const sx = [0, me, W - md, W], sy = [0, mc, H - mb, H], dx = [x, x + e, x + w - d, x + w], dy = [y, y + c, y + h - b, y + h];
  g.save(); g.imageSmoothingEnabled = true;
  for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) {
    const ow = dx[i + 1] - dx[i], oh = dy[j + 1] - dy[j]; if (ow <= 0 || oh <= 0) continue;
    g.drawImage(im, sx[i], sy[j], sx[i + 1] - sx[i], sy[j + 1] - sy[j], Math.round(dx[i]), Math.round(dy[j]), Math.ceil(ow) + 1, Math.ceil(oh) + 1);
  }
  g.restore();
  const bx = C.borda[0] * k, by = C.borda[1] * k;
  return { x: x + bx, y: y + by, w: w - 2 * bx, h: h - 2 * by, k };
}
const corTinta = qual => (INTERFACE && INTERFACE.caixa && INTERFACE.caixa[qual]) || '#2a1d12';

// caixa simples (fallback) — a de antes
function caixaPreta(x, y, w, h, a) { g.fillStyle = 'rgba(6,6,10,' + (a || .8) + ')'; g.fillRect(x, y, w, h); }

// Barra de vida do chefe (no alto, no meio da tela): moldura com arabescos e trepadeiras; a vida aparece no vão.
// A parte perdida some devagar (fica um rastro mais claro), e o nome vai escrito na própria barra.
function barraVidaChefe(b, vida, total) {
  const V = INTERFACE && INTERFACE.vida, mol = V && imgInterface(V.moldura), bar = V && imgInterface(V.barra);
  const frac = clamp(vida / total, 0, 1);
  b.rastro = b.rastro == null ? frac : (b.rastro > frac ? Math.max(frac, b.rastro - .25 * (1 / 60)) : frac);
  if (!mol || !bar) return false;
  const L = V.largura, k = L / mol.naturalWidth, H = mol.naturalHeight * k;
  const [vx0, vy0, vw0, vh0] = V.vao, x = Math.round(VW / 2 - L / 2), y = 2;   // no alto da tela, inteira: as trepadeiras ficam penduradas sem cobrir o chão
  const vx = x + vx0 * k, vy = y + vy0 * k, vw = vw0 * k, vh = vh0 * k;
  g.save(); g.imageSmoothingEnabled = true;
  g.fillStyle = 'rgba(18,6,6,.9)'; g.fillRect(vx, vy, vw, vh);
  if (b.rastro > frac) { g.globalAlpha = .55; g.drawImage(bar, 0, 0, bar.naturalWidth * b.rastro, bar.naturalHeight, vx, vy, vw * b.rastro, vh); g.globalAlpha = 1; }
  if (frac > 0) g.drawImage(bar, 0, 0, bar.naturalWidth * frac, bar.naturalHeight, vx, vy, vw * frac, vh);
  if (b.fl > 0) { g.fillStyle = 'rgba(255,240,220,.35)'; g.fillRect(vx, vy, vw * frac, vh); }
  g.drawImage(mol, x, y, L, H);
  g.textAlign = 'center'; g.font = 'italic 15px Georgia,serif';
  g.fillStyle = 'rgba(0,0,0,.75)'; g.fillText(b.name, VW / 2 + 1, vy + vh / 2 + 6);
  g.fillStyle = '#f4ead8'; g.fillText(b.name, VW / 2, vy + vh / 2 + 5);
  g.restore();
  return true;
}

// ===================== Fonte de pixel (menus e HUD) =====================
// assets/interface/fonte.png + fonte.js (ferramentas/gerar_fonte.py). Cada cor vira uma cópia pintada da folha
// (guardada), e as letras são desenhadas ampliadas sem suavizar.
const FONTE_TINTA = {};
const TROCA_LETRA = { '—': '-', '–': '-', '…': '...', '←': '<', '→': '>', '↑': '^', '↓': 'v', '“': '"', '”': '"', '’': "'" };
function fontePintada(cor) {
  const F = INTERFACE && INTERFACE.fonte, im = F && imgInterface(F.arquivo); if (!im) return null;
  let c = FONTE_TINTA[cor]; if (c) return c;
  try {
    c = document.createElement('canvas'); c.width = im.naturalWidth; c.height = im.naturalHeight;
    const x = c.getContext('2d'); x.drawImage(im, 0, 0); x.globalCompositeOperation = 'source-in'; x.fillStyle = cor; x.fillRect(0, 0, c.width, c.height);
    // a imagem pode ainda não estar decodificada (a cópia sairia vazia): confere a letra A antes de guardar
    try { const L = INTERFACE.fonte.letras.A, d = x.getImageData(L[0], 0, L[1], INTERFACE.fonte.altura).data; let tem = false; for (let i = 3; i < d.length; i += 4) if (d[i]) { tem = true; break; } if (!tem) return c; } catch (_) { }
  } catch (_) { return null; }
  return FONTE_TINTA[cor] = c;
}
function letraPixel(ch) { const F = INTERFACE.fonte; return F.letras[ch] || F.letras[TROCA_LETRA[ch]] || F.letras[ch.normalize ? ch.normalize('NFD')[0] : ch] || F.letras['?']; }
function larguraPixel(s, esc) {
  const F = INTERFACE && INTERFACE.fonte; s = String(s);
  if (!F) { g.font = Math.round(9 * esc) + 'px monospace'; return g.measureText(s).width; }
  let w = 0; for (const ch of s) w += letraPixel(ch)[2]; return w * esc;
}
// texto com a fonte de pixel; y = linha de base. sombra: true (escura embaixo/direita) ou uma cor
function textoPixel(s, x, y, esc, cor, alinh, sombra) {
  s = String(s); const F = INTERFACE && INTERFACE.fonte, c = F && fontePintada(cor);
  const w = larguraPixel(s, esc); let x0 = alinh == 'center' ? x - w / 2 : alinh == 'right' ? x - w : x;
  if (!c) { g.font = Math.round(9 * esc) + 'px monospace'; g.textAlign = 'left'; if (sombra) { g.fillStyle = 'rgba(0,0,0,.8)'; g.fillText(s, x0 + esc, y + esc); } g.fillStyle = cor; g.fillText(s, x0, y); return w; }
  if (sombra) { const so = fontePintada(sombra === true ? '#060a07' : sombra); if (so) desenharLetras(so, s, x0 + esc, y + esc, esc); }
  desenharLetras(c, s, x0, y, esc);
  return w;
}
function desenharLetras(folha, s, x0, y, esc) {
  const F = INTERFACE.fonte, yy = Math.round(y - F.base * esc); let x = Math.round(x0);
  const sm = g.imageSmoothingEnabled; g.imageSmoothingEnabled = false;
  for (const ch of s) { const L = letraPixel(ch); if (ch != ' ') g.drawImage(folha, L[0], 0, L[1], F.altura, x - L[3] * esc, yy, L[1] * esc, F.altura * esc); x += L[2] * esc; }
  g.imageSmoothingEnabled = sm;
}
// quebra o texto em linhas que cabem em maxW (fonte de pixel)
function quebrarPixel(s, maxW, esc) { const out = []; let cur = ''; for (const w of String(s).split(' ')) { const t = cur ? cur + ' ' + w : w; if (larguraPixel(t, esc) > maxW && cur) { out.push(cur); cur = w; } else cur = t; } if (cur) out.push(cur); return out; }

// ===================== Vida (lanternas) e tanque de energia (esfera) =====================
// Cada máscara de vida é uma lanterna. Ao levar dano, as lanternas perdidas trincam e estouram (os cacos caem);
// ao curar, a lanterna acende de novo. A energia é o líquido verde dentro da esfera.
const HUD_L = { G: null, hp: 0, est: [], cacos: [] };
const HUD_POS = { esfera: [56, 52], esferaK: .62, lx: 106, ly: 12, lpasso: 30, lesc: 2 };
const posLanterna = i => [HUD_POS.lx + i * HUD_POS.lpasso, HUD_POS.ly];
function atualizarHUD(dt) {
  if (typeof p == 'undefined' || !p) return;
  // durante a morte a vida já volta ao máximo por dentro (die em nucleo.js), mas as lanternas ficam quebradas até renascer
  const hp = (G.mode == 'morte' || G.mode == 'cronicaPerdida') ? 0 : p.hp;
  if (HUD_L.G !== G) { HUD_L.G = G; HUD_L.hp = hp; HUD_L.est = []; HUD_L.cacos = []; }
  const L = HUD_L;
  for (let i = 0; i < p.mhp; i++) if (!L.est[i]) L.est[i] = { m: i < hp ? 'acesa' : 'quebrada', t: 0 };
  if (hp < L.hp) { let k = 0; for (let i = L.hp - 1; i >= Math.max(0, hp); i--, k++) { const e = L.est[i]; if (e && e.m != 'quebrada') { e.m = 'quebrando'; e.t = -k * .09; e.caco = 0; } } }
  else if (hp > L.hp) { for (let i = Math.max(0, L.hp); i < hp; i++) { const e = L.est[i]; if (e) { e.m = 'acendendo'; e.t = -(i - L.hp) * .08; } } }
  L.hp = hp;
  L.est.forEach((e, i) => {
    if (!e) return; e.t += dt;
    if (e.m == 'quebrando') {
      if (e.t >= .17 && !e.caco) {               // estoura: cacos de vidro e brasas caindo
        e.caco = 1; const [x, y] = posLanterna(i), cx = x + 13, cy = y + 28;
        for (let k = 0; k < 14; k++) L.cacos.push({ x: cx + (Math.random() - .5) * 14, y: cy + (Math.random() - .5) * 16, vx: (Math.random() - .5) * 150, vy: -60 - Math.random() * 130,
          t: .6 + Math.random() * .5, c: ['#fff0b0', '#ffd768', '#f0a83a', '#d8d2c8', '#ffffff'][k % 5], s: k % 3 ? 2 : 3 });
      }
      if (e.t > .55) e.m = 'quebrada';
    } else if (e.m == 'acendendo' && e.t > .45) e.m = 'acesa';
  });
  for (const c of L.cacos) { c.vy += 520 * dt; c.x += c.vx * dt; c.y += c.vy * dt; c.t -= dt; }
  L.cacos = L.cacos.filter(c => c.t > 0 && c.y < 300);
}
function desenharLanternas() {
  const H = INTERFACE && INTERFACE.hud && INTERFACE.hud.lanterna, im = H && imgInterface(H.arquivo), L = HUD_L, esc = HUD_POS.lesc;
  const [cw, ch] = H ? H.quadro : [13, 22], perigo = HUD_L.hp == 1;
  for (let i = 0; i < p.mhp; i++) {
    const e = L.est[i] || { m: i < L.hp ? 'acesa' : 'quebrada', t: 0 };
    let [x, y] = posLanterna(i), q, flash = 0, acesa = false;
    const t = Math.max(0, e.t);
    if (e.m == 'acesa') { q = H ? H.acesa[Math.abs(Math.floor(G.time * (perigo ? 14 : 6) + i * 2.3 + Math.sin(G.time * 3.1 + i) * 1.4)) % 3] : 0; acesa = true; }
    else if (e.m == 'quebrando') {
      if (e.t < 0) { q = H ? H.acesa[0] : 0; acesa = true; }
      else if (t < .07) { q = H.acesa[0]; flash = 1 - t / .07; acesa = true; x += Math.round((Math.random() - .5) * 4); }
      else if (t < .17) { q = H.trinca[0]; acesa = true; x += Math.round((Math.random() - .5) * 3); y += Math.round((Math.random() - .5) * 2); }
      else if (t < .3) { q = (Math.floor(t * 40) % 2) ? H.trinca[1] : H.quebrada; x += Math.round((Math.random() - .5) * 2); }
      else q = H.quebrada;
    } else if (e.m == 'acendendo') { if (t < .18) { q = H.quebrada; flash = t / .18; } else { q = H.acesa[0]; flash = 1 - (t - .18) / .27; acesa = true; } }
    else q = H ? H.quebrada : 0;
    if (acesa) {   // brilho quente em volta da chama (vermelho e pulsando quando é a última)
      const cx = x + (H ? H.chama[0] : 6) * esc, cy = y + (H ? H.chama[1] : 14) * esc;
      const r = 26 + Math.sin(G.time * 9 + i * 1.7) * 2;
      const gr = g.createRadialGradient(cx, cy, 2, cx, cy, r);
      gr.addColorStop(0, perigo ? 'rgba(255,120,60,' + (.4 + .2 * Math.sin(G.time * 10)) + ')' : 'rgba(255,200,90,.32)'); gr.addColorStop(1, 'rgba(255,170,60,0)');
      g.fillStyle = gr; g.fillRect(cx - r, cy - r, 2 * r, 2 * r);
    }
    if (im) { g.save(); g.imageSmoothingEnabled = false; g.drawImage(im, q * cw, 0, cw, ch, Math.round(x), Math.round(y), cw * esc, ch * esc); g.restore(); }
    else { g.fillStyle = acesa ? '#ffd768' : '#3a0620'; g.fillRect(x + 4, y + 8, 18, 30); }
    if (flash > 0) {
      const cx = x + 13, cy = y + 29, r = 30;
      g.save(); g.globalCompositeOperation = 'lighter';
      const gr = g.createRadialGradient(cx, cy, 1, cx, cy, r); gr.addColorStop(0, 'rgba(255,250,220,' + flash + ')'); gr.addColorStop(1, 'rgba(255,220,150,0)');
      g.fillStyle = gr; g.fillRect(cx - r, cy - r, 2 * r, 2 * r); g.restore();
    }
  }
  for (const c of L.cacos) { g.globalAlpha = clamp(c.t * 2, 0, 1); g.fillStyle = c.c; g.fillRect(Math.round(c.x), Math.round(c.y), c.s, c.s); }
  g.globalAlpha = 1;
}
// esfera do tanque de energia: vidro escuro, líquido verde com ondinha e bolhas, reflexo e moldura por cima
function desenharEsfera(cx, cy, k, frac) {
  const E = INTERFACE && INTERFACE.hud && INTERFACE.hud.esfera, mol = E && imgInterface(E.arquivo), vid = E && imgInterface(E.vidro);
  const r = (E ? E.raio : 42) * k, cheio = frac >= .99;
  g.save(); g.beginPath(); g.arc(cx, cy, r + .5, 0, 7); g.clip();
  let gr = g.createRadialGradient(cx - r * .25, cy - r * .35, 2, cx, cy, r);
  gr.addColorStop(0, '#2c2824'); gr.addColorStop(1, '#090807'); g.fillStyle = gr; g.fillRect(cx - r, cy - r, 2 * r, 2 * r);
  if (frac > .005) {
    const nivel = cy + r - 2 * r * frac, amp = frac < .99 ? 1.6 + Math.sin(G.time * 1.3) * .6 : 0;
    g.beginPath(); g.moveTo(cx - r - 2, cy + r + 2);
    for (let x = -r - 2; x <= r + 2; x += 2) g.lineTo(cx + x, nivel + Math.sin(G.time * 3 + x * .12) * amp + Math.sin(G.time * 1.7 - x * .07) * amp * .6);
    g.lineTo(cx + r + 2, cy + r + 2); g.closePath();
    gr = g.createLinearGradient(0, nivel, 0, cy + r);
    gr.addColorStop(0, cheio ? '#d8ff6a' : '#b6e04c'); gr.addColorStop(.35, '#6eaa1e'); gr.addColorStop(1, '#244a08');
    g.fillStyle = gr; g.fill();
    g.strokeStyle = 'rgba(236,255,170,.85)'; g.lineWidth = 1.4; g.stroke();
    // bolhas subindo
    g.fillStyle = 'rgba(220,255,150,.55)';
    for (let b = 0; b < 6; b++) {
      const u = (G.time * (.25 + b * .05) + b * .37) % 1, bx = cx + Math.sin(b * 2.1 + G.time) * r * .55, by = cy + r - u * (cy + r - nivel);
      if (by > nivel + 2) { g.beginPath(); g.arc(bx, by, 1 + (b % 3) * .5, 0, 7); g.fill(); }
    }
  }
  if (cheio) {   // tanque cheio: pulsa (dá para lançar a cabeça)
    g.globalCompositeOperation = 'lighter'; const a = .18 + .14 * Math.sin(G.time * 6);
    gr = g.createRadialGradient(cx, cy, 2, cx, cy, r); gr.addColorStop(0, 'rgba(200,255,120,' + a + ')'); gr.addColorStop(1, 'rgba(120,200,40,0)');
    g.fillStyle = gr; g.fillRect(cx - r, cy - r, 2 * r, 2 * r); g.globalCompositeOperation = 'source-over';
  }
  g.restore();
  g.save(); g.imageSmoothingEnabled = true;
  if (vid) g.drawImage(vid, cx - E.centro[0] * k, cy - E.centro[1] * k, vid.naturalWidth * k, vid.naturalHeight * k);
  if (mol) g.drawImage(mol, cx - E.centro[0] * k, cy - E.centro[1] * k, mol.naturalWidth * k, mol.naturalHeight * k);
  else { g.strokeStyle = '#8a7a5a'; g.lineWidth = 4; g.beginPath(); g.arc(cx, cy, r + 2, 0, 7); g.stroke(); }
  g.restore();
}
