// ===== Arte dos chefes =====
// Desenha os chefes, seus ataques e seus ajudantes com as imagens de assets/chefes
// (recortadas da folha de arte por ferramentas/recortar_chefes.py; tamanhos em assets/chefes/chefes.js).
// Se uma imagem ainda não carregou, o jogo usa o desenho simples de js/chefes.js.

function arteChefe(id) { return typeof CHEFES_ARTE != 'undefined' && CHEFES_ARTE ? CHEFES_ARTE[id] : null; }
function tiraChefe(id, grupo, nome) {
  const A = arteChefe(id), info = A && A[grupo] && A[grupo][nome]; if (!info) return null;
  const im = carregarImagem(CHEFES_ARTE.pasta + id + '/' + info.arquivo);
  return imagemPronta(im) ? { im, info } : null;
}
function quadroDe(info, t, laco) {
  const q = Math.floor(Math.max(0, t) * info.fps);
  return (laco == null ? info.laco !== false : laco) ? q % info.n : Math.min(info.n - 1, q);
}
// desenha o quadro q com o ponto de apoio (pés ou centro) em (x, y) na tela
function desenharQuadro(t, q, x, y, esc, virar, alfa, branco, ang) {
  const [w, h] = t.info.quadro, [ax, ay] = t.info.ponto;
  const dx = -Math.round(ax * esc), dy = -Math.round(ay * esc), dw = Math.round(w * esc), dh = Math.round(h * esc);
  g.save(); g.translate(Math.round(x), Math.round(y)); if (ang) g.rotate(ang); if (virar) g.scale(-1, 1);
  g.imageSmoothingEnabled = false; if (alfa != null) g.globalAlpha = alfa;
  g.drawImage(t.im, q * w, 0, w, h, dx, dy, dw, dh);
  if (branco) { g.globalCompositeOperation = 'lighter'; g.globalAlpha = (alfa == null ? 1 : alfa) * .7; g.drawImage(t.im, q * w, 0, w, h, dx, dy, dw, dh); }
  g.restore();
}
// troca de animação: guarda quando ela começou
function animar(b, nome) { if (b.anim != nome) { b.anim = nome; b.animT = G.time; } return G.time - b.animT; }

// qual animação cada chefe usa em cada estado
const ANIM_CHEFE = {
  legionario(b) {
    if (b.bloq > 0) return 'escudo';
    if (b.st == 'idle') return Math.abs(b.vx) > 10 ? 'andar' : 'parado';
    if (b.st == 'prep') return b.nx == 'pilum' ? 'lanca' : 'escudo';
    if (b.st == 'investida') return 'correr';
    if (b.st == 'salto') return 'salto';
    if (b.st == 'atordoado') return 'dano';
    return 'parado';
  },
  espectro(b) {
    if (b.st == 'prep_mergulho' || b.st == 'mergulho') return 'mergulho';
    if (b.st == 'rasante' || b.st == 'sobe') return 'voar';
    if (b.st == 'prep_canhao') return 'canhao';
    return 'parado';
  },
  colosso(b) {
    if (b.st == 'prep_pisao') return 'pisao';
    if (b.st == 'prep_eng') return 'arremesso';
    if (b.st == 'superaquecido') return 'quente';
    if (b.st == 'anda' && Math.abs(b.vx) > 5) return 'andar';
    return 'parado';
  },
  enigma(b) {
    if (b.fl > 0) return 'dano';
    if (b.st == 'bombardeio') return 'bombas';
    return b.ph2 || Math.abs(b.vx) > 40 ? 'voar' : 'parado';
  }
};

function desenharChefeArte(b) {
  const A = arteChefe(b.id); if (!A) return false;
  if (b.id == 'enigma') return desenharEnigma(b, A);
  const morto = b.dead, nome = morto ? 'morte' : ANIM_CHEFE[b.id](b);
  const t = tiraChefe(b.id, 'anim', nome); if (!t) return false;
  const tt = morto ? G.time - b.morte : animar(b, nome), q = quadroDe(t.info, tt);
  const voa = A.apoio == 'centro';
  let x = b.x + b.w / 2 - cam.x, y = (voa ? b.y + b.h / 2 : b.y + b.h) - cam.y;
  let olha = b.d || 1;
  if (b.id == 'espectro') olha = (b.st == 'mergulho' || b.st == 'rasante') ? Math.sign(b.vx || 1) : lado(b);
  let alfa = b.alfa == null ? 1 : b.alfa;
  if (morto) { const dt = G.time - b.morte; alfa = dt > 4 ? Math.max(0, 1 - (dt - 4) / 1.5) : 1; if (alfa <= 0) return true; }
  // contraluz para o chefe se destacar do fundo
  if (!morto) glow(b.id == 'espectro' ? 185 : b.id == 'colosso' ? 22 : G.rm.E.hu, x, y - (voa ? 0 : b.h * .5), b.h * .95, b.id == 'colosso' && b.st == 'superaquecido' ? .45 : .22, 60);
  if (b.id == 'espectro' && !morto) {
    if (b.st == 'rasante') { const r = tiraChefe('espectro', 'extra', 'respingo'); if (r) desenharQuadro(r, 0, x - olha * b.w * .4, FY * T - cam.y, 1.2, olha < 0, .8); }
    if (b.ph2) glow(0, x, y, 90, .25 + .08 * Math.sin(G.time * 6), 55);
  }
  desenharQuadro(t, q, x, y + (voa ? Math.round(Math.sin(G.time * 2.2) * 2) * 2 : 0), A.escala, A.direita ? olha < 0 : olha > 0, alfa, b.fl > 0 && !morto);
  // efeitos de cada chefe
  if (b.id == 'espectro' && (b.st == 'some' || b.st == 'aparece')) {
    const s = tiraChefe('espectro', 'anim', 'sumir');
    if (s) { const u = b.st == 'some' ? 1 - b.t : b.t / .5; desenharQuadro(s, quadroDe(s.info, b.st == 'some' ? 1 - b.t : .5 - b.t, false), x, y, A.escala * .8, false, Math.min(1, .9 * (1 - Math.abs(.5 - Math.min(1, Math.max(0, u)))))); }
  }
  if (b.id == 'colosso' && !morto) {
    const f = tiraChefe('colosso', 'extra', 'fumaca');
    if (f) for (let k = 0; k < 2; k++) {   // fumaça das chaminés
      const u = (G.time * .7 + k * .5) % 1, sx = x + (k ? 18 : -18) * (A.direita ? olha : -olha);
      desenharQuadro(f, b.st == 'superaquecido' ? 2 : 1, sx, y - b.h * .95 - u * 40, .5 + u * .4, k == 1, .6 * (1 - u));
    }
    if (b.st == 'prep_vapor' || b.st == 'vapor') { const j = tiraChefe('colosso', 'extra', 'jato_vapor'); if (j) for (const d of [-1, 1]) desenharQuadro(j, quadroDe(j.info, G.time, true), x + d * b.w * .45, y - b.h * .55, 1, d < 0, .8); }
  }
  if (b.id == 'legionario' && b.st == 'atordoado' && !morto) for (let k = 0; k < 3; k++) { const a = G.time * 5 + k * 2.1; diamond(x + Math.cos(a) * 18, y - b.h - 10 + Math.sin(a) * 4, 4, '#ffe9a0'); }
  return true;
}

// Máquina Enigma: a máquina voadora (núcleo no centro), três rotores de proteção ligados por energia
function desenharEnigma(b, A) {
  const t = G.time, cx = b.x + b.w / 2 - cam.x, cy = b.y + b.h / 2 - cam.y + (b.dead ? 0 : Math.round(Math.sin(t * 1.5) * 3) * 2);
  // rotores e cabos de energia
  const rot = tiraChefe('enigma', 'extra', 'rotor'), rq = tiraChefe('enigma', 'extra', 'rotor_quebrado');
  b.rot.forEach((r, j) => {
    const rx = r.x + r.w / 2 - cam.x, ry = r.y + r.h / 2 - cam.y + (r.dead ? 0 : Math.round(Math.sin(t * 2 + j) * 2) * 2);
    if (!r.dead && !b.dead) {
      g.strokeStyle = 'rgba(255,60,40,' + (.45 + .3 * Math.sin(t * 12 + j)) + ')'; g.lineWidth = 2; g.setLineDash && g.setLineDash([6, 4]);
      g.beginPath(); g.moveTo(rx, ry); g.lineTo(cx, cy); g.stroke(); g.setLineDash && g.setLineDash([]);
      glow(0, rx, ry, 40, .3, 55);
      if (rot) desenharQuadro(rot, Math.floor(t * 14 + j) % rot.info.n, rx, ry, 1, false, 1, r.fl > 0);
    } else if (rq) desenharQuadro(rq, 0, rx, ry, .9, false, .7);
  });
  if (b.dead) {
    const dt = G.time - b.morte, m = tiraChefe('enigma', 'anim', 'morte'), d = tiraChefe('enigma', 'extra', 'destrocos'), ex = tiraChefe('enigma', 'extra', 'explosao');
    if (dt < 1.2 && m) desenharQuadro(m, quadroDe(m.info, dt, false), cx, cy + dt * dt * 120, A.escala, false, 1 - dt / 1.4);
    if (dt < 1.2 && ex) for (let k = 0; k < 3; k++) desenharQuadro(ex, Math.floor(dt * 12 + k) % ex.info.n, cx + (k - 1) * 50, cy + (k % 2) * 30 + dt * 60, 1.6, false, 1 - dt / 1.2);
    if (d && dt > .6) desenharQuadro(d, 0, cx, FY * T - cam.y + 6, 1, false, Math.min(1, (dt - .6) * 3));
    return true;
  }
  const nome = ANIM_CHEFE.enigma(b), tt = animar(b, nome), t2 = tiraChefe('enigma', 'anim', nome); if (!t2) return false;
  const exposto = !b.rot.some(r => !r.dead);
  glow(0, cx, cy, exposto ? 110 : 70, exposto ? .45 + .2 * Math.sin(t * 8) : .22, 55);
  desenharQuadro(t2, quadroDe(t2.info, tt), cx, cy, A.escala, false, 1, b.fl > 0);
  if (!exposto) {   // escudo de energia sobre o núcleo enquanto houver rotores
    g.strokeStyle = 'rgba(255,90,70,' + (.35 + .2 * Math.sin(t * 6)) + ')'; g.lineWidth = 2;
    g.beginPath(); g.arc(cx, cy, 30, 0, 7); g.stroke();
  }
  return true;
}

// ajudantes invocados pelos chefes (morcegos do navio fantasma, drones da Enigma)
function desenharArteAjudante(e) {
  const a = e.arte, t = tiraChefe(a.id, 'extra', a.nome); if (!t) return false;
  const x = e.x + e.w / 2 - cam.x, y = e.y + e.h / 2 - cam.y;
  if (e.dead) {
    const dt = G.time - e.morte, ex = tiraChefe('enigma', 'extra', 'explosao');
    if (a.nome == 'drone' && ex) { if (dt < .35) desenharQuadro(ex, Math.min(ex.info.n - 1, Math.floor(dt * 12)), x, y, 1, false, 1); }
    else if (dt < .5) desenharQuadro(t, 0, x, y + dt * 120, a.esc, false, 1 - dt * 2);
    return true;
  }
  const q = a.anima ? quadroDe(t.info, G.time + e.ph, true) : a.q % t.info.n;
  const olha = p.x + p.w / 2 < e.x + e.w / 2 ? -1 : 1;
  desenharQuadro(t, q, x, y + (a.anima ? 0 : Math.round(Math.sin(G.time * 6 + e.ph) * 1) * 2), a.esc, a.anima && olha < 0, 1, e.fl > 0);
  return true;
}

// ataques (projéteis) com a arte dos chefes; devolve false para usar o desenho simples
function desenharProjetilArte(q) {
  const R = G.rm, b = R.es.find(e => e.k == 'B'), id = b && b.id, x = q.x - cam.x, y = q.y - cam.y, cx = x + q.w / 2, cy = y + q.h / 2, t = G.time;
  let s;
  switch (q.k) {
    case 'pilum':
      if (!(s = tiraChefe('legionario', 'extra', 'lanca_voando'))) return false;
      desenharQuadro(s, 0, cx, cy, 2, false, 1, false, q.preso ? -1.2 : Math.atan2(q.vy, q.vx || .001)); return true;
    case 'bala':
      if (!(s = tiraChefe('espectro', 'extra', 'bala'))) return false;
      glow(185, cx, cy, 20, .35, 70); desenharQuadro(s, 0, cx, cy, 1, false); return true;
    case 'agua':
      if (!(s = tiraChefe('espectro', 'extra', 'onda'))) return false;
      desenharQuadro(s, quadroDe(s.info, t, true), cx, y + q.h, 1.25, q.vx < 0); return true;
    case 'engrenagem':
      if (!(s = tiraChefe('colosso', 'extra', 'engrenagem'))) return false;
      desenharQuadro(s, 0, cx, cy, 1.5, false, 1, false, t * 8 * Math.sign(q.vx || 1)); return true;
    case 'vapor': {
      if (!(s = tiraChefe('colosso', 'extra', 'vapor'))) return false;
      const base = FY * T - cam.y;
      if (q.warn > 0) { const j = tiraChefe('colosso', 'extra', 'jato_vapor'); if (j) desenharQuadro(j, Math.floor(t * 10) % j.info.n, cx, base, .7 + .2 * Math.sin(t * 20), false, .8); return true; }
      for (let yy = base, k = 0; yy > y - 20; yy -= 70, k++) desenharQuadro(s, (k + Math.floor(t * 8)) % s.info.n, cx + Math.round(Math.sin(t * 20 + k) * 1) * 2, yy + 8, 1.15, k % 2 == 1, .92);
      return true;
    }
    case 'onda':
      if (id == 'colosso') {
        if (!(s = tiraChefe('colosso', 'extra', 'fumaca'))) return false;
        desenharQuadro(s, 2, cx, y + q.h + 2, .55, q.vx < 0, .95); return true;
      }
      // onda de poeira do salto do legionário (pixel art)
      for (let k = 0; k < q.w; k += 4) { const hh = Math.round((Math.sin(k / q.w * Math.PI) * q.h + Math.sin(t * 20 + k) * 2) / 2) * 2; px(x + k, y + q.h - hh, 4, hh, k % 8 ? '#c8a878' : '#e8d0a0'); }
      return true;
    case 'feixe': {
      if (q.warn > 0) {
        for (let xx = x; xx < x + q.w; xx += 20) px(xx, cy - 1, 10, 2, 'rgba(255,60,50,' + (.5 + .3 * Math.sin(t * 25)) + ')');
        s = tiraChefe('enigma', 'extra', 'alvo'); if (s) desenharQuadro(s, 0, x + q.w, cy, .35 + .05 * Math.sin(t * 20), false, .9);
        return true;
      }
      const h = q.h, pis = Math.sin(t * 40) > 0 ? 2 : 0;
      px(x, y - 6 - pis, q.w, h + 12 + 2 * pis, 'rgba(140,10,10,.45)'); px(x, y, q.w, h, '#e0281e'); px(x, y + h * .25, q.w, h * .5, '#ff7a5a'); px(x, y + h * .4, q.w, Math.max(2, h * .2), '#ffe6d8');
      return true;
    }
    case 'marca':
      if (!(s = tiraChefe('enigma', 'extra', 'alvo'))) return false;
      desenharQuadro(s, 0, cx, y + 2, .35 + .06 * Math.sin(t * 18), false, .9); return true;
    case 'bomba':
      if (q.warn > 0) return true;
      if (!(s = tiraChefe('enigma', 'extra', 'missil'))) return false;
      desenharQuadro(s, 0, cx, cy, 1.5, false, 1, false, Math.atan2(q.vy || 1, q.vx || 0) + .785); return true;
    case 'missil':
      glow(20, cx, cy, 24, .35, 70);
      if (!(s = tiraChefe('enigma', 'extra', 'missil'))) { px(cx - 6, cy - 6, 12, 12, '#d0402a'); return true; }
      desenharQuadro(s, 0, cx, cy, 1.4, false, 1, false, Math.atan2(q.vy, q.vx) + .785); return true;
    case 'raio': {                                   // raio mirado: aviso tracejado, depois o feixe grosso
      const [x1, y1, L] = pontaRaio(q), sx = q.x0 - cam.x, sy = q.y0 - cam.y;
      g.save(); g.translate(Math.round(sx), Math.round(sy)); g.rotate(q.ang);
      if (q.warn > 0) {
        g.globalAlpha = .5 + .35 * Math.sin(t * 30);
        for (let d = 24; d < L; d += 18) px(d, -1, 10, 2, '#ff3a2a');
        g.restore();
        if ((s = tiraChefe('enigma', 'extra', 'alvo'))) desenharQuadro(s, 0, x1 - cam.x, y1 - cam.y, .3 + .05 * Math.sin(t * 20), false, .85);
        return true;
      }
      const h = q.larg, pis = Math.sin(t * 40) > 0 ? 2 : 0;
      px(0, -h / 2 - 6 - pis, L, h + 12 + 2 * pis, 'rgba(140,10,10,.45)'); px(0, -h / 2, L, h, '#e0281e'); px(0, -h / 4, L, h / 2, '#ff7a5a'); px(0, -Math.max(1, h * .1), L, Math.max(2, h * .2), '#ffe6d8');
      g.restore();
      if ((s = tiraChefe('enigma', 'extra', 'explosao'))) desenharQuadro(s, Math.floor(t * 12) % s.info.n, x1 - cam.x, y1 - cam.y, .9, false, .9);
      return true;
    }
    case 'coluna': {                                 // coluna de laser: mira no chão, depois o raio desce do teto
      const base = FY * T - cam.y, topo = 2 * T - cam.y;
      if (q.warn > 0) {
        for (let yy = topo; yy < base - 40; yy += 22) px(cx - 1, yy, 2, 10, 'rgba(255,60,50,' + (.3 + .25 * Math.sin(t * 25)) + ')');
        if ((s = tiraChefe('enigma', 'extra', 'alvo'))) desenharQuadro(s, 0, cx, base - 2, .4 + .06 * Math.sin(t * 18), false, .9);
        return true;
      }
      const w2 = q.w, pis = Math.sin(t * 40) > 0 ? 2 : 0;
      px(cx - w2 / 2 - 4 - pis, topo, w2 + 8 + 2 * pis, base - topo, 'rgba(140,10,10,.4)'); px(cx - w2 / 2 + 4, topo, w2 - 8, base - topo, '#e0281e'); px(cx - 8, topo, 16, base - topo, '#ff7a5a'); px(cx - 3, topo, 6, base - topo, '#ffe6d8');
      if ((s = tiraChefe('enigma', 'extra', 'raio_base'))) desenharQuadro(s, 0, cx, base + 6, 1.6, false, 1);
      return true;
    }
    case 'explosao':
      if (!(s = tiraChefe('enigma', 'extra', 'explosao'))) return false;
      desenharQuadro(s, Math.min(s.info.n - 1, Math.floor((1 - q.t / .32) * s.info.n)), cx, cy, 1.7, false, 1); return true;
  }
  return false;
}

// retrato grande do chefe quando ele acorda (com o nome)
function desenharRetratoChefe(id, a) {
  const A = arteChefe(id); if (!A || !A.retrato) return;
  const im = carregarImagem(CHEFES_ARTE.pasta + id + '/' + A.retrato); if (!imagemPronta(im)) return;
  const k = Math.min(1, 250 / im.naturalHeight), w = im.naturalWidth * k, h = im.naturalHeight * k;
  g.save(); g.globalAlpha = a; g.imageSmoothingEnabled = false;
  g.drawImage(im, Math.round(24 - (1 - a) * 40), Math.round(VH - h - 14), Math.round(w), Math.round(h));   // canto de baixo, à esquerda
  g.restore();
}
