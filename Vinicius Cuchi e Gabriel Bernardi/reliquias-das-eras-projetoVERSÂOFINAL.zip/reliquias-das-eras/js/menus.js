// ===== Tela de início e menus (início, opções, controles, marco de descanso, pausa) =====
// Estilo da tela de título: texto de pixel claro com sombra, sem caixas, um vaga-lume marcando o item escolhido.
// A cena do título (assets/titulo) é pintada por ferramentas/pintar_titulo.py; aqui ela ganha vida:
// feixes de luz pulsando, vaga-lumes, o brilho da porta e o Hallokin parado na frente do portal.
// Teclado/controle: ↑↓ escolhe, ←→ muda o valor, Enter/Pular/E confirma, Esc/Esquiva volta. Mouse e toque: clicar no item.

let MENU = null;   // { ctx: 'titulo' | 'banco' | 'pausa', pilha: [{ id, sel, rects }] }
const COR_MENU = { sel: '#f6f2e4', normal: '#a3b39a', off: '#414c3d', valor: '#ffd36e', dica: '#9fb096', cron: '#ff9a7a', cronSel: '#ffc0a8' };
const PONTEIRO = { x: 0, y: 0, mexeu: false };
if (cv.addEventListener) cv.addEventListener('pointermove', e => {
  if (e.pointerType != 'mouse') return;
  const r = cv.getBoundingClientRect(); PONTEIRO.x = (e.clientX - r.left) * VW / r.width; PONTEIRO.y = (e.clientY - r.top) * VH / r.height; PONTEIRO.mexeu = true;
});

function abrirMenu(ctx, id) { MENU = { ctx, pilha: [{ id, sel: 0 }] }; acertarSel(MENU.pilha[0]); pegarClique(); }
function irMenu(id) { const t = { id, sel: 0 }; MENU.pilha.push(t); acertarSel(t); pegarClique(); }
function voltarMenu() { MENU.pilha.pop(); if (!MENU.pilha.length) fecharMenu(); pegarClique(); }
function fecharMenu() { const c = MENU && MENU.ctx; MENU = null; if (c == 'banco' || c == 'pausa') G.mode = 'play'; }
const topoMenu = () => MENU && MENU.pilha[MENU.pilha.length - 1];
const emPreviaToque = () => { const t = topoMenu(); return !!(t && t.id == 'toque'); };
function acertarSel(t) { const T = TELAS[t.id](); if (T.itens) { let k = 0; while (T.itens[t.sel] && T.itens[t.sel].off && k++ < 20) t.sel = (t.sel + 1) % T.itens.length; } }
const simNao = v => v ? 'Sim' : 'Não';
const tempoTexto = s => { s = Math.max(0, s | 0); const h = Math.floor(s / 3600), m = Math.floor(s / 60) % 60; return h ? h + 'h' + String(m).padStart(2, '0') : m + ' min'; };
function resumoSalvo(s) { return s ? 'Era ' + (s.ri + 1) + ' · ' + s.era + ' · ' + tempoTexto(s.tempo) + (s.cronicas ? ' · Crônicas do Fim' : '') : 'Nenhum jogo salvo ainda'; }

// ---------------- as telas ----------------
const TELAS = {
  principal: () => ({
    itens: [
      { t: 'Novo jogo', f: novoJogo, dica: '' },
      { t: 'Continuar', off: !SALVO, f: continuarJogo, dica: resumoSalvo(SALVO) },
      { t: 'Opções', f: () => irMenu('opcoes') }
    ]
  }),
  modo: () => ({
    itens: [
      { t: 'Modo História', f: () => pedirNovo(false), dica: 'A jornada pelas eras, com marcos de descanso para voltar quando cair.' },
      { t: 'Crônicas do Fim', cron: true, f: () => pedirNovo(true), dica: 'Se você morrer, não há volta. Os chefes têm mais vida e cada golpe deles quebra duas lanternas.' },
      { t: 'Voltar', f: voltarMenu }
    ]
  }),
  confirmar: () => ({
    sub: 'Já existe um jogo salvo (' + resumoSalvo(SALVO) + '). Ele será substituído quando você salvar no marco de descanso.',
    itens: [{ t: 'Começar', f: () => comecar(MENU.novoCron) }, { t: 'Voltar', f: voltarMenu }]
  }),
  opcoes: () => ({
    titulo: 'Opções', grande: true,
    itens: [{ t: 'Vídeo', f: () => irMenu('video') }, { t: 'Som', f: () => irMenu('som') }, { t: 'Controles', f: () => irMenu('controles') }, { t: 'Botões de toque', f: () => irMenu('toque') }, { t: 'Voltar', f: voltarMenu }]
  }),
  video: () => ({
    titulo: 'Vídeo', grande: true, colValor: 430,
    itens: [
      { t: 'Tela cheia', valor: () => simNao(naTelaCheia()), mudar: () => { if (typeof window != 'undefined' && window.telaCheia) telaCheia(); }, dica: 'No iPhone: Compartilhar > Adicionar à Tela de Início.' },
      { t: 'Brilho', valor: () => OPC.brilho + '%', barra: () => (OPC.brilho - 50) / 100, mudar: d => { OPC.brilho = clamp(OPC.brilho + d * 10, 50, 150); salvarOpcoes(); } },
      { t: 'Limite de FPS', valor: () => OPC.fps ? OPC.fps + ' FPS' : 'Sem limite', mudar: d => { const l = [30, 60, 0], i = l.indexOf(OPC.fps); OPC.fps = l[(i + d + 3) % 3]; salvarOpcoes(); }, dica: '30 FPS gasta menos bateria no celular.' },
      { t: 'Mostrar FPS', valor: () => simNao(OPC.verFps), mudar: () => { OPC.verFps = !OPC.verFps; salvarOpcoes(); } },
      { t: 'Pixels nítidos', valor: () => simNao(OPC.nitido), mudar: () => { OPC.nitido = !OPC.nitido; salvarOpcoes(); }, dica: 'Não: a imagem fica mais suave quando a tela é ampliada.' },
      { t: 'Tremor da tela', valor: () => simNao(OPC.tremor), mudar: () => { OPC.tremor = !OPC.tremor; salvarOpcoes(); } },
      { t: 'Voltar', f: voltarMenu }
    ]
  }),
  som: () => ({
    titulo: 'Som', grande: true, colValor: 430,
    itens: [
      { t: 'Música', valor: () => OPC.musica + '%', barra: () => OPC.musica / 100, mudar: d => { OPC.musica = clamp(OPC.musica + d * 10, 0, 100); salvarOpcoes(); } },
      { t: 'Efeitos', valor: () => OPC.efeitos + '%', barra: () => OPC.efeitos / 100, mudar: d => { OPC.efeitos = clamp(OPC.efeitos + d * 10, 0, 100); salvarOpcoes(); typeof sfx == 'function' && sfx('acerto'); } },
      { t: 'Voltar', f: voltarMenu }
    ]
  }),
  controles: () => ({ especial: true, atualizar: updControles, desenhar: desenharControles }),
  toque: () => ({   // botões na tela do celular (enquanto esta tela está aberta, eles aparecem como prévia)
    titulo: 'Botões de toque', grande: true, colValor: 470,
    itens: [
      { t: 'Mostrar', valor: () => ({ auto: 'Automático', sempre: 'Sempre', nunca: 'Nunca' })[OPC.toque], mudar: d => { const l = ['auto', 'sempre', 'nunca'], i = l.indexOf(OPC.toque); OPC.toque = l[(i + d + 3) % 3]; salvarOpcoes(); }, dica: 'Automático: aparecem só em telas de toque (celular e tablet).' },
      { t: 'Transparência', valor: () => OPC.transp + '%', barra: () => OPC.transp / 80, mudar: d => { OPC.transp = clamp(OPC.transp + d * 10, 0, 80); salvarOpcoes(); }, dica: 'Deixa os botões mais transparentes para ver melhor o jogo por trás deles.' },
      { t: 'Voltar', f: voltarMenu }
    ]
  }),
  banco: () => ({
    titulo: 'Marco de descanso', sub: G.rm ? G.rm.E.n + ' · vida restaurada' : '',
    itens: [
      { t: 'Salvar jogo', f: () => salvarJogo() },
      { t: 'Opções', f: () => irMenu('opcoes') },
      { t: 'Salvar e sair', f: () => salvarJogo(voltarAoTitulo) },
      { t: 'Levantar', f: fecharMenu }
    ], voltar: fecharMenu
  }),
  pausa: () => ({
    titulo: 'Pausa', sub: G.rm ? G.rm.E.n + ' · ' + G.rm.E.y : '',
    itens: [{ t: 'Continuar', f: fecharMenu }, { t: 'Opções', f: () => irMenu('opcoes') }, { t: 'Sair para o início', f: () => irMenu('sair') }],
    voltar: fecharMenu
  }),
  sair: () => ({
    titulo: 'Sair para o início?', sub: 'O que você fez depois do último salvamento no marco de descanso será perdido.',
    itens: [{ t: 'Sair', f: voltarAoTitulo }, { t: 'Voltar', f: voltarMenu }]
  })
};
function novoJogo() { if (cronicasLiberadas()) irMenu('modo'); else pedirNovo(false); }
function pedirNovo(cron) { MENU.novoCron = cron; if (SALVO) irMenu('confirmar'); else comecar(cron); }
function comecar(cronicas) { MODO_CRONICAS = !!cronicas; MENU = null; newGame(); startGame(); }
function voltarAoTitulo() { MODO_CRONICAS = false; MENU = null; newGame(); lerSalvo().catch(() => { }); }
function abrirMarco() { rest(); G.ban.t = 0; G.mode = 'banco'; abrirMenu('banco', 'banco'); }
function abrirPausa() { G.mode = 'pausa'; abrirMenu('pausa', 'pausa'); }
function naTelaCheia() { try { return !!(document.fullscreenElement || document.webkitFullscreenElement); } catch (_) { return false; } }
function updTitulo() { if (!MENU || MENU.ctx != 'titulo') abrirMenu('titulo', 'principal'); updMenu(); }

// ---------------- atualizar e desenhar um menu de lista ----------------
const OK_TECLAS = ['Enter', 'Space', 'KeyE', 'KeyX'], VOLTA_TECLAS = ['Escape', 'KeyZ', 'Mouse2'];
function updMenu() {
  if (!MENU) return;
  if (ICONE) { pegarClique(); return; }                       // salvando ou carregando: espera terminar
  const topo = topoMenu(), T = TELAS[topo.id]();
  if (T.especial) return T.atualizar(topo, T);
  const it = T.itens, n = it.length;
  const mover = d => { let s = topo.sel; for (let k = 0; k < n; k++) { s = (s + d + n) % n; if (!it[s].off) break; } topo.sel = s; };
  if (kp('ArrowUp', 'KeyW', 'StickUp')) mover(-1);
  if (kp('ArrowDown', 'KeyS', 'StickDown')) mover(1);
  if (PONTEIRO.mexeu) { PONTEIRO.mexeu = false; if (topo.rects) for (const q of topo.rects) if (q.i != null && !q.d && dentro(PONTEIRO, q) && !it[q.i].off) topo.sel = q.i; }
  const cur = it[topo.sel];
  if (cur && cur.mudar && !cur.off) { if (kp('ArrowLeft', 'KeyA')) cur.mudar(-1); if (kp('ArrowRight', 'KeyD')) cur.mudar(1); }
  if (kp(...OK_TECLAS) && cur) return ativar(cur);
  if (kp(...VOLTA_TECLAS)) { if (T.voltar) return T.voltar(); if (MENU.pilha.length > 1) return voltarMenu(); }
  const c = pegarClique();
  if (c && topo.rects) for (const q of topo.rects) if (dentro(c, q)) {
    if (it[q.i].off) break; topo.sel = q.i;
    if (q.d) it[q.i].mudar(q.d); else ativar(it[q.i]); break;
  }
}
function ativar(i) { if (i.off) return; typeof sfx == 'function' && sfx('menu'); if (i.f) i.f(); else if (i.mudar) i.mudar(1); }

// vaga-lume que marca o item escolhido
function marcador(x, y) {
  const b = Math.sin(G.time * 4) * 1.5, a = .55 + .25 * Math.sin(G.time * 6);
  const gr = g.createRadialGradient(x, y + b, 1, x, y + b, 14); gr.addColorStop(0, 'rgba(220,255,140,' + a + ')'); gr.addColorStop(1, 'rgba(160,230,80,0)');
  g.fillStyle = gr; g.fillRect(x - 14, y + b - 14, 28, 28);
  g.fillStyle = '#f4ffc0'; g.fillRect(Math.round(x - 2), Math.round(y + b - 2), 4, 4);
}
function desenharMenu() {
  const topo = topoMenu(); if (!topo) return;
  const T = TELAS[topo.id](); topo.rects = [];
  if (T.especial) return T.desenhar(topo, T);
  const noTitulo = MENU.ctx == 'titulo', grande = !!T.grande;
  const x = 70, esc = 3, passo = grande ? 42 : 44;
  let y = grande ? 168 : noTitulo ? 368 : 300;
  if (T.titulo) { textoPixel(T.titulo.toUpperCase(), x - 6, grande ? 104 : y - 92, 4, COR_MENU.sel, 'left', true); }
  if (T.sub) { const ls = quebrarPixel(T.sub, 760, 2); ls.forEach((l, k) => textoPixel(l, x - 4, (grande ? 134 : y - 54) + k * 22, 2, COR_MENU.dica, 'left', true)); if (!T.titulo && ls.length > 1) y += 0; }
  T.itens.forEach((it, i) => {
    const sel = i == topo.sel && !it.off, cor = it.off ? COR_MENU.off : it.cron ? (sel ? COR_MENU.cronSel : COR_MENU.cron) : sel ? COR_MENU.sel : COR_MENU.normal;
    const xx = x + (sel ? 10 : 0);
    if (sel) marcador(x - 20, y - 12);
    const w = textoPixel(it.t.toUpperCase(), xx, y, esc, cor, 'left', true);
    topo.rects.push({ x: x - 34, y: y - 34, w: Math.max(w + 60, (T.colValor || 0) + (it.valor ? 280 : 0) - 0), h: passo, i });
    if (it.valor) {
      const vx = x + (T.colValor || 380), v = it.valor().toUpperCase(), vw = larguraPixel(v, esc);
      if (it.barra) {   // barrinha de valor (brilho, volume)
        const bx = vx + vw + 46, bw = 120, f = clamp(it.barra(), 0, 1);
        g.fillStyle = 'rgba(0,0,0,.55)'; g.fillRect(bx, y - 16, bw, 10); g.fillStyle = sel ? COR_MENU.valor : COR_MENU.normal; g.fillRect(bx + 2, y - 14, Math.round((bw - 4) * f), 6);
      }
      textoPixel(v, vx, y, esc, sel ? COR_MENU.valor : COR_MENU.normal, 'left', true);
      if (sel) { textoPixel('<', vx - 26, y, esc, COR_MENU.valor, 'left', true); textoPixel('>', vx + vw + 12, y, esc, COR_MENU.valor, 'left', true); }
      topo.rects.unshift({ x: vx - 40, y: y - 34, w: 40, h: passo, i, d: -1 }, { x: vx + vw, y: y - 34, w: 44, h: passo, i, d: 1 });
    }
    y += passo;
  });
  const cur = T.itens[topo.sel];
  if (cur && cur.dica) quebrarPixel(cur.dica, 820, 2).forEach((l, k) => textoPixel(l, x - 4, Math.min(VH - 22, y + 18) + k * 22, 2, COR_MENU.dica, 'left', true));
}

// ---------------- Opções > Controles: teclado e controle (gamepad) ----------------
function linhasControles() { return ACOES.length + 2; }
function updControles(topo) {
  topo.col = topo.col || 0;
  if (CAPTURA) { if (kp('Escape') || pegarClique()) CAPTURA = null; return; }
  const n = linhasControles();
  if (kp('ArrowUp', 'KeyW', 'StickUp')) topo.sel = (topo.sel + n - 1) % n;
  if (kp('ArrowDown', 'KeyS', 'StickDown')) topo.sel = (topo.sel + 1) % n;
  if (kp('ArrowLeft', 'KeyA', 'ArrowRight', 'KeyD')) topo.col = 1 - topo.col;
  if (PONTEIRO.mexeu) { PONTEIRO.mexeu = false; if (topo.rects) for (const q of topo.rects) if (dentro(PONTEIRO, q)) { topo.sel = q.i; if (q.col != null) topo.col = q.col; } }
  const escolher = () => {
    if (topo.sel < ACOES.length) { const a = ACOES[topo.sel]; CAPTURA = { tipo: topo.col ? 'botao' : 'tecla', acao: a.id, fim: () => { } }; if (topo.col) CONTROLE.ant = CONTROLE.ant.map(() => true); }
    else if (topo.sel == ACOES.length) restaurarControles();
    else voltarMenu();
  };
  if (kp(...OK_TECLAS)) return escolher();
  if (kp(...VOLTA_TECLAS)) return voltarMenu();
  const c = pegarClique();
  if (c && topo.rects) for (const q of topo.rects) if (dentro(c, q)) { topo.sel = q.i; if (q.col != null) topo.col = q.col; escolher(); break; }
}
function desenharControles(topo) {
  const x = 70, c1 = 330, c2 = 600, y0 = 146, passo = 22, esc = 2;
  topo.col = topo.col || 0;
  textoPixel('CONTROLES', x - 6, 92, 4, COR_MENU.sel, 'left', true);
  textoPixel('TECLADO', c1, 122, 2, COR_MENU.dica, 'left', true); textoPixel('CONTROLE', c2, 122, 2, COR_MENU.dica, 'left', true);
  const pisca = Math.floor(G.time * 3) % 2;
  for (let i = 0; i < linhasControles(); i++) {
    const y = y0 + i * passo + (i >= ACOES.length ? 10 : 0), sel = i == topo.sel;
    if (i < ACOES.length) {
      const a = ACOES[i], esperaT = CAPTURA && CAPTURA.acao == a.id;
      textoPixel(a.nome.toUpperCase(), x + (sel ? 8 : 0), y, esc, sel ? COR_MENU.sel : COR_MENU.normal, 'left', true);
      const tt = esperaT && CAPTURA.tipo == 'tecla' ? (pisca ? 'APERTE UMA TECLA' : '') : teclasDe(a).slice(0, 2).map(nomeTecla).join(' / ').toUpperCase();
      const tb = esperaT && CAPTURA.tipo == 'botao' ? (pisca ? 'APERTE UM BOTÃO' : '') : nomeBotao(botaoDe(a)).toUpperCase();
      textoPixel(tt || ' ', c1, y, esc, sel && topo.col == 0 ? COR_MENU.valor : COR_MENU.normal, 'left', true);
      textoPixel(tb || ' ', c2, y, esc, sel && topo.col == 1 ? COR_MENU.valor : COR_MENU.normal, 'left', true);
      if (sel) marcador((topo.col ? c2 : c1) - 16, y - 8);
      topo.rects.push({ x: c1 - 20, y: y - 20, w: c2 - c1, h: passo, i, col: 0 }, { x: c2 - 20, y: y - 20, w: 300, h: passo, i, col: 1 }, { x: x - 30, y: y - 20, w: c1 - x, h: passo, i });
    } else {
      const t = i == ACOES.length ? 'Restaurar padrão' : 'Voltar';
      if (sel) marcador(x - 16, y - 8);
      textoPixel(t.toUpperCase(), x + (sel ? 8 : 0), y, esc, sel ? COR_MENU.sel : COR_MENU.normal, 'left', true);
      topo.rects.push({ x: x - 30, y: y - 20, w: 360, h: passo, i });
    }
  }
  const st = CONTROLE.nome ? 'Controle conectado: ' + CONTROLE.nome.replace(/\s*\(.*$/, '').slice(0, 44) : 'Nenhum controle conectado. Conecte um e aperte qualquer botão.';
  textoPixel(st, x - 4, VH - 38, 2, CONTROLE.nome ? '#b8e07a' : COR_MENU.dica, 'left', true);
  textoPixel(CAPTURA ? 'Esc: cancelar' : 'Enter: trocar   ·   ←→: teclado ou controle   ·   Esc: voltar', x - 4, VH - 16, 2, COR_MENU.dica, 'left', true);
}

// ---------------- cena animada da tela de título ----------------
const VAGALUMES = []; for (let i = 0; i < 38; i++) VAGALUMES.push({ x: Math.random() * VW, y: 60 + Math.random() * 440, ph: Math.random() * 7, v: .3 + Math.random() * .6, r: 10 + Math.random() * 26 });
function imgTitulo(n) { const T = INTERFACE && INTERFACE.titulo; if (!T) return null; const im = carregarImagem(T.pasta + n); return imagemPronta(im) ? im : null; }
function desenharCenaTitulo(escurecer) {
  const T = INTERFACE && INTERFACE.titulo, cena = T && imgTitulo(T.cena), e = T ? T.escala : 2, t = G.time;
  if (cena) { g.save(); g.imageSmoothingEnabled = false; g.drawImage(cena, 0, 0, cena.naturalWidth * e, cena.naturalHeight * e); g.restore(); }
  else { const gr = g.createLinearGradient(0, 0, 0, VH); gr.addColorStop(0, '#0b1a12'); gr.addColorStop(1, '#030504'); g.fillStyle = gr; g.fillRect(0, 0, VW, VH); }
  g.save(); g.globalCompositeOperation = 'lighter';
  if (T) {
    // feixes de luz respirando
    T.feixes.forEach((f, k) => {
      const [x0, larg, ang, forca] = f, dx = Math.sin(ang), dy = Math.cos(ang), xb = x0 + VH / e / dy * dx, a = (.025 + .022 * Math.sin(t * .6 + k * 1.7)) * forca * 2;
      const gr = g.createLinearGradient(0, 0, 0, VH); gr.addColorStop(0, 'rgba(210,240,150,0)'); gr.addColorStop(.35, 'rgba(210,240,150,' + a + ')'); gr.addColorStop(1, 'rgba(210,240,150,' + a * .6 + ')');
      g.fillStyle = gr; g.beginPath(); g.moveTo((x0 - larg * .7) * e, 0); g.lineTo((x0 + larg * .7) * e, 0); g.lineTo((xb + larg * .7) * e, VH); g.lineTo((xb - larg * .7) * e, VH); g.closePath(); g.fill();
    });
    // brilho fraco lá dentro da porta e a areia da ampulheta no disco
    const [px, py] = T.porta, [dx2, dy2] = T.disco;
    let gr = g.createRadialGradient(px * e, (py - 10) * e, 2, px * e, (py - 10) * e, 70);
    gr.addColorStop(0, 'rgba(120,200,170,' + (.07 + .04 * Math.sin(t * 1.3)) + ')'); gr.addColorStop(1, 'rgba(60,120,100,0)'); g.fillStyle = gr; g.fillRect(px * e - 70, (py - 10) * e - 70, 140, 140);
    gr = g.createRadialGradient(dx2 * e, (dy2 + 4) * e, 1, dx2 * e, (dy2 + 4) * e, 26);
    gr.addColorStop(0, 'rgba(255,200,90,' + (.28 + .12 * Math.sin(t * 2.2)) + ')'); gr.addColorStop(1, 'rgba(255,160,60,0)'); g.fillStyle = gr; g.fillRect(dx2 * e - 26, (dy2 + 4) * e - 26, 52, 52);
  }
  // vaga-lumes
  for (const v of VAGALUMES) {
    const x = (v.x + Math.sin(t * v.v + v.ph) * v.r + t * 6) % (VW + 40) - 20, y = v.y + Math.cos(t * v.v * 1.3 + v.ph) * v.r * .6;
    const a = Math.max(0, Math.sin(t * (1 + v.v) + v.ph * 3)) * .8;
    if (a < .05) continue;
    const gr = g.createRadialGradient(x, y, 0, x, y, 9); gr.addColorStop(0, 'rgba(210,255,120,' + a * .5 + ')'); gr.addColorStop(1, 'rgba(160,230,60,0)');
    g.fillStyle = gr; g.fillRect(x - 9, y - 9, 18, 18); g.fillStyle = 'rgba(240,255,190,' + a + ')'; g.fillRect(Math.round(x) - 1, Math.round(y) - 1, 2, 2);
  }
  g.restore();
  // Hallokin parado na frente do portal
  const P = PERSONAGEM, folha = P && carregarImagem(P.pasta + P.arquivo);
  if (T && P && imagemPronta(folha)) {
    const A = P.anim.parado, q = A.quadros[Math.floor(t * A.fps) % A.quadros.length], [cw, ch] = P.quadro, [hx, hy] = T.heroi, k = P.escala;
    g.fillStyle = 'rgba(0,0,0,.35)'; g.beginPath(); g.ellipse(hx * e, hy * e + 1, 13, 4, 0, 0, 7); g.fill();
    g.save(); g.imageSmoothingEnabled = false;
    g.drawImage(folha, q * cw, A.linha * ch, cw, ch, Math.round(hx * e - P.pes[0] * k), Math.round(hy * e - P.pes[1] * k), cw * k, ch * k); g.restore();
  }
  // escurece o lado esquerdo (onde ficam o nome e o menu)
  const gr = g.createLinearGradient(0, 0, 560, 0); gr.addColorStop(0, 'rgba(0,0,0,' + (escurecer ? .78 : .5) + ')'); gr.addColorStop(1, 'rgba(0,0,0,' + (escurecer ? .45 : 0) + ')');
  g.fillStyle = gr; g.fillRect(0, 0, VW, VH);
}
function drawTitle() {
  const topo = topoMenu(), opcoes = topo && ['opcoes', 'video', 'som', 'controles', 'toque'].includes(topo.id);
  desenharCenaTitulo(opcoes);
  const T = INTERFACE && INTERFACE.titulo, logo = T && imgTitulo(T.logo);
  if (!opcoes) {
    if (logo) { g.save(); g.imageSmoothingEnabled = false; g.drawImage(logo, T.logoPos[0] * T.escala, T.logoPos[1] * T.escala, logo.naturalWidth * T.logoEscala, logo.naturalHeight * T.logoEscala); g.restore(); }
    else textoPixel('RELÍQUIAS DAS ERAS', 60, 140, 5, '#f4f1e6', 'left', true);
  }
  desenharMenu();
}
// fundo dos menus dentro do jogo (marco de descanso e pausa): o jogo parado e escurecido
function desenharFundoMenu() {
  const topo = topoMenu(), opcoes = topo && ['opcoes', 'video', 'som', 'controles', 'toque'].includes(topo.id);
  const gr = g.createLinearGradient(0, 0, VW, 0); gr.addColorStop(0, 'rgba(2,5,3,.9)'); gr.addColorStop(.55, 'rgba(2,5,3,' + (opcoes ? .82 : .55) + ')'); gr.addColorStop(1, 'rgba(2,5,3,' + (opcoes ? .7 : .25) + ')');
  g.fillStyle = gr; g.fillRect(0, 0, VW, VH);
}
