// ===== Loja do mercador e Diário dos Monstros =====
// Cada fase tem um mercador ao lado do marco de descanso. As espadas só são compradas aqui, com as moedas
// que os monstros deixam; cada espada aparece na loja a partir da época em que foi inventada.
// O Diário (também vendido pelo mercador) mostra os monstros e chefes que você já derrotou.

const PRECO_DIARIO = 30;
// época (pelo nome, em js/dados.js) a partir da qual cada espada é vendida
const ESPADA_ERA = [null, 'Neolítico', 'Idade dos Metais', 'Expansão Islâmica', 'Grandes Navegações', 'Revoluções Industriais', 'Primeira Guerra Mundial'];
const eraDaEspada = t => { const n = ESPADA_ERA[t]; if (!n) return 0; const i = ERAS.findIndex(e => e.n == n); return i < 0 ? 0 : i; };
const maiorEra = () => { let m = 0; for (const k in G.vis) if (G.vis[k]) m = Math.max(m, +k); return m; };

// clique/toque na tela do jogo (em coordenadas do jogo, 960x540); usado pela loja, pelo diário e pelos menus
let CLIQUE = null;
if (cv.addEventListener) cv.addEventListener('pointerdown', e => {
  const r = cv.getBoundingClientRect(); CLIQUE = { x: (e.clientX - r.left) * VW / r.width, y: (e.clientY - r.top) * VH / r.height };
});
function pegarClique() { const c = CLIQUE; CLIQUE = null; return c; }
const dentro = (c, q) => c && c.x >= q.x && c.x < q.x + q.w && c.y >= q.y && c.y < q.y + q.h;

// ---------------- loja ----------------
function itensLoja() { const a = []; for (let t = 1; t < SW.length; t++) a.push({ tipo: 'espada', t }); a.push({ tipo: 'diario' }); return a; }
function estadoItem(it) {
  if (it.tipo == 'diario') return G.diario ? { feito: 1, txt: 'Comprado' } : { preco: PRECO_DIARIO };
  const t = it.t, era = eraDaEspada(t);
  if (p.wp >= t) return { feito: 1, txt: p.wp == t ? 'Em uso' : 'Já tem melhor' };
  if (maiorEra() < era) return { bloq: 1, txt: 'Época: ' + ERAS[era].n };
  return { preco: SW[t].preco };
}
function abrirLoja() {
  G.mode = 'loja'; G.loja = { sel: 0, msg: 'Lâminas de todas as eras, viajante. O que vai levar?', rects: [] };
  const k = itensLoja().findIndex(i => estadoItem(i).preco != null); if (k >= 0) G.loja.sel = k;
  pegarClique();
}
function fecharLoja() { G.mode = 'play'; G.loja = null; }
function comprar(it) {
  const e = estadoItem(it), L = G.loja;
  if (e.feito || e.bloq) { L.msg = it.tipo == 'espada' && e.bloq ? 'Essa lâmina ainda não foi inventada. Ela chega na época: ' + ERAS[eraDaEspada(it.t)].n + '.' : (e.feito && it.tipo == 'espada' ? 'Você já tem essa lâmina (ou uma melhor).' : 'Você já tem o Diário.'); return; }
  if (G.coins < e.preco) { L.msg = 'Faltam ' + (e.preco - G.coins) + ' moedas. Os monstros deixam moedas quando são derrotados.'; return; }
  G.coins -= e.preco; typeof sfx == 'function' && sfx('acerto');
  if (it.tipo == 'diario') { G.diario = 1; L.msg = 'O Diário dos Monstros é seu. Abra com B ou com o botão Diário.'; }
  else { p.wp = it.t; L.msg = SW[it.t].n + ': ' + SW[it.t].t; }
}
function updLoja() {
  const L = G.loja, it = itensLoja();
  if (kp('ArrowUp', 'KeyW', 'StickUp')) L.sel = (L.sel + it.length - 1) % it.length;
  if (kp('ArrowDown', 'KeyS', 'StickDown')) L.sel = (L.sel + 1) % it.length;
  if (kp('Escape', 'KeyM', 'KeyQ', 'KeyZ', 'Mouse2')) return fecharLoja();
  if (kp('KeyE', 'Enter', 'Space', 'KeyX', 'KeyJ')) comprar(it[L.sel]);
  const c = pegarClique();
  if (c) for (const q of L.rects) if (dentro(c, q)) { if (q.sair) return fecharLoja(); if (L.sel == q.i) comprar(it[q.i]); else L.sel = q.i; break; }
}
function iconeEspada(t, x, y, esc) {
  const im = carregarImagem(INTERFACE.pasta + 'espadas.png'); if (!imagemPronta(im)) return;
  g.save(); g.imageSmoothingEnabled = false; g.drawImage(im, 0, t * 9, 38, 9, Math.round(x), Math.round(y), Math.round(38 * esc), Math.round(9 * esc)); g.restore();
}
function moedaTexto(n, x, y, cor) {   // "120 (moeda)" alinhado à direita em x
  g.textAlign = 'right'; g.fillStyle = cor; g.fillText(String(n), x - 22, y);
  if (!obj('moeda_runica', x - 9, y + 5, 1.2)) diamond(x - 9, y - 5, 6, '#e8c050');
}
function desenharLoja() {
  const L = G.loja, it = itensLoja(); L.rects = [];
  g.fillStyle = 'rgba(0,0,0,.6)'; g.fillRect(0, 0, VW, VH);
  const x = 110, y = 34, w = 740, h = 472, cx2 = caixaPergaminho(x, y, w, h, .42);
  if (!cx2) { caixaPreta(x, y, w, h, .95); g.strokeStyle = 'rgba(232,228,216,.4)'; g.strokeRect(x + .5, y + .5, w, h); }
  const tinta = cx2 ? corTinta('tinta') : '#f2eee2', tit = cx2 ? corTinta('titulo') : '#ffd28a', fraca = cx2 ? corTinta('fraca') : 'rgba(232,228,216,.6)';
  // vendedor e moedas
  obj('mercador', x + 120, y + 196, 3);
  g.textAlign = 'center'; g.font = 'italic 24px Georgia,serif'; g.fillStyle = tit; g.fillText('Mercador do Tempo', x + 120, y + 236);
  g.font = '15px Georgia,serif'; g.fillStyle = tinta; g.fillText('Suas moedas', x + 120, y + 270);
  g.font = 'bold 22px Georgia,serif'; moedaTexto(G.coins, x + 160, y + 300, tinta);
  // lista
  const lx = x + 238, lw = w - 290; let ly = y + 58;
  g.textAlign = 'left'; g.font = 'italic 15px Georgia,serif'; g.fillStyle = fraca; g.fillText('Lâminas e livros', lx, ly - 18);
  it.forEach((item, i) => {
    const e = estadoItem(item), rh = 42, sel = i == L.sel;
    L.rects.push({ x: lx - 8, y: ly, w: lw + 16, h: rh - 2, i });
    if (sel) { g.fillStyle = 'rgba(110,36,20,.16)'; g.fillRect(lx - 8, ly, lw + 16, rh - 2); g.fillStyle = tit; g.fillRect(lx - 8, ly, 3, rh - 2); }
    g.globalAlpha = e.bloq ? .45 : 1;
    if (item.tipo == 'espada') iconeEspada(item.t, lx, ly + 13, 1.6); else obj('diario', lx + 30, ly + 34, 2);
    g.textAlign = 'left'; g.font = (sel ? 'bold ' : '') + '16px Georgia,serif'; g.fillStyle = tinta;
    g.fillText(item.tipo == 'espada' ? SW[item.t].n : 'Diário dos Monstros', lx + 72, ly + 18);
    g.font = '12px Georgia,serif'; g.fillStyle = fraca;
    g.fillText(item.tipo == 'espada' ? 'alcance ' + SW[item.t].r + '  ·  dano ' + SW[item.t].d : 'registra os monstros e chefes que você derrota', lx + 72, ly + 34);
    g.font = '15px Georgia,serif';
    if (e.preco != null) moedaTexto(e.preco, lx + lw, ly + 25, G.coins >= e.preco ? tinta : '#9a2a1a');
    else { g.textAlign = 'right'; g.fillStyle = e.feito ? '#2f6a2a' : fraca; g.font = 'italic 13px Georgia,serif'; g.fillText(e.txt, lx + lw, ly + 25); }
    g.globalAlpha = 1; ly += rh;
  });
  // fala do mercador
  g.font = 'italic 15px Georgia,serif'; g.textAlign = 'left'; g.fillStyle = tinta;
  wrap(L.msg, lw + 10).slice(0, 3).forEach((l, k) => g.fillText(l, lx, y + 372 + k * 20));
  // rodapé
  g.font = '13px sans-serif'; g.fillStyle = fraca; g.textAlign = 'left';
  g.fillText('↑↓ escolher · E comprar · Esc sair   (no toque: toque para escolher, toque de novo para comprar)', x + 44, y + h - 40);
  const bs = { x: x + w - 128, y: y + h - 66, w: 84, h: 34, sair: 1 }; L.rects.push(bs);
  g.fillStyle = 'rgba(70,24,14,.85)'; g.fillRect(bs.x, bs.y, bs.w, bs.h); g.strokeStyle = 'rgba(240,220,180,.8)'; g.lineWidth = 1.5; g.strokeRect(bs.x + .5, bs.y + .5, bs.w - 1, bs.h - 1);
  g.fillStyle = '#f4ead8'; g.textAlign = 'center'; g.font = '16px Georgia,serif'; g.fillText('Sair', bs.x + bs.w / 2, bs.y + 23);
}

// ---------------- Diário dos Monstros ----------------
// chave de cada inimigo derrotado: tipo/tema do monstro, ajudante de chefe ou o próprio chefe
function chaveMonstro(e) {
  if (e.k == 'B') return 'chefe_' + e.id;
  if (e.arte) return 'ajud_' + e.arte.nome;
  return e.tema || e.k;
}
function registrarMorte(e) { if (e.k == 'rot') return; const k = chaveMonstro(e); G.mortos[k] = (G.mortos[k] || 0) + 1; }
const AJUDANTES = {
  ajud_morcego: { nome: 'Morcego do Abismo', id: 'espectro', arte: 'morcego', texto: 'Voam do porão do navio fantasma quando o Espectro da Caravela se enfurece.' },
  ajud_drone: { nome: 'Drone da Enigma', id: 'enigma', arte: 'drone', texto: 'Pequenos vigias que a Máquina Enigma solta pela casamata. Explodem com um golpe.' }
};
function entradasDiario() {
  const a = [];
  for (const k in MONSTROS) { const M = MONSTROS[k]; if (!M || !M.anim) continue; a.push({ k, nome: M.nome, texto: M.texto || '', monstro: M }); }
  for (const k in AJUDANTES) a.push(Object.assign({ k }, AJUDANTES[k]));
  for (const i in CHEFES) { const c = CHEFES[i]; a.push({ k: 'chefe_' + c.id, nome: c.nome, texto: (c.texto || '') + ' (Guardião de ' + ERAS[i].n + ')', chefe: c.id }); }
  return a;
}
function abrirDiario() {
  if (!G.diario) { toast('Você ainda não tem o Diário — compre com o mercador', 2.4); return; }
  G.mode = 'diario'; G.diarioSel = G.diarioSel || 0; pegarClique();
}
function updDiario() {
  const lista = entradasDiario(), n = lista.length, COL = 5;
  let s = G.diarioSel || 0;
  if (kp('ArrowLeft', 'KeyA')) s = (s + n - 1) % n;
  if (kp('ArrowRight', 'KeyD')) s = (s + 1) % n;
  if (kp('ArrowUp', 'KeyW', 'StickUp')) s = (s - COL + n) % n;
  if (kp('ArrowDown', 'KeyS', 'StickDown')) s = (s + COL) % n;
  G.diarioSel = s;
  if (kp('Escape', 'KeyB', 'KeyM', 'KeyZ', 'KeyE', 'Enter', 'Mouse2')) { G.mode = 'play'; return; }
  const c = pegarClique();
  if (c && G.diarioRects) { for (const q of G.diarioRects) if (dentro(c, q)) { if (q.sair) { G.mode = 'play'; return; } G.diarioSel = q.i; } }
}
// desenha um monstro/chefe dentro de uma caixa (centro cx, base by), cabendo em mw x mh; silhueta se ainda não derrotou
const SILHUETAS = {};
function figuraDiario(en, cx, by, mw, mh, conhecido) {
  let im = null, sx = 0, sy = 0, sw = 0, sh = 0, ax = 0, ay = 0;
  if (en.monstro) { const M = en.monstro; im = carregarImagem(MONSTROS.pasta + M.pasta + M.anim.parado[0]); if (M.diario) { [sx, sy, sw, sh] = M.diario; } else { [sw, sh] = M.quadro; } ax = sw / 2; ay = sh; }
  else if (en.arte) { const t = tiraChefe(en.id, 'extra', en.arte); if (t) { im = t.im; [sw, sh] = t.info.quadro; [ax, ay] = t.info.ponto; ay = sh; } }
  else if (en.chefe) { const A = arteChefe(en.chefe); if (A && A.retrato) { im = carregarImagem(CHEFES_ARTE.pasta + en.chefe + '/' + A.retrato); if (imagemPronta(im)) { sw = im.naturalWidth; sh = im.naturalHeight; ax = sw / 2; ay = sh; } } }
  if (!im || !imagemPronta(im) || !sw) return;
  const k = Math.min(mw / sw, mh / sh, en.monstro ? 2.5 : 1.4);
  let fonte = im;
  if (!conhecido) {   // silhueta preta (feita uma vez e guardada)
    if (!SILHUETAS[en.k]) { const c = document.createElement('canvas'); c.width = sw; c.height = sh; const x = c.getContext('2d'); x.drawImage(im, sx, sy, sw, sh, 0, 0, sw, sh); x.globalCompositeOperation = 'source-in'; x.fillStyle = '#1a1210'; x.fillRect(0, 0, sw, sh); SILHUETAS[en.k] = c; }
    fonte = SILHUETAS[en.k]; sx = sy = 0;
  }
  g.save(); g.imageSmoothingEnabled = !!en.chefe;
  g.drawImage(fonte, sx, sy, sw, sh, Math.round(cx - ax * k), Math.round(by - ay * k), Math.round(sw * k), Math.round(sh * k));
  g.restore();
}
function desenharDiario() {
  const lista = entradasDiario(), COL = 5, sel = G.diarioSel || 0; G.diarioRects = [];
  g.fillStyle = 'rgba(0,0,0,.65)'; g.fillRect(0, 0, VW, VH);
  const x = 40, y = 20, w = 880, h = 500, cx2 = caixaPergaminho(x, y, w, h, .42);
  if (!cx2) caixaPreta(x, y, w, h, .95);
  const tinta = cx2 ? corTinta('tinta') : '#f2eee2', tit = cx2 ? corTinta('titulo') : '#ffd28a', fraca = cx2 ? corTinta('fraca') : 'rgba(232,228,216,.6)';
  const conhecidos = lista.filter(en => G.mortos[en.k]).length;
  g.textAlign = 'center'; g.font = 'italic 26px Georgia,serif'; g.fillStyle = tit; g.fillText('Diário dos Monstros', VW / 2, y + 62);
  g.font = '13px Georgia,serif'; g.fillStyle = fraca; g.fillText('Registrados: ' + conhecidos + ' de ' + lista.length, VW / 2, y + 82);
  const cw = 150, ch = 92, gx = VW / 2 - COL * cw / 2, gy = y + 94;
  lista.forEach((en, i) => {
    const c = i % COL, r = Math.floor(i / COL), cx = gx + c * cw + cw / 2, cy = gy + r * ch, n = G.mortos[en.k] || 0;
    G.diarioRects.push({ x: cx - cw / 2, y: cy, w: cw, h: ch, i });
    if (i == sel) { g.fillStyle = 'rgba(110,36,20,.15)'; g.fillRect(cx - cw / 2 + 4, cy + 2, cw - 8, ch - 4); g.strokeStyle = tit; g.lineWidth = 1.5; g.strokeRect(cx - cw / 2 + 4.5, cy + 2.5, cw - 9, ch - 5); }
    figuraDiario(en, cx, cy + 58, 120, 52, n > 0);
    g.textAlign = 'center'; g.font = (en.chefe ? 'italic bold ' : '') + '12px Georgia,serif'; g.fillStyle = n ? tinta : fraca;
    g.fillText(n ? en.nome : '???', cx, cy + 74);
    if (n) { g.font = '11px Georgia,serif'; g.fillStyle = fraca; g.fillText('derrotados: ' + n, cx, cy + 87); }
  });
  // descrição do escolhido
  const en = lista[sel], n = G.mortos[en.k] || 0, dy = gy + Math.ceil(lista.length / COL) * ch + 8;
  g.textAlign = 'left'; g.font = 'italic 17px Georgia,serif'; g.fillStyle = tit; g.fillText(n ? en.nome : 'Ainda não derrotado', x + 70, dy + 14);
  g.font = '14px Georgia,serif'; g.fillStyle = tinta;
  wrap(n ? en.texto : 'Derrote este inimigo para registrá-lo no diário.', w - 300).slice(0, 2).forEach((l, k) => g.fillText(l, x + 70, dy + 36 + k * 19));
  const bs = { x: x + w - 150, y: dy - 4, w: 84, h: 34, sair: 1 }; G.diarioRects.push(bs);
  g.fillStyle = 'rgba(70,24,14,.85)'; g.fillRect(bs.x, bs.y, bs.w, bs.h); g.strokeStyle = 'rgba(240,220,180,.8)'; g.lineWidth = 1.5; g.strokeRect(bs.x + .5, bs.y + .5, bs.w - 1, bs.h - 1);
  g.fillStyle = '#f4ead8'; g.textAlign = 'center'; g.font = '16px Georgia,serif'; g.fillText('Fechar', bs.x + bs.w / 2, bs.y + 23);
}
