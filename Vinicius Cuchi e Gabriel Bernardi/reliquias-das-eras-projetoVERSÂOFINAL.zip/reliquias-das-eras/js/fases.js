// ===== Fases =====
// Cada época é uma fase longa: uma área inicial (runa, marco de descanso, item) e depois
// TRECHOS de desafio em sequência, cada um fechado por um portão. Os tipos de trecho
// estão em js/trechos.js; os chefes em js/chefes.js.

const INTRO = 14;   // largura (em blocos) da área inicial

// trechos de cada época, em ordem (o último fecha a fase). 'tipo:V' escolhe a variante do desenho
// (A, B ou C — veja js/trechos.js). Sem letra = variante A. Cada época tem uma combinação própria.
const PLANO = [
  /* 0 Paleolítico  */ ['saltos:A', 'guardioes:A', 'alavancas:A'],
  /* 1 Neolítico    */ ['fragmentos:A', 'saltos:B', 'guardioes:B'],
  /* 2 Metais       */ ['saltos:C', 'espinhos:A', 'alavancas:B'],
  /* 3 Escrita      */ ['arena:A', 'fragmentos:B', 'espinhos:B'],
  /* 4 Nilo         */ ['saltos:B', 'alavancas:A', 'guardioes:C'],
  /* 5 Grécia       */ ['escalada:A', 'fragmentos:A', 'arena:B'],
  /* 6 Roma         */ ['espinhos:C', 'chefe'],
  /* 7 Feudalismo   */ ['guardioes:B', 'escalada:B', 'alavancas:B'],
  /* 8 Islâmica     */ ['corrida:A', 'fragmentos:B', 'espinhos:A'],
  /* 9 Cruzadas     */ ['arena:C', 'saltos:C', 'escalada:A'],
  /* 10 Peste       */ ['espinhos:B', 'guardioes:A', 'fragmentos:A'],
  /* 11 Constantin. */ ['escalada:B', 'saltos:A', 'arena:A'],
  /* 12 Renascimento*/ ['alavancas:A', 'escalada:A', 'corrida:B'],
  /* 13 Navegações  */ ['saltos:B', 'chefe'],
  /* 14 Br. Colonial*/ ['fragmentos:A', 'saltos:C', 'alavancas:B'],
  /* 15 Reforma     */ ['fragmentos:B', 'espinhos:C', 'escalada:B'],
  /* 16 Absolutismo */ ['corrida:B', 'arena:B', 'alavancas:B'],
  /* 17 Iluminismo  */ ['escuro:A', 'escalada:A', 'fragmentos:A'],
  /* 18 Rev. Franc. */ ['arena:C', 'espinhos:B', 'corrida:A'],
  /* 19 Napoleônica */ ['guardioes:C', 'escuro:B', 'saltos:C'],
  /* 20 Independênc.*/ ['escalada:B', 'corrida:B', 'fragmentos:B'],
  /* 21 Br. Imperial*/ ['corrida:B', 'guardioes:A', 'escalada:B'],
  /* 22 Industrial  */ ['corrida:A', 'chefe'],
  /* 23 Primavera   */ ['arena:B', 'escuro:A', 'alavancas:A'],
  /* 24 Neocolonial */ ['saltos:B', 'espinhos:C', 'escalada:A'],
  /* 25 1ª Guerra   */ ['escuro:B', 'guardioes:B', 'corrida:B'],
  /* 26 Rev. Russa  */ ['escalada:B', 'arena:C', 'espinhos:A'],
  /* 27 Crise 1929  */ ['corrida:A', 'escuro:B', 'fragmentos:A'],
  /* 28 Totalitarism.*/ ['arena:A', 'espinhos:B', 'escalada:A'],
  /* 29 2ª Guerra   */ ['escuro:A', 'chefe']
];

// ---------- ajudantes de construção (medidas em blocos de 32 px) ----------
function chao(R, a, b) { if (b > a) { R.rects.push([a, FY, b - a, 3]); R.segs.push([a, b - a]); } }
function fosso(R, a, b) { R.haz.push([a, 17, b - a, 1]); }
function plataforma(R, x, y, w) { const r = [x, y, w, 1, 1]; R.rects.push(r); return r; }
function bloco(R, x, y, w, h) { const r = [x, y, w, h]; R.rects.push(r); return r; }
function inimigo(R, k, x, yBloco, sec, piso) {   // x em blocos; yBloco = linha (voadores) ou null = no chão (piso = linha do chão, padrão 15)
  const y = yBloco == null ? (piso || FY) * T - 26 : yBloco * T;
  R.ens.push({ k, x: x * T, y, sec, hp: k == 'f' ? Math.max(2, R.hpBase - 1) : R.hpBase });
}
function estaca(R, xBloco, yBloco, sec) { R.spk.push({ x: xBloco * T - 14, y: yBloco * T - 14, w: 28, h: 28, sec }); }
// peças que se mexem (vão e voltam em senoide). per = segundos por volta (use 2 ou 4), fase = 0..1
function movel(R, x, y, w, ax, ay, per, fase) {   // plataforma flutuante (dá para subir por baixo)
  R.mov.push({ x0: x * T, y0: y * T, w: w * T, ax: ax * T, ay: ay * T, per, fase, x: x * T, y: y * T });
}
function estacaMovel(R, xBloco, yBloco, ax, ay, per, fase, sec) {
  R.spk.push({ x: xBloco * T - 14, y: yBloco * T - 14, w: 28, h: 28, sec, mov: { cx: xBloco * T, cy: yBloco * T, ax: ax * T, ay: ay * T, per, fase } });
}
// posição das peças móveis no tempo R.tm (o tempo da fase só anda durante o jogo)
function posicionarMoveis(R) {
  const t = R.tm || 0, onda = (per, fase) => Math.sin(2 * Math.PI * (t / per + fase));
  for (const m of R.mov) { const a = onda(m.per, m.fase); m.x = m.x0 + m.ax * a; m.y = m.y0 + m.ay * a; }
  for (const s of R.spk) if (s.mov) { const a = onda(s.mov.per, s.mov.fase); s.x = s.mov.cx + s.mov.ax * a - 14; s.y = s.mov.cy + s.mov.ay * a - 14; }
}
// avança o tempo e leva junto o jogador que está em cima de uma plataforma móvel
function atualizarMoveis(R, dt) {
  if (!R.mov.length && !R.spk.some(s => s.mov)) return;
  const antes = R.mov.map(m => [m.x, m.y]);
  R.tm = (R.tm || 0) + dt; posicionarMoveis(R);
  R.mov.forEach((m, j) => {
    const [ox, oy] = antes[j];
    if (p.g && p.vy >= 0 && Math.abs(p.y + p.h - oy) < 2 && p.x + p.w > ox && p.x < ox + m.w) {
      mv(p, m.x - ox, 0, G.S || []); p.y = m.y - p.h;
    }
  });
}
function sobreMovel(R, x, y) { return R.mov.some(m => x >= m.x && x < m.x + m.w && y >= m.y && y < m.y + 16); }

function genRoom(i) {
  const E = ERAS[i], rnd = mul(i * 7919 + 101), plano = PLANO[i];
  const R = { i, E, rects: [], haz: [], spk: [], segs: [], secs: [], ens: [], excl: [], hpBase: 2 + Math.floor(i / 6),
    boss: !!CHEFES[i], es: [], pr: [], lock: false, lockX: 0, mov: [], tm: 0 };
  // área inicial
  chao(R, 0, INTRO);
  R.rune = { x: 4 * T + 16, y: FY * T };
  R.bench = { x: 7 * T + 16, y: FY * T };
  plataforma(R, 1, 12, 3); R.extra = { x: 2.5 * T, y: 12 * T };
  if (ABIL[i]) R.alt = { x: 12.9 * T, y: FY * T, a: ABIL[i] };
  R.loja = { x: 9.8 * T, y: FY * T };                // mercador (espadas e diário — js/loja.js)
  // trechos
  let x = INTRO;
  plano.forEach((nome, k) => {
    const [tipo, v] = nome.split(':');                 // 'saltos:B' = tipo saltos, variante B
    const sec = TRECHOS[tipo].gerar(R, x, rnd, k, v || 'A');
    sec.t = tipo; sec.v = v || 'A'; sec.k = k; sec.x0 = x; sec.gx = (sec.x1 - 2) * T; sec.ult = k == plano.length - 1;
    R.secs.push(sec); x = sec.x1;
  });
  R.W = x + 4; chao(R, x, R.W);
  R.rects.unshift([0, 0, R.W, 2]);            // teto
  R.gx = R.secs[R.secs.length - 1].gx;        // portão de saída
  R.sol = R.rects.map(r => [r[0] * T, r[1] * T, r[2] * T, r[3] * T, r[4] || 0]);
  R.excl.push(R.rune.x, R.extra.x, R.bench.x, R.alt ? R.alt.x : -999, R.loja.x, R.loja.x - T, R.loja.x + T, 1.2 * T);
  R.secs.forEach(s => R.excl.push(s.gx, s.gx + T, s.gx - T));
  return R;
}

// ---------- estado de cada trecho (fica salvo em G.RS[era].sec) ----------
function estT(k) {
  const S = G.rm.st; S.sec = S.sec || [];
  return S.sec[k] || (S.sec[k] = { done: 0, aberto: 0, gate: 0, on: [], sh: [], lit: [], wave: -1, tm: 0, visto: 0 });
}
function trechoAtual() {
  const R = G.rm, px = p.x + p.w / 2;
  for (const s of R.secs) if (px >= s.x0 * T && px < s.x1 * T) return s;
  return null;
}

// paredes que entram nos sólidos: portões fechados e travas de arena/chefe
function solidosTrechos(R, a) {
  R.secs.forEach((s, k) => {
    const ss = estT(k);
    if (ss.gate < .85) a.push([s.gx, 2 * T, T, 13 * T]);
    if (s.t == 'arena' && ss.wave >= 0 && !ss.done) a.push([s.x0 * T, 2 * T, T, 13 * T]);
  });
  if (R.lock) a.push([R.lockX, 2 * T, T, 13 * T]);
}

// um trecho foi vencido
function concluirTrecho(k) {
  const R = G.rm, S = R.st, s = R.secs[k], ss = estT(k);
  if (ss.done) return; ss.done = 1;
  if (!s.ult) { ss.aberto = 1; toast('Passagem aberta — trecho ' + (k + 2) + ' de ' + R.secs.length, 2.8); return; }
  say('Presente — ' + R.E.m, R.E.r, () => {
    ss.aberto = 1; S.done = 1; S.open = 1;
    toast(R.boss ? 'O guardião caiu — o mercador agora tem lâminas melhores à venda' : 'O caminho se abriu', 3);
  });
}

// inimigos de cada trecho (os de "guardiões" e arenas vencidas não voltam)
function spawnEnemies(R) {
  R.es = []; R.pr = [];
  R.ens.forEach(e => { const s = R.secs[e.sec], ss = estT(e.sec); if (s.t == 'guardioes' && ss.done) return; const m = mkEnemy(e); m.sec = e.sec; R.es.push(m); });
  R.secs.forEach((s, k) => { if (s.t == 'chefe' && !R.st.boss) mkBoss(R, s); });
}

// ao entrar na fase: desafios pela metade recomeçam
function reiniciarTrechos(R) {
  R.secs.forEach((s, k) => {
    const ss = estT(k);
    if (!ss.done) { ss.wave = -1; ss.tm = 0; if (!ss.aberto) ss.gate = 0; }
  });
  R.lock = false;
}

// itens da área inicial são pegos ao encostar (com explicação)
function pegarItens() {
  const R = G.rm, S = R.st, perto = o => o && Math.abs(p.x + p.w / 2 - o.x) < 26 && Math.abs(p.y + p.h - o.y) < 40;
  if (R.alt && !S.alt && perto(R.alt)) { S.alt = 1; p.ab[R.alt.a.k] = 1; say(R.alt.a.n, R.alt.a.t); }   // o balão da habilidade já explica
}

// por quadro: portões, dicas e regras de cada tipo de trecho
function atualizarTrechos(dt) {
  const R = G.rm, atual = trechoAtual();
  R.secs.forEach((s, k) => {
    const ss = estT(k), tipo = TRECHOS[s.t];
    if (ss.aberto || ss.tm > 0) ss.gate = Math.min(1, ss.gate + dt * 1.4);
    else if (ss.gate > 0) ss.gate = Math.max(0, ss.gate - dt * 1.6);
    if (tipo.atualizar) tipo.atualizar(R, s, ss, dt, s === atual);
  });
  if (atual) {
    const ss = estT(atual.k);
    if (!ss.visto) ss.visto = 1;   // as dicas de cada trecho (TRECHOS[].dica) não aparecem mais: só o objetivo curto no canto
  }
  if (G.dica && G.dica.t > 0) G.dica.t -= dt;
}

// golpe da espada acertando alavancas, braseiros etc.
function golpearTrechos(hb) {
  const R = G.rm;
  R.secs.forEach((s, k) => { const t = TRECHOS[s.t]; if (t.golpe) t.golpe(R, s, estT(k), hb); });
}

// objetos de apertar [E]
function interagiveisTrechos(R, a) {
  R.secs.forEach((s, k) => { const t = TRECHOS[s.t]; if (t.interagir) t.interagir(R, s, estT(k), a); });
}

// texto do objetivo para a interface
function objetivoAtual() {
  const R = G.rm, s = trechoAtual(); if (!s) return null;
  const ss = estT(s.k), t = TRECHOS[s.t];
  const txt = ss.done ? 'Concluído — siga em frente' : (t.objetivo ? t.objetivo(R, s, ss) : '');
  return { titulo: 'Trecho ' + (s.k + 1) + ' de ' + R.secs.length + ' · ' + t.nome, txt, ss, s };
}

// desenho de tudo que é dos trechos (portões, alavancas, braseiros, estacas, fragmentos)
// As peças vêm de assets/objetos/objetos.png (função obj em cenario.js).
function desenharTrechos() {
  const R = G.rm, hu = R.E.hu, cx = cam.x, cy = cam.y;
  for (const s of R.spk) {   // estacas (bolas de espinhos)
    const x = s.x + s.w / 2 - cx, y = s.y + s.h / 2 - cy; if (x < -40 || x > VW + 40) continue;
    if (s.mov) { g.fillStyle = 'rgba(30,26,40,.8)'; for (let k = 2 * T - cy; k < y - 18; k += 8) g.fillRect(Math.round(x) - 1, k, 2, 4); }
    obj('estaca', x, y + 18);
  }
  R.secs.forEach((s, k) => {
    const ss = estT(k), t = TRECHOS[s.t];
    if (t.desenhar) t.desenhar(R, s, ss, hu);
    const x = s.gx - cx; if (x < -T || x > VW + T) return;   // portão do fim do trecho (sobe ao abrir)
    portao(x, -ss.gate * 13 * T, ss.gate < 1 && !ss.aberto && !(ss.tm > 0));
    if (s.t == 'arena' && ss.wave >= 0 && !ss.done) portao(s.x0 * T - cx, 0, true);
  });
  if (R.lock) portao(R.lockX - cx, 0, true);
}
// grade de ferro de 13 blocos (do teto ao chão); desl = quanto já subiu
function portao(x, desl, fechado) {
  const gy = 2 * T - cam.y;
  g.save(); g.beginPath(); g.rect(x - 4, gy, T + 8, 13 * T); g.clip();
  if (fechado) glow(195, x + T / 2, gy + 9 * T, 70, .12 + .05 * Math.sin(G.time * 3), 70);
  for (let q = 0; q < 13; q++) obj('portao', x + T / 2, gy + desl + (q + 1) * T);
  obj('portao_ponta', x + T / 2, gy + desl + 13 * T + 6);
  g.restore();
}
// mecanismo comum: pedestal com cristal flutuando (verde quando já foi usado)
function desenharMecanismo(m, hu, feito) {
  const x = m.x - cam.x, y = m.y - cam.y; if (x < -60 || x > VW + 60) return;
  if (!feito) glow(190, x, y - 46, 58, .28, 72);
  obj('pedestal', x, y + 2);
  obj(feito ? 'cristal_feito' : 'cristal', x, y - 26 + balanco(m.x, 6));
}
