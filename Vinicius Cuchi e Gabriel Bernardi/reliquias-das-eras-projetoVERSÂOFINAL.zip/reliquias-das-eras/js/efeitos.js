// ===== Efeitos animados feitos por código (água, lava, lama, partículas) =====
// O visual fixo (terreno, objetos, fundos) vem dos assets; aqui ficam só os efeitos que se mexem.
const hh=n=>{const s=Math.sin(n*127.1+311.7)*43758.5453;return s-Math.floor(s)};
const pmod=(a,b)=>((a%b)+b)%b;

// ---------- FAIXA DE ÁGUA NO FUNDO ----------
let band_y0=380,band_y1=452;
function drawBand(c,hu){
 const y0=band_y0=c.y0,y1=band_y1=c.y1,t=G.time;
 const gr=g.createLinearGradient(0,y0,0,y1);gr.addColorStop(0,hsl(c.h,c.s,c.l+8,.9));gr.addColorStop(1,hsl(c.h,c.s,c.l-4,.95));g.fillStyle=gr;g.fillRect(0,y0,VW,y1-y0+2);
 for(let r=0;r<7;r++){const yy=y0+4+(y1-y0-6)*(r/7),amp=1+r*.35;g.strokeStyle='rgba(255,255,255,'+(.05+r*.012)+')';g.lineWidth=1.2;g.beginPath();for(let x=0;x<=VW;x+=10){const y=yy+Math.sin(x*.02*(1+r*.1)+t*(.6+r*.15)+r*2+cam.x*.004*(r+1))*amp;x?g.lineTo(x,y):g.moveTo(x,y)}g.stroke()}
 for(let k=0;k<26;k++){const sx=pmod(hh(k)*VW+Math.sin(t*.4+k)*8,VW),sy=y0+hh(k+30)*(y1-y0),a=.5+.5*Math.sin(t*2.4+k*3);g.fillStyle='rgba(255,246,215,'+(.18*a)+')';g.fillRect(sx,sy,2+a*2,1)}
 const e=g.createLinearGradient(0,y0-10,0,y0+8);e.addColorStop(0,hsl(c.h,c.s,c.l+14,0));e.addColorStop(1,hsl(c.h,c.s,c.l+14,.55));g.fillStyle=e;g.fillRect(0,y0-10,VW,18);
}

// ---------- EFEITOS POR ÉPOCA: rio no fundo (band), tipo de fosso (pit), partículas no ar (amb) ----------
const SCN=[
 /*0 Paleolítico*/{pit:'spikes',amb:'ember'},
 /*1 Neolítico*/{pit:'spikes',amb:'leaf'},
 /*2 Metais*/{pit:'lava',amb:'ember'},
 /*3 Escrita*/{band:{y0:392,y1:452,h:196,s:34,l:24},pit:'water',amb:'dust'},
 /*4 Nilo*/{band:{y0:372,y1:452,h:182,s:42,l:26},pit:'water',amb:'dust'},
 /*5 Grécia*/{band:{y0:410,y1:452,h:206,s:52,l:28},pit:'spikes',amb:'leaf'},
 /*6 Roma*/{pit:'spikes',amb:'dust'},
 /*7 Feudal*/{pit:'mud',amb:'leaf'},
 /*8 Islâmica*/{pit:'spikes',amb:'dust'},
 /*9 Cruzadas*/{band:{y0:408,y1:452,h:212,s:46,l:26},pit:'water',amb:'dust'},
 /*10 Peste*/{pit:'mud',amb:'fog'},
 /*11 Constantinopla*/{band:{y0:408,y1:452,h:208,s:44,l:22},pit:'spikes',amb:'ember'},
 /*12 Renascimento*/{pit:'spikes',amb:'dust'},
 /*13 Navegações*/{band:{y0:372,y1:452,h:206,s:52,l:26},pit:'water',amb:'spray'},
 /*14 Brasil Colonial*/{band:{y0:388,y1:452,h:188,s:46,l:26},pit:'water',amb:'leaf'},
 /*15 Reforma*/{pit:'spikes',amb:'pages'},
 /*16 Absolutismo*/{pit:'spikes',amb:'leaf'},
 /*17 Iluminismo*/{pit:'spikes',amb:'dust'},
 /*18 Rev. Francesa*/{pit:'mud',amb:'ember'},
 /*19 Napoleônica*/{pit:'mud',amb:'ash'},
 /*20 Independência*/{band:{y0:392,y1:452,h:200,s:48,l:26},pit:'water',amb:'leaf'},
 /*21 Brasil Imperial*/{pit:'mud',amb:'leaf'},
 /*22 Rev. Industrial*/{pit:'lava',amb:'ash'},
 /*23 Primavera*/{pit:'spikes',amb:'ember'},
 /*24 Neocolonial*/{pit:'spikes',amb:'dust'},
 /*25 1ª Guerra*/{pit:'mud',amb:'ash'},
 /*26 Rev. Russa*/{pit:'spikes',amb:'snow'},
 /*27 Crise 29*/{pit:'spikes',amb:'rain'},
 /*28 Totalitarismo*/{pit:'spikes',amb:'dust'},
 /*29 2ª Guerra*/{pit:'mud',amb:'ash'}
];

function prepararEfeitos(R){R.scn=SCN[R.i]||SCN[0]}

// fosso: fundo escuro (as paredes são as pontas do chão), espinhos em pixel art ou líquido
const LIQUIDOS={water:['#a8e0f0','#4a93b8','#2a6488','#163a56'],lava:['#fff0a0','#ff9a30','#d84a14','#6a1a0a'],mud:['#9a8058','#5e4a2e','#44331e','#22180e']};
function drawPit(h,hu){
 const cfg=G.rm.scn||{},st=cfg.pit||'spikes',cx=cam.x,cy=cam.y,t=G.time;
 const x=Math.round(h[0]*T-cx),w=h[2]*T,y0=FY*T-cy,yb=RH*T-cy;
 if(x>VW+20||x+w<-20)return true;
 const gr=g.createLinearGradient(0,y0-8,0,yb);gr.addColorStop(0,'rgba(0,0,0,.35)');gr.addColorStop(.3,'rgba(0,0,0,.85)');gr.addColorStop(1,'#000');
 g.fillStyle=gr;g.fillRect(x,y0-8,w,yb-y0+8);
 if(st=='spikes'){                                    // fileira de espinhos do estilo (assets/objetos)
  const nome=EST.espinhos||'espinhos_pantano';
  for(let sx=0;sx<w;sx+=32)obj(nome,x+sx+16,yb+2);
  return true;
 }
 const c=LIQUIDOS[st],top=y0+20,vel=st=='lava'?1.4:st=='mud'?.8:2.2,amp=st=='mud'?1:2;
 for(let sx=0;sx<w;sx+=4){                             // superfície em degraus de 2 px
  const off=Math.round(Math.sin((h[0]*T+sx)*.045+t*vel)*amp)*2,yy=top+off;
  g.fillStyle=c[1];g.fillRect(x+sx,yy,4,10);g.fillStyle=c[2];g.fillRect(x+sx,yy+10,4,14);g.fillStyle=c[3];g.fillRect(x+sx,yy+24,4,yb-yy-24);
  g.fillStyle=c[0];g.fillRect(x+sx,yy,4,2);
 }
 if(st=='lava'){glow(22,x+w/2,top,w*.6,.3+.08*Math.sin(t*3),55);
  for(let k=0;k<Math.ceil(w/40);k++){const u=(t*.7+hh(k+h[0]))%1;g.fillStyle=u<.5?c[0]:c[1];g.globalAlpha=1-u;g.fillRect(x+Math.round(hh(k*3+h[0])*(w-4)/2)*2,Math.round(top-2-u*24),u<.6?4:2,u<.6?4:2)}g.globalAlpha=1}
 if(st=='water'){g.fillStyle='rgba(255,255,255,.55)';for(let k=0;k<Math.ceil(w/24);k++){const ph=(t*.8+hh(k+h[0]*2))%1;if(ph<.5){const sx=Math.floor(hh(k*7+h[0])*(w-8)/2)*2;g.fillRect(x+sx,top+6+((k*5)%10),ph<.25?4:2,2)}}
  if(G.rm.i==4){const ex=Math.round(x+w*(.3+.4*((Math.sin(t*.4)+1)/2))/2)*2;g.fillStyle='#2c4a22';g.fillRect(ex-16,top+2,32,6);g.fillRect(ex-10,top,20,2);g.fillStyle='#ffd24a';g.fillRect(ex+8,top-2,2,2);g.fillRect(ex+12,top-2,2,2)}}
 if(st=='mud'){g.fillStyle=c[0];for(let k=0;k<Math.ceil(w/48);k++){const u=(t*.5+hh(k+h[0]))%1;if(u<.7){const sx=Math.floor(hh(k*5+h[0]*3)*(w-10)/2)*2,r=u<.35?2:4;g.fillRect(x+sx,top-r+2,r*2,r)}}}
 return true;
}
function drawAmb(){
 const R=G.rm,k=R.scn&&R.scn.amb;if(!k)return;const t=G.time;
 const N={dust:34,snow:90,ash:50,rain:120,ember:36,leaf:22,pages:16,fog:0,spray:40}[k]||0;
 for(let i=0;i<N;i++){
  const a=hh(i*1.7),b=hh(i*3.1+5),c=.5+hh(i*5.3);
  let x,y;
  if(k=='snow'){x=pmod(a*VW+Math.sin(t*.6+i)*20-t*14*c,VW);y=pmod(b*VH+t*40*c,VH);g.fillStyle='rgba(240,245,255,.75)';g.fillRect(x,y,2,2)}
  else if(k=='rain'){x=pmod(a*VW-t*80*c,VW);y=pmod(b*VH+t*620*c,VH);g.strokeStyle='rgba(180,200,230,.35)';g.lineWidth=1;g.beginPath();g.moveTo(x,y);g.lineTo(x-4,y+14);g.stroke()}
  else if(k=='ash'){x=pmod(a*VW+t*18*c+Math.sin(t+i)*10,VW);y=pmod(b*VH+t*22*c,VH);g.fillStyle='rgba(190,185,180,.45)';g.fillRect(x,y,2,2)}
  else if(k=='ember'){x=pmod(a*VW+Math.sin(t*.8+i)*14,VW);y=pmod(b*VH-t*38*c,VH);g.fillStyle='rgba(255,'+(120+hh(i)*80|0)+',60,'+(.35+.4*Math.sin(t*5+i))+')';g.fillRect(x,y,2,2)}
  else if(k=='dust'){x=pmod(a*VW+t*30*c,VW);y=pmod(b*VH+Math.sin(t*.7+i)*12,VH);g.fillStyle='rgba(225,205,160,.22)';g.fillRect(x,y,2,1.5)}
  else if(k=='leaf'){x=pmod(a*VW+t*26*c,VW);y=pmod(b*VH+t*20*c+Math.sin(t*2+i)*12,VH);g.fillStyle='rgba(150,170,70,.5)';g.beginPath();g.ellipse(x,y,3.2,1.6,t+i,0,7);g.fill()}
  else if(k=='pages'){x=pmod(a*VW+t*20*c+Math.sin(t*1.3+i)*30,VW);y=pmod(b*VH+t*28*c,VH);g.save();g.translate(x,y);g.rotate(Math.sin(t*1.5+i)*.9);g.fillStyle='rgba(235,225,195,.6)';g.fillRect(-5,-3.5,10,7);g.fillStyle='rgba(40,30,20,.5)';g.fillRect(-3.5,-1.5,7,1);g.fillRect(-3.5,.8,5,1);g.restore()}
  else if(k=='spray'){x=pmod(a*VW+t*50*c,VW);y=pmod(b*VH+Math.sin(t*3+i)*6,VH);g.fillStyle='rgba(210,230,255,.2)';g.fillRect(x,y,2,1.5)}
 }
 if(k=='fog'){for(let j=0;j<4;j++){const y=VH*(.42+.13*j)+Math.sin(t*.3+j)*10,gr=g.createLinearGradient(0,y-50,0,y+50);gr.addColorStop(0,'rgba(120,150,110,0)');gr.addColorStop(.5,'rgba(120,150,110,.12)');gr.addColorStop(1,'rgba(120,150,110,0)');g.fillStyle=gr;g.fillRect(0,y-50,VW,100)}}
}
