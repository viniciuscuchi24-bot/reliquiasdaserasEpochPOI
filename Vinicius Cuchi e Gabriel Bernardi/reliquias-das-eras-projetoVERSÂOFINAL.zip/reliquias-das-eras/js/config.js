// ===== Configuração do jogo =====
// Mude aqui o estilo visual que abre primeiro. No jogo, a tecla V (ou o botão "Estilo") troca.
const CONFIG = {
  estiloInicial: 'pantano',            // 'pantano' ou 'cemiterio' (nomes das pastas em assets/estilos)
  lembrarEstilo: true,                 // guarda no navegador o último estilo escolhido
  audio: {
    musica: 'assets/audio/musica.mp3',
    pulo: 'assets/audio/pulo.mp3',
    esquiva: 'assets/audio/esquiva.mp3',
    // música própria de cada fase (opcional): número da fase -> arquivo.
    // Fases sem música aqui tocam a música principal. Exemplo:
    //   musicasPorFase: { 1: 'assets/audio/fases/paleolitico.mp3', 5: 'assets/audio/fases/nilo.mp3' }
    musicasPorFase: {},
    // música da luta contra cada chefe (toca enquanto ele está acordado; quando ele cai, volta a música da fase)
    musicasChefes: {
      legionario: 'assets/audio/chefes/estudo.mp3',     // 1º chefe — Legionário de Pedra
      espectro: 'assets/audio/chefes/espirito.mp3',     // 2º chefe — Espectro da Caravela
      colosso: 'assets/audio/chefes/industria.mp3',     // 3º chefe — Colosso a Vapor
      enigma: 'assets/audio/chefes/sinistro.mp3'        // último chefe — Máquina Enigma
    }
  }
};

// Registros preenchidos pelos arquivos de assets (assets/estilos/*/estilo.js, assets/personagem/personagem.js
// e assets/monstros/monstros.js)
const ESTILOS = {};
const ORDEM_ESTILOS = [];
function registrarEstilo(e) { if (!ESTILOS[e.id]) ORDEM_ESTILOS.push(e.id); ESTILOS[e.id] = e; }
let PERSONAGEM = null;
function registrarPersonagem(p) { PERSONAGEM = p; }
let MONSTROS = null;
function registrarMonstros(m) { MONSTROS = Object.assign(MONSTROS || {}, m); }
// monstros extras (assets/monstros/monstros_era.js): entram junto com os outros; 'temas' diz em que épocas aparecem
function registrarMonstrosExtra(m) { MONSTROS = MONSTROS || { pasta: 'assets/monstros/' }; const t = m.temas; delete m.temas; Object.assign(MONSTROS, m); MONSTROS.temas = Object.assign(MONSTROS.temas || {}, t || {}); }
let CHEFES_ARTE = null;
function registrarChefes(c) { CHEFES_ARTE = c; }
let INTERFACE = null;
function registrarInterface(i) { INTERFACE = Object.assign(INTERFACE || {}, i); }   // vários arquivos juntam suas partes (interface.js, hud.js, fonte.js, titulo.js)
