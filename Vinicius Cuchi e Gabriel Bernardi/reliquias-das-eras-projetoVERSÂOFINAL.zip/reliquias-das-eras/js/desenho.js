// ===== Desenho: monta cada quadro (fundo, mundo, inimigos, jogador, interface) =====
function drawBG(){
 const R=G.rm,hu=R.E.hu;
 desenharFundo(R.i);                                   // fundo da época (assets/estilos/<estilo>/fundos)
 if(R.scn&&R.scn.band)drawBand(R.scn.band,hu);         // rio animado (efeitos.js)
 desenharArenaFundo(false);                            // arena do chefe ao ar livre: atrás das camadas do estilo (arenas.js)
 desenharCamadas();                                    // camadas do estilo com parallax
 desenharArenaFundo(true);                             // arena coberta (fábrica, casamata): cobre as camadas
 for(let k=0;k<3;k++){                                 // névoa passando
  const y=VH*(.5+.14*k)+Math.sin(G.time*.4+k)*10,a=.06+.03*Math.sin(G.time*.5+k*2);
  const gr=g.createLinearGradient(0,y-70,0,y+70);gr.addColorStop(0,hsl(hu,15,40,0));gr.addColorStop(.5,hsl(hu,15,40,a));gr.addColorStop(1,hsl(hu,15,40,0));
  g.fillStyle=gr;g.fillRect(0,y-70,VW,140);
 }
}
function glow(hu,x,y,r,a,l){const gr=g.createRadialGradient(x,y,2,x,y,r);gr.addColorStop(0,hsl(hu,70,l||65,a));gr.addColorStop(1,hsl(hu,70,l||65,0));g.fillStyle=gr;g.fillRect(x-r,y-r,2*r,2*r)}
function diamond(x,y,s,c){g.fillStyle=c;g.beginPath();g.moveTo(x,y-s);g.lineTo(x+s*.7,y);g.lineTo(x,y+s);g.lineTo(x-s*.7,y);g.closePath();g.fill()}
function drawWorld(){
 const R=G.rm,S=R.st,hu=R.E.hu,cx=cam.x,cy=cam.y;
 desenharArenaMeio();                                  // construções da arena do chefe: colunas, mastros, fornalhas... (arenas.js)
 desenharObjetos();
 for(const h of R.haz)drawPit(h,hu);                   // fossos: fundo escuro, espinhos ou líquido (efeitos.js)
 for(const r of R.sol){                                // terreno do estilo (cenario.js)
  if(r[0]+r[2]<cx-80||r[0]>cx+VW+80)continue;
  const x=r[0]-cx,y=r[1]-cy,w=r[2],h=r[3],sem=Math.floor(r[0]/150);
  if(r[1]==0)desenharTeto(x,y,w,h);
  else if(r[4]){if(!ehPlataformaDaArena(r))desenharPlataforma(x,y,w,h)}
  else if(r[1]<=2*T)desenharPendurado(x,y,w,h,sem);   // bloco preso no teto
  else if(r[1]==FY*T){const esq=R.haz.some(q=>(q[0]+q[2])*T==r[0]),dir=R.haz.some(q=>q[0]*T==r[0]+r[2]);if(!desenharChaoArena(r,x,y,w,h,sem,esq,dir))desenharChao(x,y,w,h,sem,esq,dir)}
  else if(!desenharBlocoArena(r,x,y,w,h))desenharBloco(x,y,w,r[1]+r[3]==FY*T?h+3*T:h,sem,r[1]+r[3]<FY*T);   // apoiado no chão: cobre a grama de baixo
 }
 desenharArenaPiso();                                  // casco do navio e plataformas da arena (arenas.js)
 for(const m of R.mov)desenharPlataforma(Math.round(m.x-cx),Math.round(m.y-cy),m.w,16);   // plataformas móveis
 desenharTrechos();                                    // portões, alavancas, braseiros, estacas (fases.js)
 // runa do passado (uma runa diferente em cada época)
 {const x=R.rune.x-cx,y=R.rune.y-cy,nome='runa_'+(typeof OBJETOS!='undefined'?OBJETOS.runas[R.i%OBJETOS.runas.length]:'');
  if(!S.read)glow(195,x,y-28,64,.3+.08*Math.sin(G.time*3),70);
  if(!obj(nome+(S.read?'_apagada':''),x,y+2)){g.fillStyle=hsl(hu,10,13);g.fillRect(x-14,y-54,28,54)}}
 // fragmento de memória
 {const x=R.extra.x-cx,y=R.extra.y-cy-14+balanco(1,6);if(!S.xr)glow(330,x,y-14,46,.3,70);
  g.globalAlpha=S.xr?.35:1;obj('fragmento_rosa',x,y);g.globalAlpha=1}
 // marco de descanso: banco + lampião
 if(R.bench){const x=R.bench.x-cx,y=R.bench.y-cy;glow(40,x+30,y-70,90,.32+.04*Math.sin(G.time*5),62);obj('lampiao',x+30,y+2);obj('marco',x-4,y+2)}
 // arma nova no pedestal
 if(R.loja){const x=R.loja.x-cx,y=R.loja.y-cy;if(x>-80&&x<VW+80){glow(40,x+18,y-60,70,.28+.05*Math.sin(G.time*2),70);obj('mercador',x,y+2)}}   // barraca do mercador (loja.js)
 // altar da habilidade
 if(R.alt&&!S.alt){const x=R.alt.x-cx,y=R.alt.y-cy;glow(200,x,y-48,80,.5,75);obj('pedestal',x,y+2);obj('orbe',x,y-30+balanco(3,6))}
 if(G.echo&&G.echo.ri==G.ri){const x=G.echo.x-cx,y=G.echo.y-cy;g.globalAlpha=.55+.15*Math.sin(G.time*4);g.fillStyle='#9cc6ff';g.beginPath();g.ellipse(x+11,y+22,10,17,0,0,7);g.fill();g.globalAlpha=1}
 if(G.near&&G.mode=='play'){const o=G.near,x=o.x-cx,y=o.y-cy-96;g.font='13px Georgia,serif';const t='[E] '+o.t,w=g.measureText(t).width+30;   // aviso de interação num pergaminho pequeno
  const cx2=caixaPergaminho(x-w/2,y-19,w,30);if(!cx2)caixaPreta(x-w/2,y-16,w,24,.75);g.fillStyle=cx2?corTinta('tinta'):'#f2eee2';g.textAlign='center';g.fillText(t,x,y+1)}
}
// espada da arma nova, desenhada pixel a pixel (2 px por ponto) com a cor da lâmina
function drawEnemy(e){
 if(desenharMonstro(e))return;                         // sprites de assets/monstros (monstros.js)
 if(e.dead)return;
 const hu=G.rm.E.hu,x=e.x-cam.x,y=e.y-cam.y,fl=e.fl>0,body=fl?'#fff':hsl(hu,12,5),eye=hsl(hu,90,72);
 g.fillStyle=body;g.strokeStyle=hsl(hu,50,60,.45);g.lineWidth=1.5;
 if(e.k=='w'){g.beginPath();g.ellipse(x+15,y+14,15,12,0,0,7);g.fill();g.stroke();g.fillRect(x+4,y+20,5,6);g.fillRect(x+21,y+20,5,6);g.fillStyle=eye;g.fillRect(e.vx>0?x+20:x+6,y+8,4,4)}
 else if(e.k=='h'){g.beginPath();g.arc(x+13,y+13,12,0,7);g.fill();g.stroke();g.fillRect(x+3,y+22,6,4);g.fillRect(x+17,y+22,6,4);g.fillStyle=eye;g.fillRect(p.x>e.x?x+15:x+5,y+9,4,4)}
 else{const w=Math.sin(G.time*14)*6;g.beginPath();g.moveTo(x+14,y);g.lineTo(x+28,y+14);g.lineTo(x+14,y+28);g.lineTo(x,y+14);g.closePath();g.fill();g.stroke();
  g.beginPath();g.moveTo(x+2,y+12);g.lineTo(x-14,y+4+w);g.lineTo(x,y+18);g.fill();g.beginPath();g.moveTo(x+26,y+12);g.lineTo(x+42,y+4+w);g.lineTo(x+28,y+18);g.fill();
  g.fillStyle=eye;g.fillRect(x+10,y+11,3,4);g.fillRect(x+16,y+11,3,4)}
}
function drawEnts(){
 const R=G.rm;
 for(const e of R.es){if(e.k=='B'){if(!e.dead||e.id=='enigma'||G.time-(e.morte||-99)<6)desenharChefe(e);continue}if(e.k=='rot')continue;if(e.dead&&!(e.morte&&G.time-e.morte<duracaoMorte(e)))continue;drawEnemy(e)}
 desenharProjeteis();                                  // ataques dos chefes (chefes.js)
}
function drawPlayer(){
 desenharAura();                                        // com 1 de vida: aura quente em volta (personagem.js)
 desenharAuraCura(1);                                  // curando: aura verde atrás do corpo (personagem.js)
 if(p.inv>0&&p.dashT<=0&&Math.floor(G.time*14)%2&&G.mode!='dialog'&&G.mode!='morte')return;
 if(p.dashT>0)g.globalAlpha=.4;
 const x=p.x+p.w/2-cam.x,y=p.y-cam.y;
 g.save();g.translate(x,y);
 g.scale(p.f,1);
 desenharPersonagem(G.ri);
 g.restore();g.globalAlpha=1;
 desenharAuraCura(.22,true);                           // e um pouco por cima, para envolver o personagem
 desenharGolpe();                                      // rastro do corte e espada na mão (personagem.js)
}
function drawFG(){
 const hu=G.rm.E.hu;
 desenharArenaFrente();
 drawAmb();
 for(const f of G.fx){g.globalAlpha=clamp(f.t*2,0,1);g.fillStyle=f.c;g.fillRect(Math.round(f.x-cam.x),Math.round(f.y-cam.y),Math.round(f.s),f.pena?Math.max(1,Math.round(f.s/2)):Math.round(f.s))}
 g.globalAlpha=1;desenharImpactos();desenharCabeca();
 if(G.txt)for(const q of G.txt){g.globalAlpha=clamp(q.t*2,0,1);g.font='bold 15px Georgia,serif';g.textAlign='center';g.fillStyle='#2a1a08';g.fillText(q.s,q.x-cam.x+1,q.y-cam.y-(1.1-q.t)*40+1);g.fillStyle='#ffd45a';g.fillText(q.s,q.x-cam.x,q.y-cam.y-(1.1-q.t)*40)}g.globalAlpha=1;                   // estrela do golpe acertando (personagem.js)
 g.fillStyle=hsl(hu,50,75,1);for(const m of MOTES){g.globalAlpha=m.a;g.fillRect(m.x,m.y,m.s,m.s)}g.globalAlpha=1;
}
let ESCURO_CV=null;
function drawLight(){
 const px=p.x+11-cam.x,py=p.y+19-cam.y,r=p.ab.lamp?640:480;
 let gr=g.createRadialGradient(px,py,50,px,py,r);gr.addColorStop(0,'rgba(0,0,0,0)');gr.addColorStop(1,'rgba(0,0,0,.6)');g.fillStyle=gr;g.fillRect(0,0,VW,VH);
 gr=g.createRadialGradient(VW/2,VH/2,300,VW/2,VH/2,640);gr.addColorStop(0,'rgba(0,0,0,0)');gr.addColorStop(1,'rgba(0,0,0,.5)');g.fillStyle=gr;g.fillRect(0,0,VW,VH);
 desenharEscuridao(px,py);
}
// trechos escuros: tudo preto, com buracos de luz no jogador e nos braseiros acesos
function desenharEscuridao(px,py){
 const R=G.rm;let s=null;for(const q of R.secs)if(TRECHOS[q.t].escuro&&p.x+p.w>q.x0*T-6*T&&p.x<q.x1*T+4*T){s=q;break}
 if(!s)return;const ss=estT(s.k);
 const dentro=p.x+p.w/2>=s.x0*T&&p.x+p.w/2<s.x1*T,fora=dentro?0:Math.min(1,Math.min(Math.abs(p.x-s.x0*T),Math.abs(p.x-s.x1*T))/(4*T));
 const forca=(ss.done?.45:.94)*(1-fora);if(forca<=.02)return;
 if(!ESCURO_CV){try{ESCURO_CV=document.createElement('canvas');ESCURO_CV.width=VW;ESCURO_CV.height=VH;}catch(e){ESCURO_CV=0}}
 const c=ESCURO_CV&&ESCURO_CV.getContext?ESCURO_CV.getContext('2d'):null;
 const raio=(p.ab.lamp?300:165)+(p.hp==1?50:0);          // com 1 de vida a abóbora acesa ilumina mais
 if(!c){g.fillStyle='rgba(0,0,0,'+forca*.8+')';g.fillRect(0,0,VW,VH);return}
 c.globalCompositeOperation='source-over';c.clearRect(0,0,VW,VH);c.fillStyle='rgba(2,2,6,'+forca+')';c.fillRect(0,0,VW,VH);
 c.globalCompositeOperation='destination-out';
 const furo=(x,y,r)=>{const q=c.createRadialGradient(x,y,r*.25,x,y,r);q.addColorStop(0,'rgba(0,0,0,1)');q.addColorStop(1,'rgba(0,0,0,0)');c.fillStyle=q;c.fillRect(x-r,y-r,2*r,2*r)};
 furo(px,py,raio+Math.sin(G.time*3)*6);
 s.alvos.forEach((o,j)=>{if(ss.lit[j])furo(o.x-cam.x,o.y-30-cam.y,230+Math.sin(G.time*7+j)*8);else furo(o.x-cam.x,o.y-26-cam.y,40)});
 c.globalCompositeOperation='source-over';g.drawImage(ESCURO_CV,0,0);
}
function drawHUD(){
 // tanque de energia (esfera) e vida (lanternas) — interface.js
 const [ex,ey]=HUD_POS.esfera;desenharEsfera(ex,ey,HUD_POS.esferaK,clamp(p.soul/99,0,1));
 desenharLanternas();
 const x=HUD_POS.lx+2;
 if(!obj('moeda_runica',x+7,91,1))diamond(x+7,82,7,'#e8e4d8');
 textoPixel(String(G.coins),x+20,90,2,'#f2eee2','left',true);
 textoPixel(SW[p.wp].n,x,114,2,SW[p.wp].c,'left',true);
 const ab=[['dash','Esquiva aérea'],['dj','Asas'],['wall','Garras'],['lamp','Lanterna']].filter(a=>p.ab[a[0]]).map(a=>a[1]).join(' · ');
 if(ab)textoPixel(ab,x,136,2,'rgba(232,228,216,.62)','left',true);
 if(G.cronicas){   // placa "Crônicas do Fim" embaixo da esfera e das lanternas, alinhada pela borda da esfera
  const t='CRÔNICAS DO FIM',w=larguraPixel(t,2)+18,bx=HUD_POS.esfera[0]-41,by=148;
  g.fillStyle='rgba(58,10,6,.8)';g.fillRect(bx,by,w,24);g.strokeStyle='rgba(255,138,106,.8)';g.lineWidth=1;g.strokeRect(bx+.5,by+.5,w-1,23);
  textoPixel(t,bx+9,by+18,2,'#ffb09a','left',true);
 }
 const b=G.rm.es.find(e=>e.k=='B'&&e.on&&!e.dead);
 const ob=objetivoAtual();
 if(ob&&G.mode!='title'){
  g.textAlign='right';g.font='italic 13px Georgia,serif';g.fillStyle='rgba(232,228,216,.75)';g.fillText(ob.titulo,VW-24,36);
  g.font='14px Georgia,serif';g.fillStyle=ob.ss.done?'rgba(160,230,170,.9)':'#f2eee2';g.fillText(ob.txt,VW-24,56);
  if(ob.s.t=='corrida'&&ob.ss.tm>0){g.textAlign='center';g.font='bold 34px Georgia,serif';g.fillStyle=ob.ss.tm<3?'#ff7a6a':'#f2eee2';g.fillText(Math.ceil(ob.ss.tm),VW/2,72)}
 }
 if(G.dica&&G.dica.t>0&&G.mode=='play'){
  g.globalAlpha=clamp(G.dica.t,0,1);g.font='15px Georgia,serif';g.textAlign='center';
  const ln=wrap(G.dica.s,600),h=ln.length*20+34,y0=196;   // dica num pergaminho (assets/interface)
  const cx2=caixaPergaminho(VW/2-340,y0,680,h,clamp(h/300,.12,.3));
  if(!cx2){caixaPreta(VW/2-330,y0,660,h);g.strokeStyle='rgba(232,228,216,.35)';g.lineWidth=1;g.strokeRect(VW/2-330+.5,y0+.5,660,h)}
  g.fillStyle=cx2?corTinta('tinta'):'#f2eee2';ln.forEach((l,k)=>g.fillText(l,VW/2,y0+h/2-(ln.length-1)*10+5+k*20));g.globalAlpha=1;
 }
 if(b){const vida=b.id=='enigma'?b.rot.reduce((a,r)=>a+Math.max(0,r.dead?0:r.hp),0)+b.hp:b.hp,total=b.id=='enigma'?b.rot.reduce((a,r)=>a+r.mh,0)+b.mh:b.mh;
  if(!barraVidaChefe(b,vida,total)){   // moldura com trepadeiras (interface.js); se não carregou, a barra simples
  g.fillStyle='rgba(0,0,0,.6)';g.fillRect(300,40,360,10);g.fillStyle='#d9d4c4';g.fillRect(300,40,360*Math.max(0,vida)/total,10);g.strokeStyle='rgba(255,255,255,.5)';g.lineWidth=1;g.strokeRect(300,40,360,10);g.textAlign='center';g.font='italic 14px Georgia,serif';g.fillStyle='#e8e4d8';g.fillText(b.name,VW/2,32)}}
}
function drawBanner(){
 const b=G.ban;if(b.t<=0)return;const a=clamp(Math.min(b.t,3.4-b.t)*2,0,1);
 if(b.retrato)desenharRetratoChefe(b.retrato,a);
 g.globalAlpha=a;g.textAlign='center';g.fillStyle='#f2eee2';g.font='italic 40px Georgia,serif';g.fillText(b.a,VW/2,150);
 g.font='16px Georgia,serif';g.fillStyle='rgba(242,238,226,.75)';g.fillText(b.b,VW/2,180);
 g.fillStyle='rgba(242,238,226,.5)';g.fillRect(VW/2-90,196,180,1);g.globalAlpha=1;
}
function drawToast(){   // aviso curto: texto com sombra no alto da tela, sem balão (não cobre inimigos nem chefes)
 const t=G.toast;if(t.t<=0)return;const a=clamp(t.t*2,0,1),y=G.rm&&G.rm.es.some(e=>e.k=='B'&&e.on&&!e.dead)?100:64;
 const w=larguraPixel(t.s,2)+80,gr=g.createLinearGradient(VW/2-w/2,0,VW/2+w/2,0);
 gr.addColorStop(0,'rgba(0,0,0,0)');gr.addColorStop(.2,'rgba(0,0,0,'+.42*a+')');gr.addColorStop(.8,'rgba(0,0,0,'+.42*a+')');gr.addColorStop(1,'rgba(0,0,0,0)');
 g.fillStyle=gr;g.fillRect(VW/2-w/2,y-20,w,28);
 g.globalAlpha=a;textoPixel(t.s,VW/2,y,2,'#f4ead8','center',true);g.globalAlpha=1;
}
function wrap(text,maxW){
 const words=text.split(' '),lines=[];let cur='';
 for(const w of words){const t=cur?cur+' '+w:w;if(g.measureText(t).width>maxW&&cur){lines.push(cur);cur=w}else cur=t}
 if(cur)lines.push(cur);return lines;
}
function drawDialog(){
 const d=G.dlg;if(!d)return;const hu=G.rm.E.hu,x=60,y=VH-214,w=VW-120,h=190;
 const cx2=caixaPergaminho(x,y,w,h,.46),p=cx2?44:26;   // diálogo num pergaminho com moldura (assets/interface)
 if(!cx2){caixaPreta(x,y,w,h,.94);g.strokeStyle=hsl(hu,50,65,.7);g.lineWidth=1.5;g.strokeRect(x+.5,y+.5,w,h)}
 g.textAlign='left';g.fillStyle=cx2?corTinta('titulo'):hsl(hu,60,75);g.font='italic 20px Georgia,serif';g.fillText(d.title,x+p+12,y+46);
 g.font='17px Georgia,serif';g.fillStyle=cx2?corTinta('tinta'):'#e8e4d8';
 const lines=wrap(d.text,w-2*p-24);let left=Math.floor(d.n),ly=y+80;
 for(const ln of lines){if(left<=0)break;g.fillText(ln.slice(0,left),x+p+12,ly);left-=ln.length+1;ly+=25}
 if(d.n>=d.text.length){g.textAlign='right';g.font='13px sans-serif';g.fillStyle=cx2?corTinta('fraca'):'rgba(232,228,216,.6)';g.fillText('[E] continuar',x+w-p-10,y+h-p+12)}
}
const MAPA_COL=8;   // épocas por linha no mapa (em zigue-zague)
function mapPos(i){const r=Math.floor(i/MAPA_COL),c=(r%2==0)?i%MAPA_COL:MAPA_COL-1-i%MAPA_COL;return[c,r]}
function drawMap(){
 g.fillStyle='rgba(4,4,8,.95)';g.fillRect(0,0,VW,VH);
 g.textAlign='center';g.fillStyle='#f2eee2';g.font='italic 30px Georgia,serif';g.fillText('Mapa das Eras',VW/2,56);
 const cw=112,ch=78,x0=(VW-(MAPA_COL-1)*cw)/2,y0=112;
 g.strokeStyle='rgba(255,255,255,.22)';g.lineWidth=2;
 for(let i=0;i<NR-1;i++){if(!G.vis[i])continue;const[a,b]=mapPos(i),[c,d]=mapPos(i+1);g.beginPath();g.moveTo(x0+a*cw,y0+b*ch);g.lineTo(x0+c*cw,y0+d*ch);g.stroke()}
 for(let i=0;i<NR;i++){
  const[a,b]=mapPos(i),x=x0+a*cw,y=y0+b*ch,v=G.vis[i],E=ERAS[i];
  if(!v&&!(i>0&&G.vis[i-1]))continue;
  g.fillStyle=v?hsl(E.hu,28,16):'rgba(255,255,255,.04)';g.strokeStyle=v?hsl(E.hu,50,60,.8):'rgba(255,255,255,.2)';g.lineWidth=1.5;
  g.fillRect(x-46,y-24,92,48);g.strokeRect(x-46,y-24,92,48);
  g.fillStyle='#e8e4d8';g.font='13px Georgia,serif';g.fillText(v?(i+1)+' · '+E.y:'?',x,y+4);
  if(v&&ROOMS[i]&&ROOMS[i].bench){g.fillStyle='#ffcf70';g.beginPath();g.arc(x+38,y-18,3,0,7);g.fill()}
  if(i==G.ri){g.strokeStyle='#fff';g.lineWidth=2;g.strokeRect(x-50,y-28,100,56)}
 }
 g.fillStyle='#e8e4d8';g.font='italic 20px Georgia,serif';g.fillText(G.rm.E.n,VW/2,430);
 g.font='13px sans-serif';g.fillStyle='rgba(232,228,216,.65)';g.fillText('Runas lidas: '+G.runes+' / '+NR*2+'    ·    Moedas: '+G.coins+'    ·    [M] fechar',VW/2,462);
}
function draw(){
 g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,VW,VH);
 if(G.mode=='title'){drawTitle();desenharIcone();desenharFps();return}
 if(G.mode=='fim'){desenharFim();desenharFps();return}
 const tr=OPC.tremor?16:0,ox=(Math.random()-.5)*G.shake*tr,oy=(Math.random()-.5)*G.shake*tr;
 g.save();g.translate(ox,oy);drawBG();drawWorld();drawEnts();drawPlayer();drawFG();g.restore();
 const menu=(G.mode=='banco'||G.mode=='pausa')&&MENU,opc=menu&&['opcoes','video','som','controles','toque'].includes(topoMenu().id);
 drawLight();if(!opc)drawHUD();if(!menu){drawBanner();drawToast()}
 if(G.mode=='dialog')drawDialog();
 if(G.mode=='map')drawMap();
 if(G.mode=='loja')desenharLoja();
 if(G.mode=='diario')desenharDiario();
 if(G.mode=='cronicaPerdida')desenharCronicaPerdida();
 if((G.mode=='banco'||G.mode=='pausa')&&MENU){desenharFundoMenu();desenharMenu()}   // js/menus.js
 if(G.fade>0){g.fillStyle='rgba(0,0,0,'+G.fade+')';g.fillRect(0,0,VW,VH)}
 desenharIcone();desenharFps();
}
// contador de FPS (Opções > Vídeo)
const FPS={n:0,t:0,v:0};
function desenharFps(){if(OPC.verFps)textoPixel(FPS.v+' FPS',12,VH-12,2,'#c8f070','left',true)}
// laço principal. Com limite de FPS (Opções > Vídeo) pula as chamadas do navegador que vêm cedo demais.
let last=performance.now(),proximo=0;
function loop(n){
 requestAnimationFrame(loop);
 const alvo=OPC.fps?1000/OPC.fps:0;
 if(alvo){if(n<proximo-1.5)return;proximo=n-proximo>alvo*2?n+alvo:proximo+alvo}
 const dt=Math.min(.034,(n-last)/1000);last=n;
 FPS.n++;FPS.t+=dt;if(FPS.t>=.5){FPS.v=Math.round(FPS.n/FPS.t);FPS.n=0;FPS.t=0}
 lerControle();                                          // controle (gamepad) — js/entrada.js
 try{update(dt);draw()}catch(e){console.error(e)}
 if(G.keep)G.keep=0;else for(const k in P)P[k]=0;
}
newGame();aplicarOpcoes();requestAnimationFrame(loop);
