// Gerado por ferramentas/pintar_titulo.py — tela de título
// cena.png é desenhada 2x; heroi = onde ficam os pés do Hallokin (px da cena); porta = centro de baixo da porta;
// feixes = [x no topo, largura, inclinação, força] dos feixes de luz (o jogo faz eles pulsarem)
registrarInterface({ titulo: {"pasta": "assets/titulo/", "cena": "cena.png", "escala": 2, "logo": "logo.png", "logoEscala": 5, "logoPos": [20, 18], "heroi": [318, 236], "porta": [350, 184], "disco": [350, 75], "feixes": [[215, 16, -0.42, 0.55], [262, 9, -0.42, 0.4], [300, 22, -0.45, 0.5], [178, 6, -0.4, 0.3]]} });
