// =====================================================================
//  PERSONAGEM: Hallokin (SHADOW Series - Hallokin, free) — gerado por ferramentas/recortar_hallokin.py
//  hallokin.png: uma LINHA por animação e um quadro por COLUNA (96x96 cada); "pes" é o ponto dos pés no quadro.
//  golpes.png: o rastro laranja dos golpes, na mesma grade. Nas armas de alcance maior o corte se solta e voa
//    na direção do golpe ('eixo': x = para a frente, -y = para cima, y = para baixo) até onde a arma acerta;
//    'ponta' é até onde o rastro vai no quadro e 'solta' é o quadro em que ele começa a voar.
//  ataque_baixo (pogo) foi montado a partir do ataque para cima (não existe na folha original).
//  impactos.png: o estouro do golpe acertando (3 quadros de 48x25, centro em 'centro').
//  cabeca.png: a abóbora que ele arremessa no R (com o tanque de energia cheio).
//  Mesmo personagem em todas as épocas.
// =====================================================================
registrarPersonagem({
  nome: 'Hallokin',
  pasta: 'assets/hallokin/',
  arquivo: 'hallokin.png',
  quadro: [96, 96],
  pes: [33.5, 64],
  escala: 2,
  anim: {
    parado: {"linha": 0, "quadros": [0, 1, 2, 3, 4, 5], "fps": 8},
    andar: {"linha": 1, "quadros": [0, 1, 2, 3], "fps": 10},
    pulo: {"linha": 2, "quadros": [0, 1, 2], "fps": 10},
    queda: {"linha": 3, "quadros": [0, 1, 2], "fps": 10},
    ataque: {"linha": 4, "quadros": [0, 1, 2, 3, 4, 5, 6], "fps": 28},
    ataque_ar: {"linha": 5, "quadros": [0, 1, 2, 3, 4], "fps": 24},
    ataque_cima: {"linha": 6, "quadros": [0, 1, 2, 3, 4, 5], "fps": 26},
    dano: {"linha": 7, "quadros": [0], "fps": 1},
    morte: {"linha": 8, "quadros": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11], "fps": 12},
    ataque_baixo: {"linha": 9, "quadros": [0, 1, 2, 3, 4, 5], "fps": 26}
  },
  golpes: { arquivo: 'golpes.png',
    ataque: {"eixo": "x", "ponta": 68, "solta": 2},
    ataque_ar: {"eixo": "x", "ponta": 69, "solta": 1},
    ataque_cima: {"eixo": "-y", "ponta": 16, "solta": 2},
    ataque_baixo: {"eixo": "y", "ponta": 91, "solta": 2}
  },
  impactos: { arquivo: 'impactos.png', quadro: [48, 25], centro: [23, 19], n: 3, escala: 1.5 },
  cabeca: { arquivo: 'cabeca.png', quadro: [17, 15], centro: [8.5, 8], pescoco: 10 },   // R: a cabeça arremessada; pescoco = altura (px da folha) do queixo acima dos pés
  asas: { arquivo: 'asas.png', quadro: [40, 38], ombro: [33, 21], n: 4, fps: 16, escala: 1.25, costas: [-6, 15] }
});
