// =====================================================================
//  MONSTROS
//  Arte: "Forest Monsters FREE" (cogumelo), "Golems Free Version" (golem) e "Flying Forest Enemies FREE" (voador).
//  Cada animação é uma imagem com os quadros lado a lado, todos do mesmo tamanho.
//
//  Tipos de inimigo do jogo:  w = anda e vira na beirada   h = pula na sua direção   f = flutua e persegue
//
//  quadro   [largura, altura] de cada quadro na imagem
//  centro   coluna do meio do corpo dentro do quadro (o jogo alinha com o centro da caixa de colisão)
//  pe       linha onde ficam os pés dentro do quadro
//  direita  true se o desenho original olha para a direita
//  escala   tamanho na tela
//  caixa    [largura, altura] da caixa de colisão, em pixels da tela
//  anim     nome: [arquivo, quadros, quadros por segundo]
//  diario   [x, y, largura, altura] do desenho dentro do 1º quadro de 'parado' (para a figura do Diário)
//  texto    o que o Diário dos Monstros conta sobre ele
//  Para trocar um monstro: substitua os PNG (mesmo nome) e ajuste quadro/centro/pe aqui.
// =====================================================================
registrarMonstros({
  pasta: 'assets/monstros/',
  w: {
    nome: 'Cogumelo', pasta: 'cogumelo/', quadro: [80, 64], centro: 40, pe: 64, direita: false, escala: 1.3, caixa: [30, 38], diario: [25, 31, 30, 33],
    texto: 'Brota onde a terra guarda memórias antigas. Anda de um lado para o outro e morde quem chega perto.',
    anim: { parado: ['parado.png', 7, 8], andar: ['andar.png', 8, 11], ataque: ['ataque.png', 10, 15], dano: ['dano.png', 5, 16], morte: ['morte.png', 15, 18] }
  },
  h: {
    nome: 'Golem de brasa', pasta: 'golem_laranja/', quadro: [90, 64], centro: 45, pe: 64, direita: true, escala: 1.2, caixa: [36, 42], diario: [26, 26, 38, 38],
    texto: 'Pedra e carvão em brasa que ganharam vida. Pula na sua direção quando você se aproxima.',
    anim: { parado: ['parado.png', 8, 8], andar: ['andar.png', 10, 12], ataque: ['ataque.png', 11, 16], dano: ['dano.png', 4, 14], morte: ['morte.png', 13, 16] }
  },
  f: {
    nome: 'Cogumelo voador', pasta: 'voador/', quadro: [64, 64], centro: 31, pe: 58, direita: false, escala: 0.9, caixa: [30, 40], flutua: true, brilho: 285, diario: [11, 4, 41, 53],
    texto: 'Esporos que aprenderam a flutuar. Persegue quem passa perto e ignora os muros.',
    anim: { parado: ['parado.png', 8, 8], andar: ['andar.png', 8, 12], ataque: ['ataque.png', 3, 9], dano: ['dano.png', 4, 14], morte: ['morte.png', 17, 16] }
  },
  creditos: 'Forest Monsters FREE, Golems Free Version e Flying Forest Enemies FREE (itch.io)'
});
