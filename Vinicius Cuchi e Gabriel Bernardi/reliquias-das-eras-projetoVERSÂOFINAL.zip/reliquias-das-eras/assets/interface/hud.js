// Gerado por ferramentas/gerar_hud.py — vida (lanternas), tanque de energia (esfera) e ícone de salvar (cristal)
// lanterna.quadro = tamanho de cada lanterna; acesa/trinca/quebrada = quadros da folha; chama = centro do brilho
// esfera.centro/raio = centro e raio do vidro dentro de esfera.png (o líquido é desenhado pelo jogo)
// aura = aura verde da cura (quadros lado a lado); centro = meio do anel dentro do quadro
registrarInterface({ hud: {"lanterna": {"arquivo": "lanterna.png", "quadro": [13, 22], "acesa": [0, 1, 2], "trinca": [3, 4], "quebrada": 5, "chama": [6, 14.5]}, "esfera": {"arquivo": "esfera.png", "vidro": "esfera_vidro.png", "centro": [65.5, 65.0], "raio": 53.0}, "cristal": {"arquivo": "cristal.png", "quadro": [105, 126], "gira": [0, 33], "parado": [33, 14], "fps": 16}, "aura": {"arquivo": "aura_cura.png", "quadro": [125, 170], "n": 13, "fps": 16, "centro": [63.8, 92.9]}} });
