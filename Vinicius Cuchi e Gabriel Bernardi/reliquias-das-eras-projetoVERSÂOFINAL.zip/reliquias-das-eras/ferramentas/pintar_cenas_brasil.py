#!/usr/bin/env python3
"""
pintar_cenas_brasil.py — pinta as "fotos" das duas fases do Brasil (não havia foto disponível):
  fotos/15.jpg  Brasil Colonial: igreja barroca de duas torres, casario colorido de telhado de barro, coqueiros
  fotos/22.jpg  Brasil Imperial: palácio neoclássico (inspirado no Museu Imperial de Petrópolis) e palmeiras imperiais
O céu é azul liso de propósito: o montar_cenarios.py tira o céu e põe o do estilo do jogo.
Depois de rodar este script:  python3 ferramentas/montar_cenarios.py 14 21
Para usar uma foto de verdade, é só trocar fotos/15.jpg ou fotos/22.jpg e rodar o montar_cenarios.py.
"""
import os, math, random
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

AQUI = os.path.dirname(os.path.abspath(__file__))
FOTOS = os.path.join(AQUI, 'fotos')
W, H, K = 1024, 640, 2                       # tamanho final e supersampling


def cor(h, j=0):
    h = h.lstrip('#'); c = [int(h[i:i + 2], 16) for i in (0, 2, 4)]
    return tuple(max(0, min(255, v + j)) for v in c)


class Tela:
    def __init__(self, seed):
        self.im = Image.new('RGB', (W * K, H * K)); self.d = ImageDraw.Draw(self.im); random.seed(seed); np.random.seed(seed)
        ceu = np.zeros((H * K, W * K, 3), np.float32); y = np.linspace(0, 1, H * K)[:, None]
        top, base = np.array(cor('#3d82d0')), np.array(cor('#a9d0f0'))
        ceu[:] = (top * (1 - y) + base * y)[:, None, :] if False else (top[None, None, :] * (1 - y[..., None]) + base[None, None, :] * y[..., None])
        self.im = Image.fromarray(ceu.astype(np.uint8)); self.d = ImageDraw.Draw(self.im)
    def S(self, *v): return [x * K for x in v]
    def ret(self, x0, y0, x1, y1, c): self.d.rectangle(self.S(x0, y0, x1, y1), fill=c)
    def pol(self, pts, c): self.d.polygon([(x * K, y * K) for x, y in pts], fill=c)
    def elip(self, x0, y0, x1, y1, c): self.d.ellipse(self.S(x0, y0, x1, y1), fill=c)
    def lin(self, pts, c, w): self.d.line([(x * K, y * K) for x, y in pts], fill=c, width=max(1, int(w * K)))
    def arco(self, x0, y0, x1, y1, c):   # janela/porta em arco
        r = (x1 - x0) / 2; self.elip(x0, y0, x1, y0 + 2 * r, c); self.ret(x0, y0 + r, x1, y1, c)
    def morros(self, base, amp, c, seed, passo=40):
        rnd = random.Random(seed); pts = [(0, H)]; x = -20
        while x < W + 40:
            pts.append((x, base - amp * (.5 + .5 * math.sin(x * .006 + seed)) - rnd.random() * amp * .35)); x += passo
        pts.append((W, H)); self.pol(pts, c)
    def coqueiro(self, x, y, alt, inc, folha='#2f5a2a'):
        pts = [(x + inc * (t ** 1.6) * alt * .35, y - t * alt) for t in np.linspace(0, 1, 12)]
        self.lin(pts, cor('#6a5236'), 7); self.lin(pts, cor('#8a6a46'), 3)
        tx, ty = pts[-1]
        for a in np.linspace(-2.9, -.25, 9):
            L = alt * .32; ex, ey = tx + math.cos(a) * L, ty + math.sin(a) * L * .55 + L * .35
            mx, my = tx + math.cos(a) * L * .5, ty + math.sin(a) * L * .4
            self.lin([(tx, ty), (mx, my), (ex, ey)], cor(folha, random.randint(-12, 14)), 6)
        self.elip(tx - 7, ty - 4, tx + 7, ty + 8, cor('#5a4a2a'))
    def palmeira_imperial(self, x, y, alt):
        self.ret(x - 5, y - alt, x + 5, y, cor('#b8b0a0')); self.ret(x - 5, y - alt, x - 2, y, cor('#d8d2c4')); self.ret(x + 2, y - alt, x + 5, y, cor('#8a8478'))
        self.ret(x - 7, y - alt - 26, x + 7, y - alt, cor('#5e8a3a'))
        tx, ty = x, y - alt - 26
        for a in np.linspace(-3.0, -.15, 11):
            L = 70; ex, ey = tx + math.cos(a) * L, ty + math.sin(a) * L * .45 + 34
            self.lin([(tx, ty), (tx + math.cos(a) * L * .5, ty + math.sin(a) * L * .35), (ex, ey)], cor('#2e5a26', random.randint(-10, 16)), 7)
    def textura(self, forca=10, borra=1.2):
        a = np.asarray(self.im).astype(np.int16); r = np.random.randint(-forca, forca + 1, a.shape[:2])[..., None]
        self.im = Image.fromarray(np.clip(a + r, 0, 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(borra)); self.d = ImageDraw.Draw(self.im)
    def salvar(self, nome):
        self.im.resize((W, H), Image.LANCZOS).save(os.path.join(FOTOS, nome), quality=92); print('ok', nome)


def janela(t, x, y, w, h, veneziana='#2f6a4a', moldura='#f2ecdc'):
    t.ret(x - 3, y - 3, x + w + 3, y + h + 3, cor(moldura)); t.ret(x, y, x + w, y + h, cor('#2a2a30'))
    t.ret(x, y, x + w * .5 - 1, y + h, cor(veneziana)); t.ret(x + w * .5 + 1, y, x + w, y + h, cor(veneziana, -18))
    for k in range(1, 5): t.ret(x, y + h * k / 5, x + w, y + h * k / 5 + 1, cor(veneziana, -35))


def telhado(t, x0, x1, y, alt, c='#a24a2a'):
    t.pol([(x0 - 10, y), (x1 + 10, y), (x1 - 6, y - alt), (x0 + 6, y - alt)], cor(c))
    for k in range(int((x1 - x0) / 9)):
        xx = x0 - 6 + k * 9; t.lin([(xx, y), (xx + 5, y - alt)], cor(c, -30), 1.4)
    t.ret(x0 - 10, y - 3, x1 + 10, y + 2, cor(c, -40))


def colonial():
    t = Tela(15)
    t.morros(420, 120, cor('#5b8a5a'), 3, 60)
    t.morros(470, 70, cor('#3e6e3a'), 7, 45)
    chao = 560
    # casario dos dois lados
    casas = [(-10, 150, '#e8c45a', 2), (150, 270, '#6a9ac8', 2), (740, 860, '#e6a49a', 2), (860, 1040, '#ecd9a0', 2), (270, 330, '#f0ece0', 1), (690, 745, '#9ac69a', 1)]
    for x0, x1, c, and_ in casas:
        top = chao - (170 if and_ == 2 else 105)
        t.ret(x0, top, x1, chao, cor(c)); t.ret(x0, top, x0 + 6, chao, cor(c, -25)); t.ret(x1 - 6, top, x1, chao, cor(c, -25))
        telhado(t, x0, x1, top, 34)
        for k in range(and_):
            yy = top + 22 + k * 80
            for xx in np.arange(x0 + 16, x1 - 30, 42): janela(t, xx, yy, 22, 40)
        t.ret((x0 + x1) / 2 - 14, chao - 58, (x0 + x1) / 2 + 14, chao, cor('#5a3a1e'))
    # igreja barroca
    cx, base = 512, chao
    corpo = (402, 622); topo_corpo = 300
    t.ret(corpo[0], topo_corpo, corpo[1], base, cor('#efe8d8'))
    for tx in (330, 622):                                   # torres
        t.ret(tx, 210, tx + 72, base, cor('#ece4d2')); t.ret(tx, 210, tx + 8, base, cor('#cfc4ac')); t.ret(tx + 64, 210, tx + 72, base, cor('#cfc4ac'))
        t.ret(tx - 4, 205, tx + 76, 214, cor('#c9b48a')); t.ret(tx - 4, 300, tx + 76, 306, cor('#c9b48a'))
        t.arco(tx + 20, 226, tx + 52, 284, cor('#2a2420')); t.elip(tx + 27, 246, tx + 45, 266, cor('#b08a3a'))   # sino
        t.pol([(tx - 2, 205), (tx + 74, 205), (tx + 60, 172), (tx + 36, 150), (tx + 12, 172)], cor('#8a4a2a'))   # cúpula
        t.lin([(tx + 36, 150), (tx + 36, 124)], cor('#3a3028'), 3); t.lin([(tx + 28, 134), (tx + 44, 134)], cor('#3a3028'), 3)
        janela(t, tx + 24, 340, 24, 44, '#3a5a8a', '#c9b48a')
    # frontão curvo com volutas e cruz
    t.pol([(402, 300), (622, 300), (600, 262), (560, 240), (512, 214), (464, 240), (424, 262)], cor('#ece4d2'))
    t.lin([(402, 300), (424, 262), (464, 240), (512, 214), (560, 240), (600, 262), (622, 300)], cor('#c9b48a'), 5)
    t.elip(496, 240, 528, 272, cor('#c9b48a')); t.elip(502, 246, 522, 266, cor('#3a5a8a'))
    t.lin([(512, 214), (512, 178)], cor('#3a3028'), 4); t.lin([(500, 190), (524, 190)], cor('#3a3028'), 4)
    t.ret(402, 296, 622, 304, cor('#c9b48a'))
    for xx in (420, 590): t.ret(xx, 304, xx + 14, base, cor('#c9b48a'))     # pilastras de pedra
    t.arco(480, 430, 544, base, cor('#5a3a1e')); t.lin([(512, 450), (512, base)], cor('#3a2412'), 2)   # porta
    t.ret(472, 424, 552, 432, cor('#c9b48a'))
    for xx in (436, 560): janela(t, xx, 330, 26, 52, '#3a5a8a', '#c9b48a')
    t.elip(492, 322, 532, 362, cor('#c9b48a')); t.elip(498, 328, 526, 356, cor('#3a5a8a'))
    # coqueiros e chão de pedra
    for x, a, inc in [(60, 300, .5), (230, 250, -.4), (790, 280, .45), (975, 320, -.5), (690, 210, .3)]:
        t.coqueiro(x, chao + 8, a, inc)
    t.ret(0, chao, W, H, cor('#8a7a62'))
    for k in range(260):
        x, y = random.uniform(0, W), random.uniform(chao + 4, H); r = random.uniform(6, 14)
        t.elip(x - r, y - r * .5, x + r, y + r * .5, cor('#a0907a', random.randint(-30, 20)))
    t.textura(9, 1.0); t.salvar('15.jpg')


def imperial():
    t = Tela(22)
    t.morros(380, 150, cor('#5a7a8a'), 11, 70)
    t.morros(440, 90, cor('#4a7a4a'), 5, 50)
    chao = 560
    x0, x1, topo = 150, 874, 300
    rosa, branco = '#e2a294', '#f4efe4'
    t.ret(x0, topo, x1, chao, cor(rosa))
    t.ret(x0, topo - 18, x1, topo, cor(branco)); t.ret(x0 - 6, topo - 24, x1 + 6, topo - 16, cor('#d8d0c0'))   # cornija
    for xx in np.arange(x0, x1, 18): t.ret(xx + 4, topo - 46, xx + 10, topo - 24, cor(branco))           # balaustrada
    t.ret(x0, topo - 50, x1, topo - 44, cor(branco))
    t.ret(x0, 420, x1, 428, cor(branco))                                                                   # friso entre andares
    for xx in np.arange(x0, x1 + 1, 62): t.ret(xx - 5, topo, xx + 5, chao, cor(branco, -8))               # pilastras
    for xx in np.arange(x0 + 18, x1 - 30, 62):
        if 440 < xx < 580: continue
        t.arco(xx, 330, xx + 26, 400, cor(branco)); t.arco(xx + 4, 334, xx + 22, 398, cor('#3a4a5a'))
        t.ret(xx - 2, 446, xx + 28, 530, cor(branco)); t.ret(xx + 2, 450, xx + 24, 530, cor('#3a4a5a'))
        t.ret(xx + 12, 450, xx + 14, 530, cor(branco))
    # pórtico central com colunas e frontão
    px0, px1 = 430, 594
    t.ret(px0, topo - 30, px1, chao, cor(rosa, 8))
    t.pol([(px0 - 14, topo - 30), (px1 + 14, topo - 30), ((px0 + px1) / 2, topo - 110)], cor(branco))
    t.pol([(px0 + 8, topo - 36), (px1 - 8, topo - 36), ((px0 + px1) / 2, topo - 98)], cor(rosa, 10))
    t.elip(496, topo - 82, 528, topo - 50, cor('#d8b04a')); t.ret(500, topo - 92, 524, topo - 82, cor('#d8b04a'))   # coroa
    for k in range(5):
        xx = px0 + 6 + k * 37; t.ret(xx, topo - 28, xx + 16, chao, cor(branco)); t.ret(xx, topo - 28, xx + 5, chao, cor('#d8d0c0'))
        t.ret(xx - 4, topo - 32, xx + 20, topo - 24, cor(branco)); t.ret(xx - 4, chao - 10, xx + 20, chao, cor(branco))
    t.arco(492, 470, 532, chao, cor('#4a3020'))
    t.lin([(512, topo - 110), (512, topo - 190)], cor('#3a3a3a'), 3)                                      # mastro
    t.ret(514, topo - 190, 570, topo - 156, cor('#2e8a3a')); t.pol([(542, topo - 186), (566, topo - 173), (542, topo - 160), (518, topo - 173)], cor('#f0c832'))
    t.elip(536, topo - 180, 548, topo - 168, cor('#2e8a3a')); t.ret(538, topo - 186, 546, topo - 180, cor('#d8b04a'))   # brasão com a coroa (bandeira do Império)
    # palmeiras imperiais, gramado e caminho
    for x, a in [(60, 330), (110, 300), (930, 320), (980, 300), (300, 240), (724, 240)]:
        t.palmeira_imperial(x, chao + 6, a)
    t.ret(0, chao, W, H, cor('#4e7a3a'))
    t.pol([(440, H), (584, H), (552, chao), (472, chao)], cor('#c8b898'))
    for k in range(200):
        x, y = random.uniform(0, W), random.uniform(chao + 2, H)
        t.lin([(x, y), (x + random.uniform(-3, 3), y - random.uniform(4, 9))], cor('#3e6a2e', random.randint(-15, 20)), 1.5)
    t.textura(8, 1.0); t.salvar('22.jpg')


if __name__ == '__main__':
    colonial(); imperial()
