# Gera a fonte de pixel dos menus (estilo da tela de título): assets/interface/fonte.png + fonte.js
# Usa a fonte Jersey 15 (licença SIL OFL, ferramentas/fontes/OFL-Jersey.txt) desenhada no tamanho nativo
# (15 px), sem suavização: cada letra vira um bloquinho de pixels. O jogo amplia 2x ou 3x sem borrar.
# Uso: python3 ferramentas/gerar_fonte.py
import os, json
from PIL import Image, ImageDraw, ImageFont

AQUI = os.path.dirname(os.path.abspath(__file__))
RAIZ = os.path.dirname(AQUI)
FONTE = os.path.join(AQUI, 'fontes', 'jersey-15-latin-400-normal.ttf')
TAM = 15
CHARS = ''.join(chr(c) for c in range(32, 127)) + 'ÀÁÂÃÇÉÊÍÓÔÕÚÜàáâãçéêíóôõúü·ºª«»'

def main():
    F = ImageFont.truetype(FONTE, TAM)
    asc, desc = F.getmetrics()
    altura = asc + desc + 2
    base = asc + 1
    x = 1; itens = {}; imgs = []
    for ch in CHARS:
        adv = round(F.getlength(ch))
        l, t, r, b = F.getbbox(ch, anchor='ls')
        larg = max(adv, r) - min(0, l) + 1
        im = Image.new('L', (larg, altura), 0); d = ImageDraw.Draw(im); d.fontmode = '1'
        d.text((-min(0, l), base), ch, font=F, fill=255, anchor='ls')
        imgs.append((x, im))
        itens[ch] = [x, larg, adv, -min(0, l)]      # posição na folha, largura do recorte, avanço, recuo à esquerda
        x += larg + 1
    folha = Image.new('RGBA', (x, altura), (0, 0, 0, 0))
    for (px, im) in imgs:
        branco = Image.new('RGBA', im.size, (255, 255, 255, 255))
        folha.paste(branco, (px, 0), im)
    folha.save(os.path.join(RAIZ, 'assets', 'interface', 'fonte.png'))
    with open(os.path.join(RAIZ, 'assets', 'interface', 'fonte.js'), 'w', encoding='utf-8') as f:
        f.write('// Gerado por ferramentas/gerar_fonte.py — fonte de pixel dos menus (Jersey 15, licença SIL OFL).\n')
        f.write('// letras[c] = [x na folha, largura do recorte, avanço, recuo]; altura = altura da linha; base = linha de base\n')
        f.write('registrarInterface({ fonte: ' + json.dumps({'arquivo': 'fonte.png', 'altura': altura, 'base': base, 'maiuscula': 8,
                                                             'letras': itens}, ensure_ascii=False) + ' });\n')
    print('fonte', folha.size, 'altura', altura, 'base', base)

if __name__ == '__main__':
    main()
