# Gera as peças novas da interface:
#   assets/interface/lanterna.png  — a vida (uma lanterna por máscara) e a animação dela quebrando
#   assets/interface/esfera.png    — moldura da esfera do tanque de energia (recortada de referencias/esfera_ui.webp)
#   assets/interface/esfera_vidro.png — o brilho do vidro, desenhado por cima do líquido
#   assets/interface/cristal.png   — ícone de salvar/carregar (quadros do referencias/cristal.gif, sem o fundo e sem a marca)
#   assets/interface/aura_cura.png — aura verde em volta do personagem enquanto ele se cura (referencias/aura_cura.gif)
#   assets/hallokin/olhos.png      — os olhos da abóbora acesos (mesma grade da folha do Hallokin), para quando ele está com 1 de vida
#   assets/interface/hud.js        — medidas de tudo isso (lido pelo jogo)
# A lanterna é redesenhada em pixel art limpa a partir de referencias/lanterna.webp (sem o pé), porque a imagem
# original não tem uma grade de pixels regular e encolhida fica borrada.
# Uso: python3 ferramentas/gerar_hud.py
import os, json
import numpy as np
from PIL import Image, ImageSequence

AQUI = os.path.dirname(os.path.abspath(__file__))
RAIZ = os.path.dirname(AQUI)
REF = os.path.join(AQUI, 'referencias')
INT = os.path.join(RAIZ, 'assets', 'interface')
HK = os.path.join(RAIZ, 'assets', 'hallokin')

def hexrgb(h):
    h = h.lstrip('#'); return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4)) + (255,)

# ---------------------------------------------------------------- lanterna
# grade de 13 x 22. Letras = cores (paleta tirada da lanterna de referência)
COR = {
    'k': '#1c0014',   # contorno
    'd': '#3a0620',   # metal escuro
    'm': '#5e1a34',   # metal
    'r': '#83404e',   # telhado
    'h': '#a8727a',   # brilho do telhado
    'l': '#c99a96',   # reflexo claro
    'n': '#7a2a1c',   # aro de baixo
    'o': '#c8641e',   # vidro escuro (âmbar)
    'a': '#f0a83a',   # vidro laranja
    'y': '#ffd768',   # vidro amarelo
    'p': '#fff0b0',   # vidro claro
    'w': '#ffffff',   # chama
    'g': '#8a3e14',   # treliça do vidro
}
LANTERNA = [
    '....kkkkk....',
    '...k.....k...',
    '...k..k..k...',
    '....k.d.k....',
    '.....kdk.....',
    '....kdmdk....',
    '...kmrhrmk...',
    '..kmrhlhrmk..',
    '.kmrrhhhrrmk.',
    'kdmmmmmmmmmdk',
    '.kdnkdddkndk.',
    '.kaodyyydoak.',
    '.koaagygaaok.',
    '.kogadpdagok.',
    '.kaogpwpgoak.',
    '.kaoypwpyoak.',
    '.kogadpdagok.',
    '.koaagygaaok.',
    '.kaodyyydoak.',
    '.kdnkdddkndk.',
    'kdmmmmmmmmmdk',
    '.kkddmmmddkk.',
]
LW, LH = 13, 22

def grade(linhas, cores):
    im = Image.new('RGBA', (LW, LH), (0, 0, 0, 0)); px = im.load()
    for y, ln in enumerate(linhas):
        for x, ch in enumerate(ln):
            if ch != '.': px[x, y] = cores[ch] if isinstance(cores[ch], tuple) else hexrgb(cores[ch])
    return im

def variante(trocas, rachaduras=(), buracos=(), apagada=False, cacos=()):
    cores = dict(COR); cores.update(trocas)
    linhas = [list(l) for l in LANTERNA]
    for (x, y) in rachaduras:
        if linhas[y][x] in 'oaypwg': linhas[y][x] = 'g'
    for (x, y) in buracos:
        if linhas[y][x] in 'oaypwg': linhas[y][x] = 'v'
    for (x, y) in cacos: linhas[y][x] = 'c'
    cores['v'] = '#14040c'; cores['c'] = '#d8d2c8'
    if apagada:
        for y, l in enumerate(linhas):
            for x, ch in enumerate(l):
                if ch in 'oaypwg': linhas[y][x] = 'v'
    return grade([''.join(l) for l in linhas], cores)

def lanternas():
    q = []
    # acesa: a chama pisca (3 quadros)
    q.append(variante({}))
    q.append(variante({'w': '#fff6d8', 'p': '#ffe69a', 'y': '#ffcc58'}))
    q.append(variante({'p': '#fff8cc', 'y': '#ffe080', 'a': '#f6b446'}))
    # trincando: rachaduras no vidro da frente e dos lados
    r1 = [(5, 11), (6, 12), (6, 13), (7, 14), (2, 13), (3, 14), (9, 16), (10, 17)]
    q.append(variante({'w': '#ffe8b0', 'p': '#ffd890'}, rachaduras=r1))
    r2 = r1 + [(5, 15), (4, 16), (8, 12), (7, 17), (5, 17), (2, 16), (10, 12), (9, 13)]
    q.append(variante({'w': '#ffb860', 'p': '#f0a040', 'y': '#e08a30', 'a': '#b8601c', 'o': '#7a3010'},
                      rachaduras=r2, buracos=[(6, 15), (5, 16), (3, 12), (9, 15)]))
    # quebrada: vidro estilhaçado, chama apagada, só sobram cacos na moldura
    cacos = [(2, 11), (10, 11), (2, 18), (3, 18), (9, 17), (10, 18), (6, 11), (5, 18)]
    q.append(variante({'m': '#4a1a2c', 'r': '#5e3240', 'h': '#7a525a', 'l': '#8a6a6c', 'n': '#4a2018'}, apagada=True, cacos=cacos))
    folha = Image.new('RGBA', (LW * len(q), LH), (0, 0, 0, 0))
    for i, im in enumerate(q): folha.paste(im, (i * LW, 0))
    folha.save(os.path.join(INT, 'lanterna.png'))
    return {'arquivo': 'lanterna.png', 'quadro': [LW, LH], 'acesa': [0, 1, 2], 'trinca': [3, 4], 'quebrada': 5,
            'chama': [6, 14.5]}   # centro da chama (para o brilho)

# ---------------------------------------------------------------- esfera do tanque de energia
def esfera():
    im = np.asarray(Image.open(os.path.join(REF, 'esfera_ui.webp')).convert('RGB')).astype(float)
    from scipy import ndimage
    lum = im.mean(2); H, W = lum.shape
    cx, cy, ri, ro = 375.5, 225.0, 53.0, 63.5          # centro, raio do vidro e raio de fora do aro (medidos no perfil do anel)
    yy, xx = np.mgrid[0:H, 0:W]
    d = np.hypot(xx - cx, yy - cy)
    anel = (d >= ri - .5) & (d <= ro)
    # na metade de baixo a parte de dentro do aro mostra o líquido verde: copia a cor do aro espelhado (de cima)
    verde = anel & (yy > cy) & (im[..., 1] > im[..., 0] - 6) & (im[..., 1] > im[..., 2] + 22)
    vy, vx = np.where(verde)
    im[vy, vx] = im[np.clip((2 * cy - vy).astype(int), 0, H - 1), vx]
    lum = im.mean(2)
    # enfeite de baixo: só dentro desta área (peça do meio + as duas asas que seguem o aro) e só o que
    # é bem mais claro (bronze) ou bem mais escuro (sombra do metal) que o fundo marrom da imagem
    area = ((np.abs(xx - cx) < 15) & (yy > cy + 40) & (yy < cy + 88)) | \
           ((np.abs(xx - cx) < 40) & (d > ro - 2) & (d < ro + 9) & (yy > cy + 44))
    metal = area & ((lum > 70) | (lum < 21))
    metal = ndimage.binary_closing(metal, iterations=2) & area
    metal = ndimage.binary_opening(metal, iterations=1) | (metal & (lum > 90))
    mascara = anel | metal
    lab, n = ndimage.label(mascara)
    mascara = lab == lab[int(cy - (ri + ro) / 2), int(cx)]
    mascara = ndimage.binary_fill_holes(mascara | (d < ri)) & ~(d < ri - .5)
    alfa = ndimage.gaussian_filter(mascara.astype(float), .55)
    alfa[d < ri - 1] = 0
    ys, xs = np.where(alfa > .05)
    x0, x1, y0, y1 = xs.min() - 1, xs.max() + 2, ys.min() - 1, ys.max() + 2
    rgba = np.dstack([im, np.clip(alfa * 255, 0, 255)])[y0:y1, x0:x1].astype(np.uint8)
    Image.fromarray(rgba, 'RGBA').save(os.path.join(INT, 'esfera.png'))
    # vidro: o reflexo branco e a borda clara de cima (tirados da imagem) + sombra por dentro do aro
    dentro = d < ri - .5
    base = ndimage.median_filter(lum, size=11)
    realce = np.clip((lum - base - 5) / 55, 0, 1) * dentro * (yy < cy - 4)
    realce = ndimage.gaussian_filter(realce, .5)
    vidro = np.zeros((H, W, 4)); vidro[..., :3] = 255; vidro[..., 3] = realce * 235
    sombra = np.clip((d - (ri - 10)) / 10, 0, 1) * dentro
    v2 = np.zeros((H, W, 4)); v2[..., 3] = sombra ** 1.7 * 185
    comp = Image.alpha_composite(Image.fromarray(v2.astype(np.uint8), 'RGBA'), Image.fromarray(vidro.astype(np.uint8), 'RGBA'))
    comp.crop((x0, y0, x1, y1)).save(os.path.join(INT, 'esfera_vidro.png'))
    return {'arquivo': 'esfera.png', 'vidro': 'esfera_vidro.png', 'centro': [round(cx - x0, 1), round(cy - y0, 1)], 'raio': ri}

# ---------------------------------------------------------------- cristal de salvar/carregar
def cristal():
    gif = Image.open(os.path.join(REF, 'cristal.gif'))
    fr = [np.asarray(f.convert('RGBA')).copy() for f in ImageSequence.Iterator(gif)]
    fundo = fr[0][2, 2, :3].astype(int)
    gira = list(range(146, 211, 2))      # girando com fogo (salvando / carregando)
    parado = list(range(0, 28, 2))       # flutuando parado (pronto)
    todos = gira + parado
    mascaras = []
    for i in todos:
        f = fr[i].astype(int); m = np.abs(f[..., :3] - fundo).sum(2) > 18
        m[:, 330:] = False; m[250:, :] = False              # fora a marca no canto
        mascaras.append(m)
    uni = np.any(mascaras, 0); ys, xs = np.where(uni)
    x0, x1, y0, y1 = xs.min(), xs.max() + 1, ys.min(), ys.max() + 1
    w, h = x1 - x0, y1 - y0
    folha = Image.new('RGBA', (w * len(todos), h), (0, 0, 0, 0))
    for k, (i, m) in enumerate(zip(todos, mascaras)):
        f = fr[i].copy(); f[..., 3] = np.where(m, 255, 0)
        # cores misturadas com o roxo do fundo (sombra do anel) ficam meio transparentes
        roxo = (np.abs(f[..., :3].astype(int) - fundo).sum(2) < 70) & m
        f[..., 3] = np.where(roxo, 110, f[..., 3])
        folha.paste(Image.fromarray(f[y0:y1, x0:x1], 'RGBA'), (k * w, 0))
    folha.save(os.path.join(INT, 'cristal.png'))
    return {'arquivo': 'cristal.png', 'quadro': [int(w), int(h)], 'gira': [0, len(gira)], 'parado': [len(gira), len(parado)], 'fps': 16}

# ---------------------------------------------------------------- aura da cura
def aura():
    gif = Image.open(os.path.join(REF, 'aura_cura.gif'))
    fr = [np.asarray(f.convert('RGB')).astype(float) for f in ImageSequence.Iterator(gif)]
    x0, y0, x1, y1 = 126, 64, 376, 404                      # em volta do que se mexe (com folga)
    esc = .5
    w, h = int((x1 - x0) * esc), int((y1 - y0) * esc)
    folha = Image.new('RGBA', (w * len(fr), h), (0, 0, 0, 0))
    cxs, cys = [], []
    for k, a in enumerate(fr):
        a = a[y0:y1, x0:x1]
        v = a.max(2)
        alfa = np.clip((v - 20) / 200, 0, 1) ** 1.15          # o fundo escuro some; o brilho vira transparência
        cor = np.clip(a / np.maximum(v[..., None], 1) * 255, 0, 255)
        rgba = np.dstack([cor, alfa * 255]).astype(np.uint8)
        im = Image.fromarray(rgba, 'RGBA').resize((w, h), Image.LANCZOS)
        folha.paste(im, (k * w, 0))
        ys, xs = np.where(v > 150); cxs.append(xs.mean()); cys.append(ys.mean())
    folha.quantize(colors=256, method=Image.Quantize.FASTOCTREE).save(os.path.join(INT, 'aura_cura.png'), optimize=True)   # 256 cores: bem menor
    return {'arquivo': 'aura_cura.png', 'quadro': [w, h], 'n': len(fr), 'fps': 16,
            'centro': [round(float(np.mean(cxs)) * esc, 1), round(float(np.mean(cys)) * esc, 1)]}

# ---------------------------------------------------------------- olhos acesos do Hallokin
def olhos():
    folha = np.asarray(Image.open(os.path.join(HK, 'hallokin.png')).convert('RGBA')).astype(int)
    H, W, _ = folha.shape; C = 96
    out = np.zeros_like(folha)
    centros = {}
    for ly in range(H // C):
        linha = []
        for cx in range(W // C):
            q = folha[ly * C:(ly + 1) * C, cx * C:(cx + 1) * C]
            a = q[..., 3] > 0; r, g, b = q[..., 0], q[..., 1], q[..., 2]
            laranja = a & (r > 170) & (g > 30) & (g < 140) & (b < 80)
            if laranja.sum() < 12: linha.append(None); continue
            ys, xs = np.where(laranja)
            # cabeça = maior bloco laranja no alto do quadro
            topo, base = ys.min(), ys.min() + 13
            sel = ys <= base; ys, xs = ys[sel], xs[sel]
            x0, x1, y0, y1 = xs.min(), xs.max(), ys.min(), ys.max()
            preto = a & (r < 40) & (g < 40) & (b < 40)
            olho = np.zeros_like(preto)
            for y in range(y0 + 1, y1):
                for x in range(x0 + 1, x1):
                    if not preto[y, x]: continue
                    # olho: preto com laranja em cima, embaixo e de pelo menos um lado
                    esq = laranja[y, x0:x].any(); dir_ = laranja[y, x + 1:x1 + 1].any()
                    cima = laranja[y0:y, x].any(); baixo = laranja[y + 1:y1 + 1, x].any()
                    if cima and baixo and (esq or dir_): olho[y, x] = True   # o olho da frente pode encostar na borda da cabeça
            if olho.sum() == 0: linha.append(None); continue
            oy, ox = np.where(olho)
            bloco = out[ly * C:(ly + 1) * C, cx * C:(cx + 1) * C]
            bloco[olho] = [255, 226, 96, 255]
            # o miolo do olho mais claro
            for y, x in zip(oy, ox):
                viz = sum(olho[y + dy, x + dx] for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)))
                if viz >= 3: bloco[y, x] = [255, 250, 210, 255]
            linha.append([round(float(ox.mean()) + .5, 1), round(float(oy.mean()) + .5, 1),
                          round(float((x0 + x1) / 2) + .5, 1), round(float((y0 + y1) / 2) + .5, 1)])
        centros[ly] = linha
    Image.fromarray(out.astype(np.uint8), 'RGBA').save(os.path.join(HK, 'olhos.png'))
    return {'arquivo': 'olhos.png', 'centros': centros}

def main():
    hud = {'lanterna': lanternas(), 'esfera': esfera(), 'cristal': cristal(), 'aura': aura()}
    ol = olhos()
    with open(os.path.join(INT, 'hud.js'), 'w', encoding='utf-8') as f:
        f.write('// Gerado por ferramentas/gerar_hud.py — vida (lanternas), tanque de energia (esfera) e ícone de salvar (cristal)\n')
        f.write('// lanterna.quadro = tamanho de cada lanterna; acesa/trinca/quebrada = quadros da folha; chama = centro do brilho\n')
        f.write('// esfera.centro/raio = centro e raio do vidro dentro de esfera.png (o líquido é desenhado pelo jogo)\n')
        f.write('// aura = aura verde da cura (quadros lado a lado); centro = meio do anel dentro do quadro\n')
        f.write('registrarInterface({ hud: ' + json.dumps(hud, ensure_ascii=False) + ' });\n')
    with open(os.path.join(HK, 'olhos.js'), 'w', encoding='utf-8') as f:
        f.write('// Gerado por ferramentas/gerar_hud.py — olhos acesos da abóbora (mesma grade de hallokin.png).\n')
        f.write('// centros[linha][coluna] = [x, y do meio dos olhos, x, y do meio da cabeça] em px do quadro (null = sem olhos visíveis)\n')
        f.write('if (typeof PERSONAGEM != "undefined" && PERSONAGEM) PERSONAGEM.olhos = ' + json.dumps(ol) + ';\n')
    print(json.dumps(hud)[:600])
    print('olhos', sum(1 for l in ol['centros'].values() for c in l if c), 'quadros com olhos')

if __name__ == '__main__':
    main()
