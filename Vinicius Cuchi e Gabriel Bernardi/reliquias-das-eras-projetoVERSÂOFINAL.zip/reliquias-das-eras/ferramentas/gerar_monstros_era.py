#!/usr/bin/env python3
"""
gerar_monstros_era.py — desenha (em pixel art, quadro a quadro) os monstros próprios das épocas
industriais e das guerras do século XX, no mesmo formato dos outros monstros (assets/monstros):

  Revolução Industrial (tema 'vapor')        Guerras do século XX (tema 'guerra')
    w  Autômato de Engrenagens (anda)          w  Tanque de Corda (anda)
    h  Caldeira Saltadora (pula)               h  Mina Saltadora (pula)
    f  Ornitóptero de Latão (voa)              f  Zepelim de Vigia (voa)

Cada um ganha uma pasta em assets/monstros/ com parado.png, andar.png, ataque.png, dano.png e morte.png
(quadros de 40x40 lado a lado, desenhados em 1x; o jogo mostra em 2x) e o manifesto
assets/monstros/monstros_era.js (tamanhos, animações, textos do Diário e em quais épocas aparecem).
Uso: python3 ferramentas/gerar_monstros_era.py     (precisa de pillow, numpy e scipy)
"""
import os, math, json
import numpy as np
from PIL import Image, ImageDraw
from scipy import ndimage as nd

AQUI = os.path.dirname(os.path.abspath(__file__))
PASTA = os.path.join(os.path.dirname(AQUI), 'assets', 'monstros')
QW = QH = 40
Y, X = np.mgrid[0:QH, 0:QW] + .5

def hexc(h, a=255):
    h = h.lstrip('#'); return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)
def pal(*hs): return [hexc(h) for h in hs]
LATAO = pal('2a1606', '5a3410', '8a5a1c', 'b8842e', 'e0b450', 'fff0b0')
FERRO = pal('121218', '26262e', '3e3e4a', '5c5c6a', '8a8a9a', 'c0c0cc')
COBRE = pal('2a0e06', '5a2410', '8a3e1c', 'b8622e', 'e09050', 'ffd0a0')
OLIVA = pal('14180c', '262e16', '3c4a22', '566a32', '7a8e4a', 'b0c07a')
PRATA = pal('1c1e26', '3a3e4c', '5a6070', '7e8496', 'a8aebe', 'd8dce6')
CREME = pal('3a3020', '8a7a5a', 'c8b890', 'f0e6c8', 'fff8e8', 'ffffff')
CONTORNO = hexc('120c10')
FAISCA = [hexc('ffe080'), hexc('ff9a30'), hexc('fff6d0')]
VAPOR = [hexc('e4e4ec', 230), hexc('b8b8c6', 210), hexc('8a8a9a', 180)]
FUMO = [hexc('5a5250', 220), hexc('3a3434', 200), hexc('7a7270', 190)]
FOGO = [hexc('fff2b0'), hexc('ffc93a'), hexc('ff8a1c'), hexc('e2481a'), hexc('8a1e0e')]

# ---------------- máscaras ----------------
def disco(cx, cy, r): return (X - cx) ** 2 + (Y - cy) ** 2 <= r * r
def elipse(cx, cy, rx, ry): return ((X - cx) / rx) ** 2 + ((Y - cy) / ry) ** 2 <= 1
def ret(x0, y0, x1, y1): return (X >= x0) & (X < x1) & (Y >= y0) & (Y < y1)
def poli(pts):
    im = Image.new('L', (QW, QH), 0); ImageDraw.Draw(im).polygon([(x, y) for x, y in pts], fill=1); return np.asarray(im) > 0
def segm(x0, y0, x1, y1, w):
    vx, vy = x1 - x0, y1 - y0; L2 = vx * vx + vy * vy or 1
    u = np.clip(((X - x0) * vx + (Y - y0) * vy) / L2, 0, 1)
    return np.hypot(X - (x0 + vx * u), Y - (y0 + vy * u)) <= w / 2
def engrenagem(cx, cy, r, dentes, ang):
    m = disco(cx, cy, r - 1.1)
    for k in range(dentes):
        a = ang + 2 * math.pi * k / dentes
        m |= segm(cx + math.cos(a) * (r - 2), cy + math.sin(a) * (r - 2), cx + math.cos(a) * (r + .7), cy + math.sin(a) * (r + .7), 2.2)
    return m & ~disco(cx, cy, max(1, r * .28))

class Quadro:
    def __init__(self):
        self.a = np.zeros((QH, QW, 4), np.uint8); self.m = np.zeros((QH, QW), bool); self.solto = []
    def parte(self, m, p, luz=(-.7, -.8), ruido=0.0, seed=1, borda=True):
        if not m.any(): return
        ys, xs = np.nonzero(m); cx, cy = xs.mean(), ys.mean(); w = np.ptp(xs) + 1; h = np.ptp(ys) + 1
        dist = nd.distance_transform_edt(np.pad(m, 1))[1:-1, 1:-1]
        v = .32 + .2 * np.minimum(dist, 3) / 3 + .5 * ((X - cx) * luz[0] + (Y - cy) * luz[1]) / max(w, h, 4)
        if ruido: v = v + ruido * (np.random.default_rng(seed).random(m.shape) - .5)
        k = np.clip((v * (len(p) - 1) + .5).astype(int), 1, len(p) - 1)
        cores = np.array(p, np.uint8)[k]
        self.a[m] = cores[m]
        if borda and m.sum() > 8:      # contorno próprio da peça (separa as partes umas das outras)
            beira = m & ~nd.binary_erosion(m, structure=[[0, 1, 0], [1, 1, 1], [0, 1, 0]])
            sob = beira & self.m        # só onde ela fica por cima de outra peça; o contorno de fora vem no fim
            self.a[sob] = CONTORNO
        self.m |= m
    def cor(self, m, c): self.a[m] = c; self.m |= m
    def px(self, x, y, c):
        x, y = int(x), int(y)
        if 0 <= x < QW and 0 <= y < QH: self.a[y, x] = c; self.m[y, x] = True
    def fumaca(self, cx, cy, r, cores):     # desenhada sem contorno, por cima
        self.solto.append((disco(cx, cy, r), disco(cx - r * .3, cy - r * .3, r * .55), cores))
    def faisca(self, x, y, k=0): self.solto.append(('px', int(x), int(y), FAISCA[k % 3]))
    def pronto(self):
        viz = nd.binary_dilation(self.m, structure=[[0, 1, 0], [1, 1, 1], [0, 1, 0]]) & ~self.m
        a = self.a.copy(); a[viz] = CONTORNO
        for s in self.solto:
            if isinstance(s[0], str):
                _, x, y, c = s
                if 0 <= x < QW and 0 <= y < QH: a[y, x] = c
            else:
                m, luz, cores = s; a[m] = cores[1]; a[m & luz] = cores[0]
        return a

def onda(k, n, fase=0): return math.sin(2 * math.pi * (k / n + fase))

# =====================================================================
#  REVOLUÇÃO INDUSTRIAL
# =====================================================================
def automato(anim, k, n):
    """robô de latão com engrenagem nas costas, chaminé, olho de manômetro e braço de pinça"""
    q = Quadro(); ang = k * .5 + (k * .5 if anim == 'andar' else 0)
    bob = 0; passo = 0; braco = 0; caido = 0; tremor = 0
    if anim == 'parado': bob = 1 if k % 3 == 1 else 0
    if anim == 'andar': passo = onda(k, n); bob = 1 if k % 3 == 0 else 0
    if anim == 'ataque': braco = [0, -1, 3, 5, 4, 1][k]; bob = 1 if k in (2, 3) else 0
    if anim == 'dano': tremor = [-2, 1, -1][k]
    if anim == 'morte': caido = min(k, 6); tremor = [1, -1, 1, 0, 0, 0, 0, 0, 0, 0][k]
    if anim == 'morte' and k >= 6:      # monte de peças com vapor saindo
        q.parte(ret(8, 33, 30, 38) & elipse(19, 37, 12, 4), LATAO, ruido=.3, seed=k)
        q.parte(engrenagem(30 + (k - 6) * 2, 33, 4, 7, k * .8), FERRO)
        q.parte(ret(13, 30, 18, 34), FERRO)
        for j in range(2): q.fumaca(14 + j * 9, 30 - (k - 6) * 3 - j * 2, 3 + (k - 6) * .6, VAPOR)
        return q.pronto()
    dy = bob + caido; dx = tremor
    # engrenagem das costas
    q.parte(engrenagem(10 + dx, 17 + dy, 7, 8, ang), FERRO)
    q.parte(disco(10 + dx, 17 + dy, 2), LATAO)
    # pernas (pistões)
    if anim != 'morte' or k < 4:
        for j, lado in enumerate((-1, 1)):
            off = passo * 2.5 * lado; lev = max(0, -passo * lado) * 1.5
            x = 15 + j * 8 + dx; topo = 28 + dy
            pe = 37 - lev - (caido * .6)
            q.parte(ret(x - 1 + off * .4, topo, x + 2 + off * .4, pe - 1), FERRO if j else pal('121218', '1e1e26', '2e2e38', '46465a', '6a6a7a', '9a9aa8'))
            q.parte(ret(x - 2 + off, pe - 2, x + 4 + off, pe), FERRO)
    # corpo
    corpo = ret(10 + dx, 12 + dy, 29 + dx, 30 + dy) & ~(ret(10 + dx, 12 + dy, 11 + dx, 13 + dy) | ret(28 + dx, 12 + dy, 29 + dx, 13 + dy))
    q.parte(corpo, LATAO, ruido=.12, seed=k)
    q.cor(ret(10 + dx, 21 + dy, 29 + dx, 22 + dy), LATAO[1])
    for (rx, ry) in [(12, 14), (27, 14), (12, 28), (27, 28)]: q.px(rx + dx, ry + dy, LATAO[5])
    # chaminé
    q.parte(ret(13 + dx, 5 + dy, 17 + dx, 12 + dy), FERRO); q.parte(ret(12 + dx, 4 + dy, 18 + dx, 6 + dy), FERRO)
    # rosto: manômetro com o olho
    q.parte(disco(23 + dx, 18 + dy, 4.2), CREME)
    olho = (255, 120, 40, 255) if anim != 'dano' else (255, 255, 255, 255)
    q.px(24 + dx, 17 + dy, olho); q.px(25 + dx, 17 + dy, olho); q.px(24 + dx, 18 + dy, (255, 200, 120, 255))
    q.px(22 + dx, 19 + dy, CONTORNO); q.px(21 + dx, 20 + dy, CONTORNO)
    # braço com pinça
    bx = 26 + dx + braco; by = 25 + dy
    q.parte(ret(24 + dx, by - 1, bx + 3, by + 2), FERRO)
    aberta = anim == 'ataque' and k in (2, 3)
    q.parte(poli([(bx + 2, by - 3), (bx + 7, by - 4 - aberta), (bx + 5, by - 1)]), LATAO)
    q.parte(poli([(bx + 2, by + 2), (bx + 7, by + 3 + aberta), (bx + 5, by)]), LATAO)
    # vapor da chaminé e faíscas
    if anim in ('parado', 'andar'):
        u = (k % n) / n; q.fumaca(15 + dx - u * 3, 2 + dy - u * 4, 1.5 + u * 2, VAPOR)
    if anim == 'ataque' and k in (2, 3, 4): q.fumaca(15 + dx, 1 + dy - k, 2.5 + k * .5, VAPOR)
    if anim == 'dano':
        for j in range(4): q.faisca(20 + j * 3 + dx, 10 + (j * 7 + k * 5) % 14 + dy, j + k)
    if anim == 'morte' and k < 6:
        for j in range(3): q.faisca(12 + (j * 9 + k * 4) % 18, 12 + (j * 5 + k * 3) % 16, j)
        q.fumaca(18, 8 - k, 2 + k * .6, VAPOR)
    return q.pronto()

def caldeira(anim, k, n):
    """caldeira de ferro redonda com faixas de cobre, válvula que apita e pernas de mola"""
    q = Quadro(); sobe = 0; aperta = 0; tremor = 0; quente = 0
    if anim == 'parado': sobe = 1 if k % 3 == 2 else 0
    if anim == 'andar': sobe = [0, -1, -3, -4, -2, 0][k]; aperta = [1, 0, 0, 0, 0, 1][k]
    if anim == 'ataque': aperta = [2, 3, 0, 0, 0, 1][k]; sobe = [1, 2, -4, -6, -4, -1][k]
    if anim == 'dano': tremor = [-2, 2, -1][k]
    if anim == 'morte': quente = min(1, k / 3); tremor = (k % 2) * 2 - 1 if k < 4 else 0
    if anim == 'morte' and k >= 4:      # explodiu: rebites e uma nuvem de vapor
        for j in range(7):
            a = j * 0.9 + 0.4; r = 4 + (k - 4) * 3
            q.cor(ret(20 + math.cos(a) * r, 26 + math.sin(a) * r * .7, 22 + math.cos(a) * r, 28 + math.sin(a) * r * .7), FERRO[3])
        q.parte(elipse(20, 37, 9 - (k - 4), 2), FERRO)
        for j in range(3): q.fumaca(14 + j * 6, 24 - (k - 4) * 2 - j * 3, 4 + (k - 4) * .8 - j, VAPOR)
        return q.pronto()
    cy = 23 + sobe + aperta; dx = tremor
    # pernas de mola
    for j, x in enumerate((15, 25)):
        topo = cy + 8; pe = 37
        alt = pe - topo; zz = max(2, int(alt / 2))
        pts = [(x + dx + (1.6 if i % 2 else -1.6), topo + i * alt / zz) for i in range(zz + 1)]
        for i in range(len(pts) - 1): q.parte(segm(*pts[i], *pts[i + 1], 1.6), FERRO)
        q.parte(ret(x + dx - 3, 36, x + dx + 3, 38), FERRO)
    # corpo
    corpo = elipse(20 + dx, cy, 10, 10 - aperta * .5)
    p = COBRE if quente > .5 else FERRO
    q.parte(corpo, p, ruido=.1, seed=k)
    for yy in (cy - 5, cy + 4):
        q.cor(corpo & ret(0, yy, QW, yy + 1), COBRE[3] if not quente else FOGO[2])
    for j in range(6): q.px(11 + dx + j * 3.6, cy - 5, COBRE[5])
    # válvula e apito
    q.parte(ret(17 + dx, cy - 14, 21 + dx, cy - 9), LATAO); q.parte(ret(16 + dx, cy - 15, 22 + dx, cy - 13), LATAO)
    # olho-manômetro
    q.parte(disco(25 + dx, cy - 1, 3.6), CREME)
    olho = (255, 70, 40, 255) if anim in ('ataque', 'morte') else (255, 160, 60, 255)
    if anim == 'dano': olho = (255, 255, 255, 255)
    q.px(26 + dx, cy - 2, olho); q.px(26 + dx, cy - 1, olho); q.px(24 + dx, cy, CONTORNO)
    if anim in ('parado', 'andar'):
        u = (k % n) / n; q.fumaca(19 + dx, cy - 17 - u * 4, 1.4 + u * 1.6, VAPOR)
    if anim == 'ataque' and k >= 2:
        for j in range(3): q.fumaca(14 + j * 6, 37 - (k - 2), 2.5 + (k - 2) * .4, VAPOR)
    if anim == 'dano': q.fumaca(30 + dx, cy - 6, 2.5, VAPOR)
    if anim == 'morte':
        q.fumaca(19, cy - 17, 2 + k, VAPOR)
        for j in range(3): q.faisca(14 + j * 6, cy - 3 + (j * 3 + k) % 6, j + k)
    return q.pronto()

def ornitoptero(anim, k, n):
    """pássaro mecânico de latão: asas grandes de placas que batem, hélice na cauda e lente azul no olho"""
    q = Quadro(); bate = onda(k, n); incl = 0; cai = 0; tremor = 0
    if anim == 'parado': bate = onda(k, n) * .6
    if anim == 'ataque': incl = [0, 1, 3, 4, 3, 1][k]; bate = [.6, .9, 1, 1, .7, .3][k]
    if anim == 'dano': tremor = [-2, 1, -1][k]
    if anim == 'morte': cai = k * 1.6; incl = min(6, k); bate = .8
    cy = 20 + cai; dx = tremor
    P = lambda x, y: (x + dx, y + (x - 20) * incl * .12)
    PENA = pal('2a1606', '6a4414', '9a6a22', 'c8963a', 'ecc462', 'fff2b8')
    PENA2 = pal('1a0e04', '3a2208', '5a3a12', '7a5420', '9a6e30', 'b88c48')
    def asa(sx, sy, ang, L, p, luz):
        tip = (sx - math.cos(ang) * L * .35, sy - math.sin(ang) * L)        # sobe/desce bastante, um pouco para trás
        pts = [(sx + 2, sy)]
        for j in range(4):                                                     # borda de trás em "penas" de placa
            t = j / 3; bx_ = sx + (tip[0] - sx) * t; by_ = sy + (tip[1] - sy) * t
            pts.append((bx_ - 3.5 - t * 2, by_ + 2.5))
            pts.append((bx_ - 2.5 - t * 2, by_ + .5))
        pts.append(tip); pts.append((tip[0] + 2.5, tip[1] + (1 if ang > 0 else -1)))
        m = poli(pts); q.parte(m, p, luz=luz)
        for j in (1, 2):                                                       # emendas das placas
            t = j / 3; q.px(sx + (tip[0] - sx) * t, sy + (tip[1] - sy) * t, p[1])
    ang = .25 + 1.15 * bate                                                    # >0 = asa para cima
    # asa de trás (mais escura, um pouco defasada)
    sx, sy = P(18, cy - 3); asa(sx, sy, ang * .85 + .15, 12, PENA2, (-.4, -.9))
    # cauda com hélice
    tx, ty = P(10, cy)
    q.parte(poli([P(14, cy - 2), P(14, cy + 2), (tx, ty + 3), (tx, ty - 3)]), LATAO)
    if k % 2 == 0: q.parte(ret(tx - 1, ty - 5, tx + 1, ty + 5), FERRO)
    else: q.parte(ret(tx - 4, ty - 1, tx + 1, ty + 1), FERRO)
    # corpo e cabeça
    bx, by = P(20, cy)
    q.parte(elipse(bx, by, 7, 4), LATAO, ruido=.1, seed=k)
    hx, hy = P(27, cy - 2)
    q.parte(disco(hx, hy, 3.6), LATAO)
    q.parte(poli([(hx + 2, hy - 1.5), (hx + 8, hy + .5 + incl * .3), (hx + 2, hy + 1.8)]), FERRO)
    olho = (110, 230, 255, 255) if anim != 'dano' else (255, 255, 255, 255)
    q.px(hx + 1, hy - 1, olho); q.px(hx + 1, hy - 2, (220, 250, 255, 255))
    for j in range(3): q.px(bx - 4 + j * 3, by - 2, LATAO[5])
    q.cor(ret(bx - 2, by + 4, bx - 1, by + 7), FERRO[2]); q.cor(ret(bx + 2, by + 4, bx + 3, by + 7), FERRO[2])
    # asa da frente (clara)
    sx, sy = P(21, cy - 2); asa(sx, sy, ang, 15, PENA, (-.3, -.9))
    if anim == 'morte':
        q.fumaca(14, cy - 4 - k * .5, 2 + k * .4, FUMO)
        for j in range(2): q.faisca(18 + j * 6, cy + (k * 3 + j * 5) % 7, j + k)
    if anim == 'dano':
        for j in range(3): q.faisca(16 + j * 5, cy - 6 + (j * 4 + k * 3) % 10, j)
    return q.pronto()

# =====================================================================
#  GUERRAS DO SÉCULO XX
# =====================================================================
def tanque(anim, k, n):
    """tanquezinho de corda: esteiras com rodas, torre com canhão curto e a chave de corda girando"""
    q = Quadro(); rec = 0; fogo = 0; tremor = 0; pula = 0
    if anim == 'ataque': rec = [0, 0, -2, -1, 0, 0][k]; fogo = k in (2, 3)
    if anim == 'dano': tremor = [-2, 1, -1][k]
    if anim == 'parado': pula = 1 if k % 3 == 0 else 0
    if anim == 'morte' and k >= 5:
        q.parte(ret(6, 32, 32, 38), pal('0c0c0c', '1c1c1c', '2a2a2a', '3a3a3a', '4a4a4a', '5a5a5a'), ruido=.3, seed=k)
        q.parte(ret(10, 27, 28, 32), pal('0e0e0a', '1e2214', '2a3018', '363e22', '444c2a', '525a32'), ruido=.3, seed=k)
        for j in range(3): q.fumaca(12 + j * 7, 22 - (k - 5) * 3 - j * 2, 3 + (k - 5) * .7, FUMO)
        if k < 8: q.fumaca(20, 26, 5 - (k - 5), [hexc('ffc93a', 230), hexc('ff8a1c', 220), hexc('e2481a')])
        q.parte(engrenagem(31 + k - 5, 36, 2.5, 5, k), FERRO)
        return q.pronto()
    dx = tremor + rec; dy = -pula
    if anim == 'morte': dy = 0
    # esteira
    q.parte(ret(5 + dx, 30, 33 + dx, 38) & ~(ret(5 + dx, 30, 6 + dx, 31) | ret(32 + dx, 30, 33 + dx, 31) | ret(5 + dx, 37, 6 + dx, 38) | ret(32 + dx, 37, 33 + dx, 38)),
            pal('0c0c10', '1c1c22', '2c2c34', '3e3e48', '54545e', '6e6e78'))
    mov = (k * (2 if anim == 'andar' else 0)) % 4
    for xx in range(6 + mov, 33, 4): q.cor(ret(xx + dx, 30, xx + 1 + dx, 31), FERRO[4]); q.cor(ret(xx + dx, 37, xx + 1 + dx, 38), FERRO[3])
    for j in range(3):
        cx = 11 + j * 8 + dx; q.parte(disco(cx, 34, 2.4), FERRO)
        a = k * .8 if anim == 'andar' else 0
        q.px(cx + math.cos(a) * 1.5, 34 + math.sin(a) * 1.5, FERRO[5])
    # casco
    q.parte(poli([(7 + dx, 30 + dy), (31 + dx, 30 + dy), (29 + dx, 24 + dy), (9 + dx, 24 + dy)]), OLIVA, ruido=.1, seed=k)
    for j in range(5): q.px(10 + j * 4.5 + dx, 26 + dy, OLIVA[5])
    # chave de corda
    rot = k % 4 if anim in ('andar', 'parado') else 0
    q.parte(ret(6 + dx, 22 + dy, 9 + dx, 24 + dy), FERRO)
    if rot in (0, 2): q.parte(ret(4 + dx, 17 + dy, 7 + dx, 23 + dy) | ret(2 + dx, 18 + dy, 9 + dx, 21 + dy) & ret(2 + dx, 18 + dy, 4 + dx, 21 + dy), LATAO)
    else: q.parte(ret(5 + dx, 18 + dy, 7 + dx, 22 + dy), LATAO)
    # torre e canhão
    q.parte(elipse(19 + dx, 23 + dy, 7, 5) & (Y < 24 + dy), OLIVA)
    q.parte(ret(23 + dx, 19 + dy, 34 + dx, 22 + dy), pal('14180c', '262e16', '3c4a22', '4a5a2a', '5e7034', '7a8e4a'))
    q.parte(ret(32 + dx, 18 + dy, 35 + dx, 23 + dy), OLIVA)
    luz = (255, 60, 40, 255) if anim == 'ataque' else (255, 150, 40, 255)
    if anim == 'dano': luz = (255, 255, 255, 255)
    q.cor(ret(20 + dx, 19 + dy, 23 + dx, 20 + dy), luz)
    if fogo:
        for j in range(3): q.fumaca(37 + j * .5 + dx, 20 + dy, 2.6 - j * .6, [hexc('fff2b0'), hexc('ffc93a'), hexc('ff8a1c')])
    if anim == 'ataque' and k in (3, 4): q.fumaca(36 + dx, 17 + dy - k, 2 + k * .3, FUMO)
    if anim == 'dano':
        for j in range(3): q.faisca(14 + j * 6, 20 + (j * 5 + k) % 8, j + k)
    if anim == 'morte':
        q.fumaca(19, 16 - k * 2, 2 + k, FUMO)
        for j in range(3): q.faisca(10 + (j * 11 + k * 5) % 22, 18 + (j * 4 + k * 3) % 12, j)
    return q.pronto()

def mina(anim, k, n):
    """mina saltadora: esfera com chifres detonadores, luz vermelha piscando e três pezinhos"""
    q = Quadro(); sobe = 0; pisca = k % 3 == 0; arma = 0; tremor = 0
    if anim == 'andar': sobe = [0, -2, -4, -4, -2, 0][k]
    if anim == 'ataque': arma = 1; sobe = [1, 2, -5, -8, -6, -2][k]; pisca = k % 2 == 0
    if anim == 'dano': tremor = [-2, 2, -1][k]; pisca = True
    if anim == 'morte':
        r = [3, 6, 9, 11, 12, 12, 11, 10, 9, 8][k]
        if k < 7: q.fumaca(20, 26, r, [hexc('fff2b0'), hexc('ffc93a'), hexc('ff8a1c')] if k < 3 else [hexc('ffc93a', 230), hexc('e2481a', 230), hexc('8a1e0e', 220)])
        if k >= 3:
            for j in range(3): q.fumaca(14 + j * 6, 24 - (k - 3) * 2.5 - j * 2, 3 + (k - 3) * .6, FUMO)
        for j in range(8):
            a = j * .785 + .2; rr = 4 + k * 2.4
            q.cor(ret(20 + math.cos(a) * rr, 26 + math.sin(a) * rr * .8, 22 + math.cos(a) * rr, 27 + math.sin(a) * rr * .8), OLIVA[2])
        return q.pronto()
    cy = 26 + sobe; dx = tremor
    # pezinhos
    for x in (14, 20, 26):
        q.parte(segm(x + dx, cy + 6, x + dx + (x - 20) * .3, 37 + min(0, sobe) * .3, 1.8), FERRO)
    # chifres
    L = 4 + arma
    for a in (-2.6, -2.0, -1.57, -1.14, -.54):
        q.parte(segm(20 + dx + math.cos(a) * 6, cy + math.sin(a) * 6, 20 + dx + math.cos(a) * (6 + L), cy + math.sin(a) * (6 + L), 2.2), LATAO)
    # esfera
    q.parte(disco(20 + dx, cy, 8.2), OLIVA, ruido=.12, seed=k)
    q.cor(disco(20 + dx, cy, 8.2) & ret(0, cy + 1, QW, cy + 2), OLIVA[1])
    for j in range(5): q.px(14 + j * 3 + dx, cy + 1, OLIVA[4])
    luz = (255, 50, 40, 255) if pisca else (110, 20, 20, 255)
    if anim == 'dano': luz = (255, 255, 255, 255)
    q.cor(disco(20 + dx, cy - 8.5, 1.6), luz)
    if pisca: q.px(20 + dx, cy - 10, (255, 200, 190, 255))
    q.px(17 + dx, cy - 4, OLIVA[5]); q.px(16 + dx, cy - 3, OLIVA[5])
    if anim == 'ataque' and k <= 1:
        for j in range(3): q.faisca(13 + j * 7, 37, j)
    if anim == 'dano':
        for j in range(3): q.faisca(14 + j * 6, cy - 4 + (j * 5 + k) % 9, j + k)
    return q.pronto()

def zepelim(anim, k, n):
    """zepelim de vigia: balão prateado com lemes, gôndola e um holofote que procura você"""
    q = Quadro(); dy = 1 if k % 3 == 1 else 0; murcha = 0; luz_ver = 0; tremor = 0; cai = 0
    if anim == 'ataque': luz_ver = 1
    if anim == 'dano': tremor = [-2, 1, -1][k]
    if anim == 'morte': murcha = min(1, k / 7); cai = k * 1.5
    cy = 15 + dy + cai; dx = tremor
    rx, ry = 13 - murcha * 3, 7 - murcha * 3
    # lemes
    q.parte(poli([(8 + dx, cy - 2), (3 + dx, cy - 8), (6 + dx, cy)]), pal('3a0e0e', '6a1e1e', '8a2e2a', 'b04a3a', 'd06a50', 'e89a80'))
    q.parte(poli([(8 + dx, cy + 2), (3 + dx, cy + 7), (6 + dx, cy)]), pal('3a0e0e', '6a1e1e', '8a2e2a', 'b04a3a', 'd06a50', 'e89a80'))
    # balão
    bal = elipse(19 + dx, cy, rx, ry)
    if murcha: bal &= ~elipse(19 + dx + 3, cy + ry, rx * .6, ry * murcha * .9)
    q.parte(bal, PRATA, luz=(-.4, -.9), ruido=.08, seed=k)
    for xx in (12, 17, 22, 27): q.cor(bal & ret(xx + dx, 0, xx + 1 + dx, QH), PRATA[2])
    q.cor(bal & ret(0, cy - 1, QW, cy), PRATA[4])
    q.cor(disco(26 + dx, cy - 2, 2.2) & bal, (180, 50, 40, 255)); q.px(26 + dx, cy - 2, (240, 200, 120, 255))   # emblema (engrenagem vermelha)
    # hélice
    hx = 5 + dx
    if k % 2: q.parte(ret(hx - 1, cy - 4, hx + 1, cy + 4), FERRO)
    else: q.parte(ret(hx - 3, cy - 1, hx + 1, cy + 1), FERRO)
    # gôndola e holofote
    gy = cy + ry + 1
    q.cor(segm(16 + dx, cy + ry - 1, 16 + dx, gy + 1, 1), FERRO[1]); q.cor(segm(24 + dx, cy + ry - 1, 24 + dx, gy + 1, 1), FERRO[1])
    q.parte(ret(14 + dx, gy, 27 + dx, gy + 5), pal('120e0a', '2a2014', '3e3020', '54422c', '6a563a', '8a7452'))
    for xx in (17, 20, 23): q.px(xx + dx, gy + 2, (255, 210, 120, 255))
    holo = (255, 60, 50) if luz_ver else (255, 240, 170)
    if anim == 'dano': holo = (255, 255, 255)
    q.cor(ret(27 + dx, gy + 1, 29 + dx, gy + 4), holo + (255,))
    if anim != 'morte':      # facho de luz (meio transparente)
        for j in range(1, 9):
            for i in range(-j // 2, j // 2 + 1):
                x, y = 29 + dx + j, gy + 2 + j + i
                if 0 <= x < QW and 0 <= y < QH and not q.m[y, x]: q.solto.append(('px', x, y, holo + (70 if luz_ver else 45,)))
    if anim == 'morte':
        q.fumaca(14, cy - 6 - k, 2 + k * .5, FUMO)
        for j in range(2): q.faisca(20 + j * 6, cy + (k * 3 + j * 4) % 6, j + k)
    if anim == 'dano':
        for j in range(3): q.faisca(14 + j * 6, cy - 4 + (j * 4 + k * 3) % 8, j)
    return q.pronto()

# =====================================================================
ANIMS = {'parado': (6, 8), 'andar': (6, 10), 'ataque': (6, 12), 'dano': (3, 14), 'morte': (10, 14)}
MONSTROS = [
    # chave, pasta, função, nome, pé (linha), caixa (px na tela), voa, brilho, texto do Diário
    ('w_vapor', 'automato', automato, 'Autômato de Engrenagens', 38, [30, 40], False, None,
     'Feito de latão e pressão, anda sem parar pelas fábricas. A pinça aperta forte e a chaminé nunca apaga.'),
    ('h_vapor', 'caldeira', caldeira, 'Caldeira Saltadora', 38, [30, 38], False, None,
     'Uma caldeira com pernas de mola. Junta pressão, apita e salta em cima de quem chega perto.'),
    ('f_vapor', 'ornitoptero', ornitoptero, 'Ornitóptero de Latão', 31, [32, 28], True, 195,
     'Pássaro mecânico de placas de latão. Bate as asas a corda e mergulha com o bico de ferro.'),
    ('w_guerra', 'tanque', tanque, 'Tanque de Corda', 38, [36, 32], False, None,
     'Um tanquezinho de lata movido a corda. Pequeno, mas o canhão faz um estrago.'),
    ('h_guerra', 'mina', mina, 'Mina Saltadora', 38, [28, 30], False, None,
     'Fica quieta piscando até alguém chegar perto. Aí arma os chifres e pula.'),
    ('f_guerra', 'zepelim', zepelim, 'Zepelim de Vigia', 28, [38, 30], True, 40,
     'Balão de vigia com um holofote. Quando a luz fica vermelha, ele te achou.'),
]
TEMAS = {
    'vapor': {'eras': ['Revoluções Industriais', 'Primavera dos Povos', 'Neocolonialismo'], 'w': 'w_vapor', 'h': 'h_vapor', 'f': 'f_vapor'},
    'guerra': {'eras': ['Primeira Guerra Mundial', 'Revolução Russa', 'Crise de 1929', 'Totalitarismo', 'Segunda Guerra Mundial'], 'w': 'w_guerra', 'h': 'h_guerra', 'f': 'f_guerra'},
}

def main():
    manif = {}
    for chave, pasta, fn, nome, pe, caixa, voa, brilho, texto in MONSTROS:
        os.makedirs(os.path.join(PASTA, pasta), exist_ok=True)
        anim = {}
        for a, (n, fps) in ANIMS.items():
            tira = np.concatenate([fn(a, k, n) for k in range(n)], axis=1)
            Image.fromarray(tira, 'RGBA').save(os.path.join(PASTA, pasta, a + '.png'), optimize=True)
            anim[a] = [a + '.png', n, fps]
        q0 = fn('parado', 0, ANIMS['parado'][0]); ys, xs = np.nonzero(q0[..., 3] > 0)
        m = {'nome': nome, 'pasta': pasta + '/', 'quadro': [QW, QH], 'centro': 20, 'pe': pe, 'direita': True, 'escala': 2,
             'caixa': caixa, 'diario': [int(xs.min()), int(ys.min()), int(np.ptp(xs) + 1), int(np.ptp(ys) + 1)], 'texto': texto, 'anim': anim}
        if voa: m['flutua'] = True; m['brilho'] = brilho
        manif[chave] = m
    linhas = ',\n'.join('  %s: %s' % (k, json.dumps(v, ensure_ascii=False)) for k, v in manif.items())
    js = ('// =====================================================================\n'
          '//  MONSTROS DAS ÉPOCAS INDUSTRIAIS E DAS GUERRAS — gerado por ferramentas/gerar_monstros_era.py\n'
          '//  Mesmo formato de monstros.js. "temas" diz em quais épocas (pelo nome) cada tipo (w anda, h pula, f voa)\n'
          '//  troca de desenho; o jeito de lutar continua o mesmo do tipo.\n'
          '// =====================================================================\n'
          'registrarMonstrosExtra({\n' + linhas + ',\n  temas: ' + json.dumps(TEMAS, ensure_ascii=False) + '\n});\n')
    open(os.path.join(PASTA, 'monstros_era.js'), 'w').write(js)
    print('ok', ', '.join(manif))

if __name__ == '__main__':
    main()
