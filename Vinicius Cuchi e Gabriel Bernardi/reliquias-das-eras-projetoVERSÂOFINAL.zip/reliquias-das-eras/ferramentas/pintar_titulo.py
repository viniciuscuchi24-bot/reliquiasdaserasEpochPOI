# Pinta a cena da tela de título em pixel art (480 x 270, o jogo amplia 2x):
#   floresta escura, um portal de pedra antigo coberto de musgo (com o emblema da ampulheta das eras),
#   feixes de luz entrando pelas copas e uma clareira iluminada na frente da escada.
# Também monta o logotipo "RELÍQUIAS / DAS ERAS" (fonte Jersey 10, licença SIL OFL).
# Saídas: assets/titulo/cena.png, assets/titulo/logo.png e assets/titulo/titulo.js (posições usadas pelo jogo)
# Tudo é desenhado por código (sem fotos): cada material tem uma rampa de cores e a luz decide o tom;
# um pontilhado regular (Bayer) faz as transições, como em pixel art feita à mão.
# Uso: python3 ferramentas/pintar_titulo.py
import os, json, math
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy import ndimage

AQUI = os.path.dirname(os.path.abspath(__file__))
RAIZ = os.path.dirname(AQUI)
SAI = os.path.join(RAIZ, 'assets', 'titulo')
W, H = 480, 270
rng = np.random.default_rng(7)

def hx(h): h = h.lstrip('#'); return [int(h[i:i + 2], 16) for i in (0, 2, 4)]
def rampa(*c): return np.array([hx(x) for x in c], np.uint8)

FUNDO = rampa('#020403', '#040a07', '#07120c', '#0b1b12', '#10251a', '#163221', '#1d3f2a', '#264d33')
FOLHA = rampa('#030703', '#07110a', '#0c1d0f', '#122a15', '#1a3a1b', '#244c20', '#305f25', '#3f742a', '#558c30',
              '#70a536', '#93c043', '#bcd95c', '#e2f08e')
PEDRA = rampa('#050807', '#0b100e', '#121a16', '#1a241f', '#24302a', '#2f3d35', '#3b4a40', '#4a5a4c', '#5d6d5b',
              '#73836c', '#8d9c82', '#a9b69a')
TERRA = rampa('#060503', '#0e0b06', '#18140b', '#231d10', '#302816', '#40361e', '#544727')
CASCA = rampa('#020302', '#060806', '#0b0f0b', '#121812', '#1a221a', '#243024', '#30402e', '#40553a')
QUENTE = rampa('#1a0d05', '#3a1c08', '#6a330e', '#a85a1c', '#e09a3a', '#ffd36e', '#fff2bf')

B4 = np.array([[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]]) / 16.0
BAYER = np.tile(B4, (H // 4 + 1, W // 4 + 1))[:H, :W]
yy, xx = np.mgrid[0:H, 0:W].astype(float)
tela = np.zeros((H, W, 3), np.uint8)

def ruido(escala, semente, oit=3):
    r = np.random.default_rng(semente); tot = np.zeros((H, W)); amp = 1; soma = 0
    for o in range(oit):
        s = escala / (2 ** o); gh, gw = int(H / s) + 3, int(W / s) + 3
        gr = r.random((gh, gw))
        z = ndimage.zoom(gr, (H / (gh - 2) * 1.0, W / (gw - 2) * 1.0), order=3)[:H, :W]
        tot += z * amp; soma += amp; amp *= .5
    tot /= soma; return (tot - tot.min()) / (tot.max() - tot.min() + 1e-9)

def pinta(mascara, v, rp, pont=1.0):
    n = len(rp)
    i = np.clip(np.floor(v * (n - 1) + .5 + (BAYER - .5) * pont), 0, n - 1).astype(int)
    tela[mascara] = rp[i[mascara]]

def poli(pts):
    m = Image.new('L', (W, H), 0); ImageDraw.Draw(m).polygon([tuple(p) for p in pts], fill=255); return np.asarray(m) > 0
def elipse(cx, cy, rx, ry):
    return ((xx - cx) / max(rx, .1)) ** 2 + ((yy - cy) / max(ry, .1)) ** 2 <= 1
def retang(x0, y0, x1, y1): return (xx >= x0) & (xx < x1) & (yy >= y0) & (yy < y1)

# ---------------- luz da cena ----------------
# brilho atrás do portal (névoa iluminada), feixes que descem da esquerda para a direita e a clareira
PORTA = (350, 184)            # centro de baixo da porta
def feixe(x0, larg, ang, forca):
    # faixa inclinada: distância perpendicular ao eixo que passa por (x0, 0) com inclinação ang
    dx, dy = math.sin(ang), math.cos(ang)
    dist = np.abs((xx - x0) * dy - yy * dx)
    return np.clip(1 - dist / larg, 0, 1) ** 1.5 * forca * np.clip(yy / 60 + .3, 0, 1)
FEIXES = [(215, 16, -.42, .55), (262, 9, -.42, .4), (300, 22, -.45, .5), (178, 6, -.40, .3)]
luz_feixes = sum(feixe(*f) for f in FEIXES)
nevoa = np.exp(-(((xx - 345) / 150) ** 2 + ((yy - 110) / 95) ** 2))
clareira = np.exp(-(((xx - 318) / 95) ** 2 + ((yy - 236) / 26) ** 2))
sol_topo = np.exp(-(((xx - 342) / 75) ** 2 + ((yy - 42) / 20) ** 2))      # sol batendo no alto do portal
LUZ = .12 + .35 * nevoa + luz_feixes + .75 * clareira + .55 * sol_topo

# ---------------- fundo: névoa e troncos distantes ----------------
v = .1 + .5 * nevoa + .2 * luz_feixes + (ruido(40, 1) - .5) * .12 - np.clip((yy - 150) / 200, 0, .2)
pinta(np.ones((H, W), bool), np.clip(v, 0, 1), FUNDO)
r = np.random.default_rng(3)
for k in range(26):                                   # troncos lá no fundo (claros pela névoa)
    x = r.uniform(0, W); w = r.uniform(2, 7); prof = r.uniform(.2, .8)
    m = retang(x, 0, x + w, 200) & (ruido(8, 100 + k, 1) > .05)
    vv = .1 + .45 * nevoa * (1 - prof) + .15 * (1 - prof) + (xx - x) / w * .06
    pinta(m, np.clip(vv, 0, 1), FUNDO)
# copas lá em cima (bem escuras)
copa = (ruido(22, 5) * 60 + 18 > yy) | (yy < 8)
pinta(copa, np.clip(.06 + ruido(5, 6) * .18 + luz_feixes * .2, 0, 1), FOLHA)

# ---------------- folhagem (folhas pequenas soltas) ----------------
def folhagem(area, n, tam, base, var, semente, luzk=1.0, cor=FOLHA, dentro=True):
    r = np.random.default_rng(semente)
    ys, xs = np.where(area)
    if len(xs) == 0: return
    idx = r.integers(0, len(xs), n)
    folhas = []
    for i in idx:
        cx, cy = xs[i] + r.uniform(-.5, .5), ys[i] + r.uniform(-.5, .5)
        a = r.uniform(0, math.pi); L = r.uniform(*tam); Wd = L * r.uniform(.35, .6)
        val = base + r.uniform(-var, var) + LUZ[int(cy) % H, int(cx) % W] * luzk * .5 + (1 - cy / H) * .05
        folhas.append((val, cx, cy, a, L, Wd))
    folhas.sort()
    img = Image.new('L', (W, H), 0); d = ImageDraw.Draw(img)
    vals = np.zeros((H, W)); msk = np.zeros((H, W), bool)
    for (val, cx, cy, a, L, Wd) in folhas:
        pts = [(cx + math.cos(a) * L, cy + math.sin(a) * L), (cx + math.cos(a + 1.57) * Wd, cy + math.sin(a + 1.57) * Wd),
               (cx - math.cos(a) * L, cy - math.sin(a) * L), (cx - math.cos(a + 1.57) * Wd, cy - math.sin(a + 1.57) * Wd)]
        m = Image.new('L', (W, H), 0); ImageDraw.Draw(m).polygon(pts, fill=255); mm = np.asarray(m) > 0
        if dentro: mm &= ndimage.binary_dilation(area, iterations=3)
        # borda de baixo da folha um pouco mais escura
        sombra = mm & ~np.roll(mm, -1, 0)
        vals[mm] = val; vals[sombra] = val - .12; msk |= mm
    pinta(msk, np.clip(vals, 0, 1), cor)
    return msk

# folhagem do fundo (meia distância), dos dois lados do portal
meio = (ruido(26, 9) * 70 + 120 > yy) & (yy > 40) & ((xx < 250) | (xx > 440))
folhagem(meio, 1400, (2, 5), .1, .07, 11, luzk=.45)

# ---------------- portal de pedra ----------------
CHAO = 200
camadas = [(262, 96, 438, 186), (286, 54, 414, 96), (314, 36, 386, 54)]
corpo = np.zeros((H, W), bool)
for (x0, y0, x1, y1) in camadas: corpo |= retang(x0, y0, x1, y1)
# ruína: falta um pedaço no canto de cima à direita e na camada de baixo à esquerda
corpo &= ~poli([(392, 36), (414, 36), (414, 70), (404, 64), (398, 50)])
corpo &= ~poli([(262, 96), (276, 96), (270, 108), (262, 112)])
porta_arco = (elipse(350, 132, 22, 24) & (yy <= 132)) | retang(328, 132, 372, 187)
moldura = ((elipse(350, 132, 29, 31) & (yy <= 132)) | retang(321, 132, 379, 187)) & ~porta_arco
disco = elipse(350, 75, 19, 19)
pilar_e, pilar_d = retang(292, 100, 312, 186), retang(388, 100, 408, 186)
# blocos de pedra: cada fileira com um deslocamento; tom de cada bloco varia um pouco
blocos = np.zeros((H, W)); junta = np.zeros((H, W), bool)
r = np.random.default_rng(21)
y = 30
while y < 190:
    hgt = int(r.integers(9, 13)); x = 250 - int(r.integers(0, 18))
    while x < 450:
        wd = int(r.integers(14, 26))
        blocos[y:y + hgt, max(x, 0):x + wd] = r.uniform(-.06, .06)
        junta[y + hgt - 1, max(x, 0):x + wd] = True; junta[y:y + hgt, min(max(x, 0), W - 1)] = True
        x += wd
    y += hgt
ilum_pedra = .22 + .6 * np.clip(LUZ - .1, 0, 1.2) - np.clip((xx - 320) / 260, -.12, .3) - np.clip((yy - 110) / 200, 0, .3)
vp = ilum_pedra + blocos + (ruido(6, 31, 2) - .5) * .1
vp[junta] -= .16
# realce em cima/esquerda e sombra embaixo/direita de cada bloco (relevo)
topo_bloco = np.roll(junta, 1, 0) & ~junta
vp[topo_bloco] += .07
pinta(corpo, np.clip(vp, 0, 1), PEDRA)
# bordas de cada camada: aresta clara em cima, sombra embaixo
for (x0, y0, x1, y1) in camadas:
    pinta(retang(x0, y0, x1, y0 + 1) & corpo, np.clip(ilum_pedra + .18, 0, 1), PEDRA)
    pinta(retang(x0, y1 - 2, x1, y1) & corpo, np.clip(ilum_pedra - .2, 0, 1), PEDRA)
# pilares com glifos
for pil, cx in ((pilar_e, 302), (pilar_d, 398)):
    vv = ilum_pedra + .04 + (ruido(4, 41, 2) - .5) * .08
    pinta(pil, np.clip(vv, 0, 1), PEDRA)
    pinta(pil & ((xx == cx - 10) | (yy == 100)), np.clip(vv + .14, 0, 1), PEDRA)
    pinta(pil & (xx == cx + 9), np.clip(vv - .2, 0, 1), PEDRA)
    for k, gy in enumerate(range(108, 180, 13)):
        g = (k * 5 + cx) % 4
        glifo = [poli([(cx, gy), (cx + 4, gy + 4), (cx, gy + 8), (cx - 4, gy + 4)]) & ~poli([(cx, gy + 2), (cx + 2, gy + 4), (cx, gy + 6), (cx - 2, gy + 4)]),
                 retang(cx - 4, gy + 1, cx + 4, gy + 2) | retang(cx - 4, gy + 4, cx + 4, gy + 5) | retang(cx - 4, gy + 7, cx + 4, gy + 8),
                 (retang(cx - 4, gy, cx + 4, gy + 8) & ~retang(cx - 3, gy + 1, cx + 3, gy + 7)) | retang(cx - 1, gy + 3, cx + 1, gy + 5),
                 poli([(cx - 4, gy + 8), (cx + 4, gy + 8), (cx, gy)])][g]
        pinta(glifo & pil, np.clip(vv - .22, 0, 1), PEDRA)
        pinta(np.roll(glifo, 1, 0) & ~glifo & pil, np.clip(vv + .1, 0, 1), PEDRA)
# moldura da porta: aduelas grandes em volta do arco
ang = np.arctan2(yy - 132, xx - 350)
aduela = ((np.floor((ang + math.pi) / (math.pi / 9)) % 2) == 0)
vm = ilum_pedra + .08 + np.where(aduela, .04, -.02) + (ruido(5, 51, 2) - .5) * .08
raio = np.hypot(xx - 350, yy - 132)
vm[(np.abs(np.diff(np.floor((ang + math.pi) / (math.pi / 9)), axis=1, prepend=0)) > 0) & (yy < 132)] -= .2
vm[(raio > 28.2) & (yy <= 132)] -= .12
pinta(moldura, np.clip(vm, 0, 1), PEDRA)
# porta: escuridão com um brilho fraco lá no fundo
vporta = np.clip(.0 + .09 * np.exp(-(((xx - 350) / 12) ** 2 + ((yy - 176) / 16) ** 2)), 0, 1)
pinta(porta_arco, vporta, FUNDO)
pinta(porta_arco & (np.roll(~porta_arco, -1, 1) | np.roll(~porta_arco, 1, 1)) & (yy > 110), np.full((H, W), .02), FUNDO)
# disco das eras: anel com 12 marcas e a ampulheta no meio
vd = ilum_pedra + .06 + (ruido(4, 61, 2) - .5) * .06
pinta(disco, np.clip(vd, 0, 1), PEDRA)
rd = np.hypot(xx - 350, yy - 75); ad = np.arctan2(yy - 75, xx - 350)
sulco = disco & (((rd > 15) & (rd < 16.5)) | ((rd > 9.5) & (rd < 10.8)))
pinta(sulco, np.clip(vd - .25, 0, 1), PEDRA)
pinta(disco & (rd >= 16.5) & (rd < 17.6) & (ad < -.6) & (ad > -2.6), np.clip(vd + .12, 0, 1), PEDRA)
for k in range(12):
    a = k * math.pi / 6
    mx, my = 350 + math.cos(a) * 13, 75 + math.sin(a) * 13
    pinta(elipse(mx, my, 1.2, 1.2), np.clip(vd - .3, 0, 1), PEDRA)
amp = poli([(345, 68), (355, 68), (350, 75)]) | poli([(345, 82), (355, 82), (350, 75)])
pinta(amp, np.clip(vd - .3, 0, 1), PEDRA)
pinta(retang(344, 67, 356, 68) | retang(344, 82, 356, 83), np.clip(vd + .1, 0, 1), PEDRA)
pinta(retang(349, 77, 351, 82), np.full((H, W), .55), QUENTE)          # areia brilhando na ampulheta
pinta(elipse(350, 75, 19.6, 19.6) & ~disco & corpo, np.clip(vd - .28, 0, 1), PEDRA)
# rachaduras
r = np.random.default_rng(71)
for k in range(9):
    x, y = r.uniform(268, 432), r.uniform(40, 175); ang2 = r.uniform(1.0, 2.2)
    for s in range(int(r.integers(6, 16))):
        ang2 += r.uniform(-.5, .5); x += math.cos(ang2); y += math.sin(ang2)
        xi, yi = int(x), int(y)
        if 0 <= xi < W and 0 <= yi < H and corpo[yi, xi] and not porta_arco[yi, xi]: tela[yi, xi] = PEDRA[1]
# escada
for k in range(4):
    x0, x1, y1 = 300 + 7 * k, 400 - 7 * k, 206 - 5 * k
    deg = retang(x0, y1 - 5, x1, y1)
    vv = .3 + .55 * np.clip(LUZ - .1, 0, 1.2) - .05 * k + (ruido(4, 80 + k, 2) - .5) * .1
    pinta(deg, np.clip(vv, 0, 1), PEDRA)
    pinta(retang(x0, y1 - 5, x1, y1 - 4), np.clip(vv + .16, 0, 1), PEDRA)
    pinta(retang(x0, y1 - 1, x1, y1), np.clip(vv - .22, 0, 1), PEDRA)

# ---------------- musgo, raízes e cipós no portal ----------------
musgo = np.zeros((H, W), bool)
rm = ruido(5, 91, 2)
for (x0, y0, x1, y1) in camadas:
    espessura = 3 + rm * 7 + np.clip(LUZ - .4, 0, 1) * 4
    cai = (yy >= y0 - 3) & (yy < y0 + espessura) & (xx >= x0 - 2) & (xx < x1 + 2)
    gotas = (yy >= y0) & (yy < y0 + espessura + (ruido(3, 92 + y0, 1) > .62) * 14 * ruido(2, 93 + y0, 1)) & (xx >= x0) & (xx < x1)
    musgo |= (cai | gotas) & (corpo | (yy < y0)) & (rm > .18)
musgo |= corpo & (ruido(9, 95, 3) > .78) & (rm > .45)                    # manchas no meio da pedra
musgo |= (moldura & (yy < 112) & (ruido(4, 96, 2) > .45))
musgo &= ~porta_arco & ~elipse(350, 75, 21, 21)
# sombra embaixo das saliências de musgo
pinta(corpo & ~musgo & np.roll(musgo, 2, 0) & ~porta_arco, np.clip(ilum_pedra - .22, 0, 1), PEDRA)
folhagem(musgo, 2400, (1.5, 3.2), .14, .1, 97, luzk=1.0)
# cipós pendurados das bordas
r = np.random.default_rng(101)
for k in range(17):
    cam = camadas[k % 3]; x = r.uniform(cam[0] + 4, cam[2] - 4); y = cam[1] + 2; comp = r.uniform(10, 70)
    if 326 < x < 374 and cam[1] > 90: comp = min(comp, 20)
    pts = []
    for s in range(int(comp)):
        x += math.sin(s * .25 + k) * .35; y += 1; pts.append((int(x), int(y)))
    for i, (px, py) in enumerate(pts):
        if 0 <= px < W and 0 <= py < H:
            vv = .2 + LUZ[py, px] * .45
            tela[py, px] = FOLHA[int(np.clip(vv * 12, 0, 12))]
            if i % 4 == 0:
                lado = 1 if (i // 4) % 2 else -1
                for q in range(1, 3):
                    qx = px + lado * q
                    if 0 <= qx < W: tela[py - (q > 1), qx] = FOLHA[int(np.clip((vv + .12) * 12, 0, 12))]
# blocos caídos na frente
for (cx, cy, rx, ry) in ((268, 196, 12, 7), (430, 194, 10, 8), (254, 205, 6, 4)):
    b = elipse(cx, cy, rx, ry) & (yy < cy + ry * .6)
    vv = .28 + .5 * np.clip(LUZ - .1, 0, 1) - (yy - (cy - ry)) / (2 * ry) * .25 + (ruido(3, int(cx), 2) - .5) * .1
    pinta(b, np.clip(vv, 0, 1), PEDRA)
    folhagem(b & (yy < cy - ry * .2), 90, (1.5, 3), .32, .1, int(cx) + 5, luzk=1.2)

# ---------------- chão ----------------
chao = yy >= CHAO - 2 + (ruido(6, 110, 1) - .5) * 4
chao &= ~retang(300, 186, 400, 207)
vc = .12 + .55 * clareira + .25 * luz_feixes + (ruido(3, 111, 2) - .5) * .12
pinta(chao, np.clip(vc, 0, 1), FOLHA)
# caminho de terra e pedras até a escada
caminho = poli([(326, 206), (374, 206), (392, 270), (296, 270)]) & chao
vt = .25 + .45 * clareira + (ruido(4, 120, 2) - .5) * .2
pinta(caminho, np.clip(vt, 0, 1), TERRA)
r = np.random.default_rng(121)
for k in range(9):
    t = (k + r.uniform(0, .6)) / 9; cx = 347 + (r.uniform(-1, 1) * (12 + 16 * t)); cy = 209 + t * 58
    lajota = elipse(cx, cy, 5 + 6 * t, 1.6 + 2 * t) & caminho
    pinta(lajota, np.clip(.16 + .36 * clareira + (yy - cy) * -.05 + (ruido(2, 122, 1) - .5) * .1, 0, 1), PEDRA)
# capim: talos finos, mais claros na clareira
r = np.random.default_rng(131)
for k in range(2600):
    x = r.uniform(0, W); y = r.uniform(CHAO - 2, H)
    if caminho[int(y), int(x)] and r.random() < .8: continue
    alt = int(1 + r.uniform(1, 4) * (.6 + (y - CHAO) / 70))
    vv = .12 + .6 * clareira[int(y), int(x)] + .2 * luz_feixes[int(y), int(x)] + r.uniform(-.06, .1)
    for s in range(alt):
        py = int(y) - s; px = int(x + (s * .3 if k % 2 else -s * .3))
        if 0 <= px < W and 0 <= py < H: tela[py, px] = FOLHA[int(np.clip((vv + s * .03) * 12 + BAYER[py, px] - .5, 0, 12))]

# ---------------- árvores grandes da frente (moldura) ----------------
def tronco(x0, x1, semente, borda_luz=1):
    larg = x1 - x0
    meio = (x0 + x1) / 2
    perfil = larg / 2 * (1 + np.clip((yy - 150) / 60, 0, 1.2) ** 2 * .9) + (ruido(10, semente, 2) - .5) * 3
    m = (np.abs(xx - meio) < perfil) & (yy < CHAO + 14)
    # raízes
    r = np.random.default_rng(semente)
    for k in range(5):
        lado = -1 if k % 2 else 1; rx = meio + lado * larg * .3; ry = 170
        for s in range(40):
            rx += lado * r.uniform(.6, 1.4); ry += r.uniform(.3, .9)
            m |= elipse(rx, ry, 2.5 - s * .05, 2)
    m &= yy < H
    rel = (xx - meio) / (larg / 2 + 1e-6) * borda_luz
    vv = .18 + np.clip(rel, -1, 1) * .12 + (ruido(2, semente + 1, 2) - .5) * .25 * (1 - ((xx * 7 + semente) % 5 == 0))
    vv += np.clip(rel - .55, 0, 1) * .7 * (nevoa + .2)
    vv -= ((xx.astype(int) * 3 + (yy // 7).astype(int)) % 9 == 0) * .1
    pinta(m, np.clip(vv, 0, 1), CASCA)
    return m
tronco(18, 62, 141, 1)
tronco(150, 166, 142, 1)
tronco(456, 492, 143, -1)
# musgo nos troncos e folhagem pendurada em cima
folhagem(retang(0, 0, W, 34) & (ruido(14, 150) * 40 + 10 > yy), 2200, (2, 6), .08, .07, 151, luzk=.4)
folhagem(retang(150, 20, 250, 60) & (ruido(10, 152) > .55), 260, (2, 4), .12, .06, 153, luzk=.6)
# arbustos da frente (cantos de baixo), escuros com algumas folhas pegando luz
canto_e = (elipse(40, 270, 150, 58) | elipse(150, 280, 60, 40)) & (ruido(8, 160, 2) * 18 + yy > 225)
canto_d = (elipse(470, 262, 90, 70) | elipse(400, 285, 40, 30))
for area, s in ((canto_e, 161), (canto_d, 162)):
    folhagem(area, 3000, (3, 8), .07, .06, s, luzk=.55)
# samambaias dos lados do portal
for (cx, cy, s) in ((256, 200, 170), (446, 200, 171), (236, 214, 172), (408, 218, 173)):
    r = np.random.default_rng(s)
    for k in range(7):
        a = -math.pi / 2 + r.uniform(-1.2, 1.2); L = r.uniform(10, 20)
        for t in np.linspace(0, 1, int(L)):
            px = cx + math.cos(a) * L * t + t * t * 6 * math.copysign(1, math.cos(a)); py = cy + math.sin(a) * L * t + t * t * 8
            for lado in (-1, 1):
                for q in range(int(4 * (1 - t)) + 1):
                    qx, qy = int(px + lado * q * .8 * -math.sin(a)), int(py + lado * q * .8 * math.cos(a) + q * .4)
                    if 0 <= qx < W and 0 <= qy < H:
                        vv = .15 + LUZ[qy, qx] * .45 + (1 - t) * .05
                        tela[qy, qx] = FOLHA[int(np.clip(vv * 12 + BAYER[qy, qx] - .5, 0, 12))]

# ---------------- feixes de luz por cima (clareia em pontilhado) ----------------
lf = np.clip(luz_feixes * .3, 0, .28)[..., None]
tf = tela.astype(float)
claro = np.array([200, 230, 140], float)
tf = tf * (1 - lf) + claro * lf
tela[:] = np.clip(tf, 0, 255).astype(np.uint8)
# vaga-lumes parados (os que piscam são desenhados pelo jogo)
r = np.random.default_rng(181)
for k in range(30):
    x, y = int(r.uniform(0, W)), int(r.uniform(30, 250))
    tela[y, x] = hx('#c8f070') if k % 3 else hx('#f4ffb0')

# ---------------- salva ----------------
os.makedirs(SAI, exist_ok=True)
Image.fromarray(tela).save(os.path.join(SAI, 'cena.png'))

# ---------------- logotipo ----------------
def logo():
    F = ImageFont.truetype(os.path.join(AQUI, 'fontes', 'jersey-10-latin-400-normal.ttf'), 20)
    linhas = ['RELÍQUIAS', 'DAS ERAS']
    alt = 24; lw = max(round(F.getlength(l)) for l in linhas) + 8
    m = Image.new('L', (lw, alt * len(linhas) + 4), 0); d = ImageDraw.Draw(m); d.fontmode = '1'
    for i, l in enumerate(linhas): d.text((3, 3 + i * alt + 17), l, font=F, fill=255, anchor='ls')
    a = np.asarray(m) > 0
    h, w = a.shape
    out = np.zeros((h + 2, w + 2, 4), np.uint8)
    A = np.zeros((h + 2, w + 2), bool); A[1:-1, 1:-1] = a
    contorno = ndimage.binary_dilation(A, structure=np.ones((3, 3))) & ~A
    sombra = np.roll(np.roll(ndimage.binary_dilation(A, structure=np.ones((3, 3))), 1, 0), 1, 1) & ~A & ~contorno
    out[sombra] = [3, 6, 4, 200]; out[contorno] = [8, 14, 10, 255]
    # letra: branca em cima e cinza-esverdeada na parte de baixo de cada linha (como pedra polida)
    Y = np.arange(h + 2)[:, None] % alt
    face = np.where(Y > 13, 1, 0)
    cores = np.array([[244, 241, 230, 255], [196, 203, 186, 255]], np.uint8)
    out[A] = cores[np.broadcast_to(face, A.shape)[A]]
    # acento do Í vira uma pedrinha dourada (a relíquia)
    ys, xs = np.where(A[:9])
    for y, x in zip(ys, xs):
        if y < 6: out[y, x] = [255, 205, 96, 255]
    Image.fromarray(out, 'RGBA').save(os.path.join(SAI, 'logo.png'))
    return out.shape[1], out.shape[0]
lw, lh = logo()

with open(os.path.join(SAI, 'titulo.js'), 'w', encoding='utf-8') as f:
    f.write('// Gerado por ferramentas/pintar_titulo.py — tela de título\n')
    f.write('// cena.png é desenhada 2x; heroi = onde ficam os pés do Hallokin (px da cena); porta = centro de baixo da porta;\n')
    f.write('// feixes = [x no topo, largura, inclinação, força] dos feixes de luz (o jogo faz eles pulsarem)\n')
    f.write('registrarInterface({ titulo: ' + json.dumps({
        'pasta': 'assets/titulo/', 'cena': 'cena.png', 'escala': 2, 'logo': 'logo.png', 'logoEscala': 5, 'logoPos': [20, 18],
        'heroi': [318, 236], 'porta': [350, 184], 'disco': [350, 75], 'feixes': FEIXES}) + ' });\n')
print('cena ok, logo', lw, lh)
