# Eras Perdidas

Jogo de plataforma 2D (estilo metroidvania) pelas 28 épocas da história, do Paleolítico à Segunda Guerra.
O visual vem todo da pasta `assets/`, como num jogo normal: trocou a imagem, mudou o jogo.

## Como jogar

- Dê dois cliques em `index.html`. Abre no navegador, não precisa instalar nada.
- Se o navegador bloquear alguma coisa, rode um servidor local dentro da pasta e abra `http://localhost:8000`:
  `python3 -m http.server 8000`
- Controles: A/D andar · Espaço pular · clique esquerdo ou X golpe · clique direito ou Z esquiva ·
  F curar · E interagir · M mapa · N música · **V troca o estilo visual** · R recomeça.
- **No celular**: os controles de toque aparecem sozinhos (joystick à esquerda: andar, para cima = golpe para
  cima, para baixo = golpe para baixo no ar; botões Golpe, Pular, Esquiva, Curar e E à direita; Estilo, música e
  Mapa em cima). Melhor com o celular deitado. Para jogar sem servidor, use `eras-perdidas-celular.html`
  (o jogo inteiro num arquivo só, feito por `python3 ferramentas/montar_arquivo_unico.py`): copie para o
  celular e abra no navegador.

## Pastas

```
index.html              página do jogo: layout, controles de toque e tamanho da tela; carrega os arquivos abaixo
js/
  config.js             estilo inicial e caminhos dos sons
  dados.js              as 28 épocas (nomes, textos das runas)
  nucleo.js             física, inimigos, combate
  fases.js              monta cada fase: área inicial + trechos com portões (tabela PLANO), peças móveis
  trechos.js            os 9 tipos de trecho, com variantes de desenho (A, B, C), e suas regras
  chefes.js             os 4 chefes (como lutam) e um desenho simples de reserva
  chefes_arte.js        desenha os chefes, ataques e ajudantes com as imagens de assets/chefes
  arenas.js             o cenário próprio de cada luta contra chefe (Coliseu, navio, fábrica, casamata)
  interface.js          caixas de texto em pergaminho e barra de vida dos chefes (imagens de assets/interface)
  recursos.js           carregador de imagens
  cenario.js            desenha terreno, plataformas, objetos, fundo e camadas a partir do estilo
  efeitos.js            efeitos animados: rio, água/lava/lama nos fossos, partículas no ar
  personagem.js         desenha o personagem (parado, andar, pulo, queda, golpes, dano, morte), o rastro dos golpes
                        e as asas do pulo duplo
  monstros.js           desenha os inimigos a partir das folhas de sprite (parado, andando, ataque, dano, morte)
  desenho.js            monta cada quadro (fundo, mundo, inimigos, jogador, interface)
  toque.js              controles de celular, música e sons
assets/
  audio/                musica.mp3, pulo.mp3, esquiva.mp3
  hallokin/             o personagem em uso (Hallokin): hallokin.png (corpo, uma linha por animação), golpes.png
                        (rastro laranja dos golpes), impactos.png, asas.png e hallokin.js (medidas)
  personagem/           o personagem antigo (o cronista, uma roupa por época) — não é carregado; veja abaixo como voltar
  monstros/             monstros.js (manifesto) + cogumelo/, golem_laranja/, voador/ (uma imagem por animação)
  objetos/              objetos.png + objetos.js: runas, fragmentos, alavancas, braseiros, portões, espinhos
  chefes/               chefes.js (manifesto) + legionario/, espectro/, colosso/, enigma/ (animações, ataques, retrato)
  interface/            interface.js + caixa.png (pergaminho das caixas de texto) e a moldura/barra de vida dos chefes
  estilos/
    pantano/            estilo "Pântano encantado"
      estilo.js         recortes e regras deste estilo (o "mapa" das imagens)
      imagens/          arte do pacote (terreno, objetos, camadas)
      fundos/           e0.webp … e27.webp: fundo de cada época (foto real + céu do estilo)
    cemiterio/          estilo "Cemitério gótico" (mesma organização)
ferramentas/
  montar_cenarios.py    gera os fundos das épocas a partir das fotos
  fotos/                01.jpg … 28.jpg (fotos reais) e creditos.json
  montar_arquivo_unico.py  gera ../eras-perdidas-celular.html: o jogo inteiro num arquivo só (para abrir no celular)
  hallokin_folha.png    folha original do Hallokin (SHADOW Series - Hallokin, free)
  recortar_hallokin.py  recorta a folha e gera assets/hallokin, inclusive o golpe para baixo (pogo)
  personagem_folha.webp  folha de arte do personagem antigo (uma linha por época)
  recortar_personagem.py  recorta a folha e gera assets/personagem (python3 ferramentas/recortar_personagem.py)
  gerar_asas.py         desenha as asas do pulo duplo (assets/personagem/asas.png)
  gerar_bainha.py       desenha a espada embainhada na cintura, uma por arma (assets/personagem/bainha.png)
  gerar_cortes.py       desenha o golpe: rastro do corte em meia-lua e a espada na mão, um por arma (cortes.png, laminas.png)
  gerar_objetos.py      desenha objetos.png (runas, fragmentos, portões...) em pixel art
  chefes_folha.webp      folha de arte dos chefes
  recortar_chefes.py    recorta a folha e gera assets/chefes (python3 ferramentas/recortar_chefes.py)
creditos.html           créditos das artes e das fotos
```

## Como mudar o visual

1. **Trocar uma arte**: substitua o arquivo em `assets/estilos/<estilo>/imagens/` por outro com o
   mesmo nome. Se o desenho mudar de lugar dentro da imagem, ajuste o recorte em `estilo.js`.
2. **Recortes**: em `estilo.js` cada peça é `[x, y, largura, altura]` dentro da imagem.
   - `chao.topo`: faixa de cima do chão (repete na horizontal)
   - `chao.ladoEsq / ladoDir`: paredes na beira dos fossos e nas torres (repetem na vertical)
   - `chao.pontaEsq / pontaDir`: quinas (opcional, ex.: lajes de pedra do cemitério)
   - `bloco`: peças próprias para torres e blocos (se faltar, usa as do chão)
   - `espinhos`: qual desenho de espinhos vai no fundo dos fossos
   - `teto.borda` e `teto.tijolo`: borda de baixo do teto e parede repetida
   - `plataforma.esquerda / meio / direita`: as três partes da plataforma fina
   - `objetos`: decoração do chão; `peso` é a chance de aparecer, `escala` o tamanho
   - `camadas`: camadas na frente do fundo, com `parallax` (0 = parada, 1 = anda junto com o chão)
3. **Fundo de uma época**: edite `assets/estilos/<estilo>/fundos/eN.webp` direto (1536x540),
   ou troque a foto em `ferramentas/fotos/` e rode `python3 ferramentas/montar_cenarios.py`
   (precisa de `pip install pillow numpy scipy`).
4. **Personagem (Hallokin)**: `assets/hallokin/hallokin.png` tem uma linha por animação (parado, andar,
   pulo, queda, ataque, ataque no ar, ataque para cima, dano, morte, ataque para baixo) e um quadro por coluna
   (96x96); `golpes.png` tem só o rastro laranja dos golpes, na mesma grade. Nas armas de alcance maior o corte
   se solta e voa até onde a arma acerta. Para refazer tudo a partir da folha original:
   `python3 ferramentas/recortar_hallokin.py` (ele também monta o golpe para baixo, que não existe na folha:
   corpo da queda + rastro do golpe para cima virado para baixo). É o mesmo personagem em todas as épocas.
   **Voltar ao personagem antigo** (o cronista, com uma roupa por época): no `index.html` troque
   `assets/hallokin/hallokin.js` por `assets/personagem/personagem.js`. Os arquivos dele continuam em
   `assets/personagem/` (folhas `eraNN.png`, golpe `cortes.png`/`laminas.png`, bainha; ferramentas
   `recortar_personagem.py`, `gerar_cortes.py`, `gerar_bainha.py`). As asas do pulo duplo são de
   `ferramentas/gerar_asas.py`.
5. **Monstros**: troque os PNG em `assets/monstros/<monstro>/` (uma tira de quadros por animação) e
   ajuste `quadro`, `centro`, `pe`, `escala` e o número de quadros em `assets/monstros/monstros.js`.
6. **Runas, fragmentos, portões**: edite `assets/objetos/objetos.png` num editor de imagem, ou mude os
   desenhos em `ferramentas/gerar_objetos.py` e rode `python3 ferramentas/gerar_objetos.py`.
7. **Caixas de texto e barra de vida dos chefes**: troque `assets/interface/caixa.png`, `vida_moldura.png` e
   `vida_barra.png`; em `assets/interface/interface.js` ficam as margens que não esticam, o vão da barra e as cores do texto.
8. **Estilo inicial**: `estiloInicial` em `js/config.js`.
9. **Criar um estilo novo**: copie a pasta `assets/estilos/pantano` com outro nome, troque o `id`
   e o `nome` dentro do `estilo.js`, ponha suas imagens e acrescente no `index.html`:
   `<script src="assets/estilos/SEU_ESTILO/estilo.js"></script>`. A tecla V passa a incluir ele.

## Como as fases funcionam

Cada época é uma fase longa: área inicial (runa, marco de descanso, item) e depois **trechos**
em sequência, cada um fechado por um portão que só abre quando você vence o desafio:

| Trecho | O que fazer |
|---|---|
| saltos | atravessar vãos (um deles exige a esquiva no ar) e ativar a alavanca |
| espinhos | cruzar um fosso quicando nas estacas (↓ + golpe no ar) |
| escalada | subir numa torre: pulo duplo (Asas) antes de Constantinopla, Garras depois |
| alavancas | acertar 3 alavancas com a espada (uma no alto, outra numa ilha) |
| guardioes | derrotar todos os inimigos do trecho |
| fragmentos | pegar 3 fragmentos nas plataformas e levar ao mecanismo |
| arena | as portas fecham e chegam 3 ondas de inimigos |
| escuro | acender 3 braseiros no escuro (a Lanterna aumenta a visão) |
| corrida | a alavanca abre o portão por poucos segundos |

Cada tipo tem variantes de desenho, e cada época usa uma combinação própria:

| Variante | saltos | espinhos | escalada | alavancas | guardiões | fragmentos | arena | escuro | corrida |
|---|---|---|---|---|---|---|---|---|---|
| A | ilhas e vão longo | estacas em linha | torre | ilha e pendurada | dois lados | escada | plana | dois fossos | três fossos |
| B | pilares no fosso | zigue-zague | degraus / coluna do teto | patamar + fosso | patamar central | pilares | bloco central | no alto + plataforma móvel | obstáculos e teto baixo |
| C | plataformas móveis | estacas que sobem e descem | — | — | fosso com plataforma móvel | — | dois fossos | — | — |

A tabela `PLANO` em `js/fases.js` diz os trechos de cada época, por exemplo `'saltos:C'` — dá para trocar à vontade.
As habilidades (Esquiva Veloz, Asas, Garras, Lanterna) são pegas só de encostar, com explicação na
tela, e o trecho seguinte já pede a habilidade nova.

Chefes (`js/chefes.js`), cada um com sua arena própria (`js/arenas.js`):

| Fase | Chefe | Arena | Como luta |
|---|---|---|---|
| 7 | Legionário de Pedra | ruínas do Coliseu: arcos de pedra, colunas, estandartes, sacadas de mármore, braseiros | escudo bloqueia de frente, investida, lanças, salto |
| 14 | Espectro da Caravela | navio atracado no cais: casco, convés, mastros, vergas (plataformas), velas rasgadas, cordas e o mar | voa, some, mergulha, canhão, onda; chama morcegos |
| 21 | Colosso a Vapor | fábrica: tijolos, janelões, engrenagens, canos, fornalhas, correntes, passarelas | pisão, colunas de vapor, engrenagens; superaquece (dano dobrado) |
| 28 | Máquina Enigma | casamata: concreto, seteiras, sacos de areia, holofote, alarmes, vigas | três rotores protegem o núcleo; raios, mísseis e drones |

As arenas se misturam com o estilo escolhido: o chão continua o do estilo (só o navio troca pelo casco),
tudo é pintado em pixels de 2 px, recebe o tom e o escurecimento do estilo e aparece aos poucos na entrada,
com um pontilhado. O que não se mexe é pintado uma vez por fase e depois só copiado (fica leve).

A arte dos chefes vem de `ferramentas/chefes_folha.webp`. Para trocar: edite a folha (ou as imagens em
`assets/chefes/<chefe>/`) e, se mudar a folha, rode `python3 ferramentas/recortar_chefes.py`; as caixas de
recorte de cada animação ficam no começo desse arquivo.

## Música de cada fase

Em `js/config.js`, `musicasPorFase` liga o número da fase a um arquivo de música, por exemplo
`{ 1: 'assets/audio/fases/paleolitico.mp3', 5: 'assets/audio/fases/nilo.mp3' }`.
Fases sem música própria tocam a música principal.

## O que ainda é desenhado por código

Os cenários das arenas dos chefes (`js/arenas.js`, em pixel art), os efeitos que se mexem (água, lava e lama,
chuva, neve, faíscas) e a interface (vida, mapa, diálogos), em `js/efeitos.js` e `js/desenho.js`.

## Créditos e licenças

- Pântano: Fantasy Swamp Forest, de @theflavare. A versão grátis permite usar em jogos e trabalhos
  escolares, mas **não permite modificar nem redistribuir o pacote** (veja `LICENCA_DO_PACOTE.md`).
- Cemitério: pacote "Final", de Anokolisa (uso livre, crédito opcional).
- Monstros: "Forest Monsters FREE" (cogumelo), "Golems Free Version" (golem) e "Flying Forest Enemies FREE"
  (cogumelo voador), pacotes grátis do itch.io.
  Os zips não trazem arquivo de licença: confira a página de cada pacote antes de publicar o jogo.
- Runas, fragmentos, portões e espinhos: desenhados para o jogo (`ferramentas/gerar_objetos.py`).
- Fotos: Wikimedia Commons; autor e licença de cada uma em `creditos.html`.
