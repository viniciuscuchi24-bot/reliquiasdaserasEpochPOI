// gerado por ferramentas/recortar_chefes.py a partir de ferramentas/chefes_folha.webp
// quadro = [largura, altura] de cada quadro; ponto = pés (ou centro) dentro do quadro; escala = tamanho na tela
registrarChefes({
  pasta: "assets/chefes/",
  legionario: {
    escala: 3, apoio: "pe", direita: true, retrato: "retrato.png",
    anim: {
      parado: {"arquivo": "parado.png", "quadro": [28, 42], "ponto": [13.3, 42], "n": 6, "fps": 6, "laco": true},
      andar: {"arquivo": "andar.png", "quadro": [27, 37], "ponto": [11.9, 37], "n": 9, "fps": 10, "laco": true},
      correr: {"arquivo": "correr.png", "quadro": [53, 39], "ponto": [15.4, 39], "n": 4, "fps": 12, "laco": true},
      lanca: {"arquivo": "lanca.png", "quadro": [29, 37], "ponto": [11.3, 37], "n": 5, "fps": 11, "laco": false},
      salto: {"arquivo": "salto.png", "quadro": [49, 62], "ponto": [20.3, 62], "n": 6, "fps": 7, "laco": false},
      dano: {"arquivo": "dano.png", "quadro": [29, 37], "ponto": [13.4, 37], "n": 4, "fps": 6, "laco": true},
      morte: {"arquivo": "morte.png", "quadro": [52, 30], "ponto": [24.8, 30], "n": 3, "fps": 4, "laco": false},
      escudo: {"arquivo": "escudo.png", "quadro": [21, 41], "ponto": [11.7, 41], "n": 3, "fps": 10, "laco": true},
    },
    extra: {
      lanca_voando: {"arquivo": "lanca_voando.png", "quadro": [34, 3], "ponto": [17.3, 1.6], "n": 1, "fps": 8},
    },
  },
  espectro: {
    escala: 2.5, apoio: "centro", direita: true, retrato: "retrato.png",
    anim: {
      parado: {"arquivo": "parado.png", "quadro": [43, 59], "ponto": [20.0, 32.0], "n": 6, "fps": 7, "laco": true},
      voar: {"arquivo": "voar.png", "quadro": [45, 52], "ponto": [21.9, 27.2], "n": 6, "fps": 9, "laco": true},
      mergulho: {"arquivo": "mergulho.png", "quadro": [41, 55], "ponto": [19.2, 30.7], "n": 5, "fps": 9, "laco": false},
      canhao: {"arquivo": "canhao.png", "quadro": [45, 50], "ponto": [19.7, 27.6], "n": 6, "fps": 12, "laco": false},
      sumir: {"arquivo": "sumir.png", "quadro": [42, 42], "ponto": [19.7, 20.5], "n": 4, "fps": 6, "laco": false},
    },
    extra: {
      bala: {"arquivo": "bala.png", "quadro": [24, 25], "ponto": [11.4, 12.0], "n": 1, "fps": 8},
      onda: {"arquivo": "onda.png", "quadro": [75, 56], "ponto": [37.0, 56], "n": 4, "fps": 8},
      respingo: {"arquivo": "respingo.png", "quadro": [50, 54], "ponto": [24.0, 54], "n": 1, "fps": 8},
      jato: {"arquivo": "jato.png", "quadro": [49, 70], "ponto": [22.7, 70], "n": 2, "fps": 8},
      morcego: {"arquivo": "morcego.png", "quadro": [50, 51], "ponto": [24.7, 22.6], "n": 6, "fps": 9},
      tiro: {"arquivo": "tiro.png", "quadro": [26, 26], "ponto": [13.9, 13.0], "n": 1, "fps": 8},
    },
  },
  colosso: {
    escala: 3.5, apoio: "pe", direita: true, retrato: "retrato.png",
    anim: {
      parado: {"arquivo": "parado.png", "quadro": [33, 43], "ponto": [14.6, 43], "n": 7, "fps": 6, "laco": true},
      andar: {"arquivo": "andar.png", "quadro": [32, 42], "ponto": [13.3, 42], "n": 7, "fps": 8, "laco": true},
      pisao: {"arquivo": "pisao.png", "quadro": [45, 48], "ponto": [23.0, 48], "n": 3, "fps": 5, "laco": false},
      arremesso: {"arquivo": "arremesso.png", "quadro": [40, 39], "ponto": [18.2, 39], "n": 4, "fps": 8, "laco": false},
      quente: {"arquivo": "quente.png", "quadro": [51, 43], "ponto": [21.8, 43], "n": 6, "fps": 8, "laco": true},
      dano: {"arquivo": "dano.png", "quadro": [34, 36], "ponto": [16.2, 36], "n": 6, "fps": 8, "laco": true},
      morte: {"arquivo": "morte.png", "quadro": [58, 34], "ponto": [28.1, 34], "n": 6, "fps": 5, "laco": false},
    },
    extra: {
      engrenagem: {"arquivo": "engrenagem.png", "quadro": [24, 24], "ponto": [11.8, 11.2], "n": 1, "fps": 8},
      vapor: {"arquivo": "vapor.png", "quadro": [45, 77], "ponto": [21.7, 77], "n": 3, "fps": 8},
      jato_vapor: {"arquivo": "jato_vapor.png", "quadro": [35, 44], "ponto": [17.9, 44], "n": 4, "fps": 10},
      fumaca: {"arquivo": "fumaca.png", "quadro": [46, 62], "ponto": [16.4, 62], "n": 3, "fps": 8},
    },
  },
  enigma: {
    escala: 2.5, apoio: "centro", direita: true, retrato: "retrato.png",
    anim: {
      parado: {"arquivo": "parado.png", "quadro": [72, 49], "ponto": [35.5, 19.2], "n": 4, "fps": 6, "laco": true},
      voar: {"arquivo": "voar.png", "quadro": [76, 49], "ponto": [38.0, 19.3], "n": 4, "fps": 6, "laco": true},
      raio: {"arquivo": "raio.png", "quadro": [82, 56], "ponto": [37.8, 22.7], "n": 4, "fps": 6, "laco": false},
      bombas: {"arquivo": "bombas.png", "quadro": [67, 52], "ponto": [33.1, 21.0], "n": 3, "fps": 6, "laco": false},
      dano: {"arquivo": "dano.png", "quadro": [65, 42], "ponto": [32.4, 18.5], "n": 4, "fps": 8, "laco": true},
      morte: {"arquivo": "morte.png", "quadro": [70, 40], "ponto": [35.0, 15.8], "n": 2, "fps": 3, "laco": false},
    },
    extra: {
      rotor: {"arquivo": "rotor.png", "quadro": [57, 46], "ponto": [28.4, 17.2], "n": 2, "fps": 8},
      rotor_quebrado: {"arquivo": "rotor_quebrado.png", "quadro": [46, 44], "ponto": [22.5, 19.0], "n": 1, "fps": 8},
      drone: {"arquivo": "drone.png", "quadro": [38, 30], "ponto": [17.9, 13.1], "n": 5, "fps": 8},
      missil: {"arquivo": "missil.png", "quadro": [27, 32], "ponto": [12.6, 15.8], "n": 1, "fps": 8},
      explosao: {"arquivo": "explosao.png", "quadro": [51, 44], "ponto": [25.1, 23.0], "n": 4, "fps": 12},
      fogo: {"arquivo": "fogo.png", "quadro": [58, 57], "ponto": [28.4, 57], "n": 3, "fps": 10},
      alvo: {"arquivo": "alvo.png", "quadro": [62, 71], "ponto": [30.7, 42.7], "n": 1, "fps": 8},
      raio_base: {"arquivo": "raio_base.png", "quadro": [44, 99], "ponto": [21.4, 99], "n": 1, "fps": 8},
      destrocos: {"arquivo": "destrocos.png", "quadro": [108, 99], "ponto": [53.8, 99], "n": 1, "fps": 8},
    },
  },
});
