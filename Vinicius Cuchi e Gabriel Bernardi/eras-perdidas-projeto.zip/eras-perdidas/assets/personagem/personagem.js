// =====================================================================
//  PERSONAGEM (o cronista) — gerado por ferramentas/recortar_personagem.py
//  Uma folha por época: era00.png … era27.png. Cada LINHA da folha é uma animação e cada COLUNA um quadro,
//  todos do mesmo tamanho (quadro). "pes" é o ponto dos pés dentro do quadro; "escala" é o tamanho na tela.
//  impactos.png: o efeito de impacto do golpe de cada época (um quadro por época).
//  asas.png: as asas do pulo duplo (feitas por ferramentas/gerar_asas.py).
//  cortes.png: o rastro do golpe (uma linha por arma, 5 quadros, em meia resolução: aparece em 2x);
//  laminas.png: a espada na mão durante o golpe. Feitos por ferramentas/gerar_cortes.py.
//  bainha.png: a espada embainhada na cintura (uma coluna por melhoria da arma; linha 0 = bainha,
//    linha 1 = cabo). 'cinto' = ponto do cinto no quadro; 'cintura' = onde ele fica no corpo
//    (px para a frente e para cima a partir dos pés). Feita por ferramentas/gerar_bainha.py.
//  Para mudar uma roupa: edite eraNN.png mantendo o tamanho dos quadros.
// =====================================================================
registrarPersonagem({
  pasta: 'assets/personagem/',
  arquivoEra: 'era{nn}.png',
  quadro: [36, 49],
  pes: [17, 48],
  escala: 1.25,
  anim: {
    parado: {"linha": 0, "quadros": [1, 2], "fps": 4},
    andar: {"linha": 1, "quadros": [1, 2, 3, 4], "fps": 11},
    pulo: {"linha": 2, "quadros": [0, 1, 2, 3], "fps": 10},
    ataque: {"linha": 3, "quadros": [0, 1, 2, 3, 4], "fps": 25},
    dano: {"linha": 4, "quadros": [1, 2, 1], "fps": 10},
    pouso: {"linha": 5, "quadros": [0, 1, 2, 3, 4], "fps": 22}
  },
  impactos: { arquivo: 'impactos.png', quadro: [46, 44] },
  asas: { arquivo: 'asas.png', quadro: [40, 38], ombro: [33, 21], n: 4, fps: 16, escala: 1.5 },
  cortes: { arquivo: 'cortes.png', quadro: [147, 56], ombro: [4, 28], n: 5, escala: 2 },
  laminas: { arquivo: 'laminas.png', quadro: [38, 9], mao: [6, 4] },
  bainha: { arquivo: 'bainha.png', quadro: [34, 18], cinto: [15, 5], cintura: [-3, 14] }
});
