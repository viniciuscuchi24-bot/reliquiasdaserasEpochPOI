// =====================================================================
//  INTERFACE — caixa de texto (pergaminho) e barra de vida dos chefes
//  caixa.margens  [esquerda, cima, direita, baixo]: partes da imagem que não esticam (cantos com enfeites)
//  caixa.borda    [x, y]: onde começa o pergaminho, por dentro da moldura (px da imagem)
//  vida.vao       [x, y, largura, altura]: o buraco da moldura onde a vida aparece (px da imagem)
//  Para trocar: substitua os PNG (mesmo nome) e ajuste os números aqui.
// =====================================================================
registrarInterface({
  pasta: 'assets/interface/',
  caixa: {
    imagem: 'caixa.png', margens: [115, 90, 115, 90], borda: [42, 33],
    tinta: '#2a1d12', titulo: '#6e2414', fraca: '#6a5640'      // cores do texto sobre o pergaminho
  },
  vida: {
    moldura: 'vida_moldura.png', barra: 'vida_barra.png', vao: [43, 64, 474, 38],
    largura: 470                                                // largura da moldura na tela
  }
});
