// =====================================================================
//  ESTILO "PÂNTANO ENCANTADO"
//  Arte: Fantasy Swamp Forest (versão grátis) — @theflavare
//  Tudo que o jogo desenha neste estilo vem das imagens desta pasta.
//  Os recortes são [x, y, largura, altura] em pixels dentro da imagem.
//  Para mudar o visual: troque as imagens (mesmo nome) ou ajuste os recortes.
// =====================================================================
registrarEstilo({
  id: 'pantano',
  nome: 'Pântano encantado',
  pasta: 'assets/estilos/pantano/',

  // imagens usadas (apelido: arquivo)
  imagens: {
    terreno: 'imagens/terreno_e_objetos.png',
    fundo1: 'imagens/fundo_1.png'
  },

  // fundo de cada época (foto real + céu do estilo), gerado por ferramentas/montar_cenarios.py
  fundos: 'fundos/e{era}.webp',
  corCeu: '#c6cfe3',                       // cor usada enquanto o fundo carrega
  escurecer: [0.26, 0.14, 0.5],            // escurecimento do fundo (topo, meio, base) para o jogo ficar legível

  // chão: faixa de cima repetida + laterais de pedra na beira dos fossos e nas torres + recheio
  // (topo alterna musgo verde e laranja; cada lista de laterais tem uma peça para cada um)
  chao: {
    img: 'terreno', escala: 2, subir: 8, sobra: 6,
    topo:    [[227, 9, 40, 32], [93, 12, 40, 32]],
    ladoEsq: [[196, 44, 14, 48], [68, 44, 14, 48]],
    ladoDir: [[287, 44, 14, 48], [158, 44, 14, 48]],
    ladoInicio: 20,                          // onde a lateral começa, abaixo do topo (px na tela)
    recheio: '#201c2c'
  },

  // torres e blocos usam as mesmas peças do chão (sem "bloco" aqui = igual ao chão)

  // espinhos do fundo dos fossos (desenho em assets/objetos/objetos.png)
  espinhos: 'espinhos_pantano',

  // teto: recheio + borda de baixo (rochas com pontas)
  teto: {
    img: 'terreno', escala: 2,
    borda: [227, 92, 40, 20],
    recheio: '#201c2c'
  },

  // plataformas finas (dá para subir por baixo)
  plataforma: {
    img: 'terreno', escala: 2, subir: 6,
    esquerda: [81, 160, 12, 12], meio: [93, 160, 53, 12], direita: [146, 160, 12, 12]
  },

  // objetos espalhados pelo chão: r = recorte, escala, peso = chance de aparecer
  objetos: {
    pedra_pequena:  { img: 'terreno', r: [2, 367, 31, 19],   escala: 1.6, peso: 3 },
    pedra_musgo:    { img: 'terreno', r: [35, 363, 57, 23],  escala: 1.5, peso: 3 },
    pedra_media:    { img: 'terreno', r: [30, 387, 68, 31],  escala: 1.4, peso: 2 },
    pedra_grande:   { img: 'terreno', r: [2, 422, 105, 43],  escala: 1.2, peso: 1 },
    totem_1:        { img: 'terreno', r: [1, 303, 30, 51],   escala: 1.5, peso: 1 },
    totem_2:        { img: 'terreno', r: [31, 302, 32, 52],  escala: 1.5, peso: 1 },
    totem_3:        { img: 'terreno', r: [72, 303, 24, 52],  escala: 1.5, peso: 1 },
    rocha_cogumelos:{ img: 'terreno', r: [110, 367, 158, 82], escala: 1.0, peso: .6 },
    cogumelos_azuis:{ img: 'terreno', r: [114, 450, 45, 33],  escala: 1.5, peso: 3, balanca: true }
  },

  // camadas na frente do fundo, com parallax (0 = parada, 1 = anda junto com o chão)
  // base = altura da parte de baixo da camada na tela (a tela tem 540 de altura)
  camadas: [
    { img: 'fundo1', recorte: [0, 0, 696, 110],   escala: 1.2, parallax: 0.3,  base: 160, repetir: 'espelho', alfa: 0.9 },  // cipós no alto
    { img: 'fundo1', recorte: [0, 180, 696, 222], escala: 1.0, parallax: 0.45, base: 505, repetir: 'espelho', alfa: 0.8 }   // cogumelos gigantes
  ],

  creditos: 'Fantasy Swamp Forest — @theflavare (itch.io)'
});
