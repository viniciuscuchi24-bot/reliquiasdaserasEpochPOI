// =====================================================================
//  ESTILO "CEMITÉRIO GÓTICO"
//  Arte: pacote "Final" — Anokolisa
//  Tudo que o jogo desenha neste estilo vem das imagens desta pasta.
//  Os recortes são [x, y, largura, altura] em pixels dentro da imagem.
//  Para mudar o visual: troque as imagens (mesmo nome) ou ajuste os recortes.
// =====================================================================
registrarEstilo({
  id: 'cemiterio',
  nome: 'Cemitério gótico',
  pasta: 'assets/estilos/cemiterio/',

  imagens: {
    blocos: 'imagens/blocos.png',
    arbustos: 'imagens/arbustos.png',
    estatua: 'imagens/estatua.png',
    colina1: 'imagens/colina_1.png',
    colina2: 'imagens/colina_2.png'
  },

  fundos: 'fundos/e{era}.webp',
  corCeu: '#141a2c',
  escurecer: [0.22, 0.1, 0.45],

  // chão: grama sobre terra; na beira dos fossos, parede de tijolos com laje de pedra
  chao: {
    img: 'blocos', escala: 1, subir: 14, sobra: 4, pontaSubir: 10, ladoInicio: 30,
    topo:     [[128, 16, 96, 32]],
    pontaEsq: [[36, 24, 22, 34]],            // laje de pedra na quina
    pontaDir: [[102, 24, 22, 34]],
    ladoEsq:  [[36, 56, 22, 32]],            // tijolos
    ladoDir:  [[102, 56, 22, 32]],
    recheio: '#000000'
  },

  // torres e blocos: tijolos com laje de pedra em cima
  bloco: {
    img: 'blocos', escala: 1, subir: 6, sobra: 4, ladoInicio: 24,
    topo:     [[52, 24, 48, 24]],
    pontaEsq: [[36, 24, 16, 26]],
    pontaDir: [[108, 24, 16, 26]],
    ladoEsq:  [[36, 56, 16, 32]],
    ladoDir:  [[108, 56, 16, 32]],
    recheio: '#000000'
  },

  espinhos: 'espinhos_cemiterio',

  teto: {
    img: 'blocos', escala: 1,
    tijolo: [44, 52, 72, 44],              // parede de tijolos repetida
    borda: [36, 24, 88, 24], virarBorda: true,   // laje de pedra virada para baixo
    recheio: '#050403'
  },

  plataforma: {
    img: 'blocos', escala: 1, subir: 6,
    esquerda: [65, 249, 10, 26], meio: [75, 249, 106, 26], direita: [181, 249, 10, 26]
  },

  objetos: {
    arbusto_dourado: { img: 'arbustos', r: [3, 0, 218, 96],  escala: .42, peso: 3 },
    arbusto_escuro:  { img: 'arbustos', r: [3, 96, 218, 96], escala: .42, peso: 3 },
    planta_seca:     { img: 'blocos',   r: [227, 48, 29, 40], escala: 1,  peso: 2 },
    coluna:          { img: 'blocos',   r: [256, 30, 33, 64], escala: 1.1, peso: 1.5 },
    cerca:           { img: 'blocos',   r: [0, 241, 64, 80],  escala: 1,  peso: 1.5 },
    estatua:         { img: 'estatua',  r: [8, 24, 96, 200],  escala: .7, peso: .5 }
  },

  camadas: [
    { img: 'colina2', parallax: 0.55, base: 600, escala: 1, repetir: 'espaco', espaco: 1500, x0: 0, alfa: 1 },
    { img: 'colina1', parallax: 0.55, base: 610, escala: 1, repetir: 'espaco', espaco: 1500, x0: 760, espelhar: true, alfa: 1 }
  ],

  creditos: 'pacote "Final" — Anokolisa (patreon.com/Anokolisa)'
});
