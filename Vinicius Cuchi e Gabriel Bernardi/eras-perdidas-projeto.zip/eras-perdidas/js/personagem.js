// ===== Personagem: desenha o jogador a partir das folhas de sprite =====
// Dois formatos: folha única com rastro separado (Hallokin, assets/hallokin — o que está em uso; veja desenharFolha
// no fim do arquivo) ou uma folha por época (o cronista antigo, assets/personagem).
// Chamado dentro de drawPlayer (desenho.js), já posicionado no topo-centro do corpo e virado para o lado certo.
// Escolhe a animação pelo que o personagem está fazendo:
//   parado · andar · pulo (subindo, no alto, caindo) · ataque · dano · pouso (depois de uma queda)
//   pulo duplo: as Asas de Dédalo aparecem nas costas e batem enquanto ele sobe.

function animacaoPersonagem() {
  const A = PERSONAGEM.anim, quadro = (nome, i) => ({ nome, q: A[nome].quadros[clamp(i, 0, A[nome].quadros.length - 1)] });
  const ciclo = nome => { const l = A[nome].quadros; return { nome, q: l[Math.floor(G.time * A[nome].fps) % l.length] }; };
  const parte = (nome, falta, total) => quadro(nome, Math.floor((1 - falta / total) * A[nome].quadros.length));
  if (p.dor > 0) return parte('dano', p.dor, .3);
  if (p.atk > 0) return parte('ataque', p.atk, .2);
  if (p.pouso > 0 && p.g) return parte('pouso', p.pouso, .22);
  if (!p.g && p.dashT <= 0) {
    if (p.wall) return quadro('pulo', 3);                   // agarrado na parede
    if (p.asas > .12) return quadro('pulo', 1);              // pulo duplo: encolhido enquanto as asas batem
    if (p.vy < -320) return quadro('pulo', 0);               // subindo
    if (p.vy < 120) return quadro('pulo', 1 + (Math.floor(G.time * 8) % 2));   // no alto
    return quadro('pulo', 3);                                // caindo
  }
  if (p.dashT > 0 || (p.g && Math.abs(p.vx) > 20)) return ciclo('andar');
  return ciclo('parado');
}

// asas do pulo duplo (atrás do corpo). 'costas' = onde elas nascem (px para a frente e para cima a partir dos pés)
function desenharAsas(P, e, pe) {
  if (p.asas <= 0 || !P.asas) return;
  const As = P.asas, asas = carregarImagem(P.pasta + As.arquivo); if (!imagemPronta(asas)) return;
  const q = Math.floor((.55 - p.asas) * As.fps) % As.n, ea = As.escala || e;
  const bx = As.costas ? As.costas[0] : -3 * e, by = As.costas ? pe - As.costas[1] : pe - 28 * e;
  g.save(); g.globalAlpha *= Math.min(1, p.asas / .15);
  g.drawImage(asas, q * As.quadro[0], 0, As.quadro[0], As.quadro[1], Math.round(bx - As.ombro[0] * ea), Math.round(by - As.ombro[1] * ea), Math.round(As.quadro[0] * ea), Math.round(As.quadro[1] * ea));
  g.restore();
}

function desenharPersonagem(era) {
  const P = PERSONAGEM; if (!P) return;
  if (P.arquivo) return desenharFolha();          // personagem de folha única (Hallokin), igual em todas as épocas
  const nn = String(era).padStart(2, '0'), folha = carregarImagem(P.pasta + P.arquivoEra.replace('{nn}', nn));
  if (era + 1 < NR) carregarImagem(P.pasta + P.arquivoEra.replace('{nn}', String(era + 1).padStart(2, '0')));
  const [cw, ch] = P.quadro, [px0, py0] = P.pes, e = P.escala, pe = p.h + 1;   // os pés ficam na base da caixa do jogador
  g.imageSmoothingEnabled = false;
  if (!imagemPronta(folha)) { g.fillStyle = '#0a0a10'; g.beginPath(); g.ellipse(2, 8, 7, 8, 0, 0, 7); g.fill(); g.fillRect(-7, 14, 15, 24); return; }
  // espada embainhada no quadril, do lado de quem olha (uma para cada melhoria da arma); desenhada depois do corpo
  const B = P.bainha, bainha = B && carregarImagem(P.pasta + B.arquivo), temBainha = bainha && imagemPronta(bainha);
  const peca = linha => g.drawImage(bainha, p.wp * B.quadro[0], linha * B.quadro[1], B.quadro[0], B.quadro[1],
    Math.round(B.cintura[0] * e - B.cinto[0] * e), Math.round(pe - B.cintura[1] * e - B.cinto[1] * e), Math.round(B.quadro[0] * e), Math.round(B.quadro[1] * e));
  desenharAsas(P, e, pe);
  const a = animacaoPersonagem(), linha = P.anim[a.nome].linha;
  const passo = a.nome == 'ataque' && !p.up && !p.dn ? Math.round(Math.sin(clamp((.2 - p.atk) / .2, 0, 1) * Math.PI) * 3) : 0;   // corpo vai junto no golpe
  g.drawImage(folha, a.q * cw, linha * ch, cw, ch, Math.round(-px0 * e) + passo, Math.round(pe - py0 * e), Math.round(cw * e), Math.round(ch * e));
  if (temBainha) { peca(0); if (a.nome != 'ataque' && a.nome != 'pouso') peca(1); }   // no golpe a espada está na mão: a bainha fica vazia
}

// impacto do golpe (um desenho por época, em assets/personagem/impactos.png)
function desenharImpactos() {
  if (!G.imp || !G.imp.length || !PERSONAGEM || !PERSONAGEM.impactos) return;
  const I = PERSONAGEM.impactos, im = carregarImagem(PERSONAGEM.pasta + I.arquivo); if (!imagemPronta(im)) return;
  const [w, h] = I.quadro;
  g.save(); g.imageSmoothingEnabled = false;
  if (I.n) {                                       // animação de estouro (um quadro atrás do outro)
    const s = I.escala || 1;
    for (const q of G.imp) {
      const k = Math.min(I.n - 1, Math.floor((1 - q.t / .16) * I.n));
      g.drawImage(im, k * w, 0, w, h, Math.round(q.x - cam.x - I.centro[0] * s), Math.round(q.y - cam.y - I.centro[1] * s), Math.round(w * s), Math.round(h * s));
    }
    g.restore(); return;
  }
  for (const q of G.imp) {
    const k = q.t / .16, esc = .7 + (1 - k) * .5;
    g.globalAlpha = Math.min(1, k * 1.6);
    g.drawImage(im, G.ri * w, 0, w, h, Math.round(q.x - cam.x - w * esc / 2), Math.round(q.y - cam.y - h * esc / 2), Math.round(w * esc), Math.round(h * esc));
  }
  g.restore();
}

// ===== Golpe da espada =====
// Rastro do corte em pixel art (cortes.png, um por arma, do tamanho do alcance) + a espada na mão girando junto.
// De lado o corte varre de cima para baixo; no golpe seguinte (combo) de baixo para cima. Para cima e para baixo
// o mesmo rastro é girado. O desenho acompanha o tempo do golpe (p.atk vai de 0,2 a 0).
const suave = u => 1 - Math.pow(1 - u, 3);
function desenharGolpe() {
  if (p.atk <= 0 || !PERSONAGEM || !PERSONAGEM.cortes || PERSONAGEM.golpes) return;
  const P = PERSONAGEM, C = P.cortes, L = P.laminas, e = P.escala;
  const cortes = carregarImagem(P.pasta + C.arquivo), laminas = carregarImagem(P.pasta + L.arquivo);
  const prog = clamp((.2 - p.atk) / .2, 0, .999), k = Math.floor(prog * C.n), volta = p.combo ? -1 : 1;
  const cx = p.x + p.w / 2 - cam.x, cy = p.y - cam.y;
  let ox, oy, rot, mx, my;                       // ombro (centro do rastro), giro, mão
  if (p.up) { ox = cx; oy = cy + 8; rot = -Math.PI / 2; mx = cx + p.f * 3; my = cy + 12; }
  else if (p.dn) { ox = cx; oy = cy + p.h - 10; rot = Math.PI / 2; mx = cx + p.f * 3; my = cy + 26; }
  else { ox = cx + p.f * 4; oy = cy + 20; rot = 0; mx = cx + p.f * 7; my = cy + 22; }
  g.save(); g.imageSmoothingEnabled = false;
  // espada na mão: acompanha a frente do corte (ângulo de -80° a +80° em volta da direção do golpe)
  if (imagemPronta(laminas)) {
    const ang = volta * (-1.4 + 2.8 * suave(prog));
    g.save(); g.translate(Math.round(mx), Math.round(my)); g.scale(p.f, 1); g.rotate(rot + ang);
    g.drawImage(laminas, 0, p.wp * L.quadro[1], L.quadro[0], L.quadro[1], Math.round(-L.mao[0] * e), Math.round(-L.mao[1] * e), Math.round(L.quadro[0] * e), Math.round(L.quadro[1] * e));
    g.restore();
  }
  // rastro do corte
  if (imagemPronta(cortes)) {
    const [w, h] = C.quadro, s = C.escala;
    g.translate(Math.round(ox), Math.round(oy)); g.scale(p.f, 1); g.rotate(rot); g.scale(1, volta);
    g.drawImage(cortes, k * w, p.wp * h, w, h, -C.ombro[0] * s, -C.ombro[1] * s, w * s, h * s);
  }
  g.restore();
}

// ===== Personagem de folha única (Hallokin) =====
// Uma folha com todas as animações (assets/hallokin/hallokin.png) e outra só com o rastro dos golpes (golpes.png).
// O rastro é desenhado por cima do corpo e esticado na direção do golpe até o alcance da arma: o pedaço 'faixa'
// do quadro estica e a ponta vai junto, então o desenho original não deforma perto do corpo.
const ANIM_GOLPE = { chao: 'ataque', ar: 'ataque_ar', cima: 'ataque_cima', baixo: 'ataque_baixo' };
function animacaoFolha() {
  const A = PERSONAGEM.anim;
  const quadro = (nome, i) => ({ nome, q: A[nome].quadros[clamp(i, 0, A[nome].quadros.length - 1)] });
  const ciclo = nome => { const l = A[nome].quadros; return { nome, q: l[Math.floor(G.time * A[nome].fps) % l.length] }; };
  if (G.mode == 'morte' && A.morte) return quadro('morte', Math.floor((G.morteT0 - G.morteT) * A.morte.fps));
  if (p.dor > .2 && A.dano) return quadro('dano', 0);                  // pisca laranja quando leva dano
  if (p.atk > 0) { const nome = ANIM_GOLPE[p.gTipo] || 'ataque'; if (A[nome]) return quadro(nome, Math.floor(p.gT * A[nome].fps)); }
  if (!p.g && p.dashT <= 0) {
    if (p.wall) return quadro('queda', 0);                              // agarrado na parede
    if (p.asas > .12) return quadro('pulo', 1);                         // pulo duplo
    if (p.vy < -300) return quadro('pulo', 0);                          // subindo
    if (p.vy < -60) return quadro('pulo', 1);
    if (p.vy < 120) return quadro('pulo', 2);                           // no alto
    return ciclo('queda');                                              // caindo
  }
  if (p.dashT > 0 || (p.g && Math.abs(p.vx) > 20)) return ciclo('andar');
  return ciclo('parado');
}

function desenharFolha() {
  const P = PERSONAGEM, folha = carregarImagem(P.pasta + P.arquivo);
  const [cw, ch] = P.quadro, [px0, py0] = P.pes, e = P.escala, pe = p.h + 1;   // os pés ficam na base da caixa do jogador
  g.imageSmoothingEnabled = false;
  if (!imagemPronta(folha)) { g.fillStyle = '#0a0a10'; g.beginPath(); g.ellipse(0, 12, 9, 9, 0, 0, 7); g.fill(); g.fillRect(-7, 20, 14, 19); return; }
  desenharAsas(P, e, pe);
  const a = animacaoFolha(), linha = P.anim[a.nome].linha;
  const x0 = Math.round(-px0 * e), y0 = Math.round(pe - py0 * e);
  g.drawImage(folha, a.q * cw, linha * ch, cw, ch, x0, y0, cw * e, ch * e);
  if (G.mode != 'morte') desenharRastro(P);
}

// rastro laranja do golpe (continua sumindo um pouco depois que o golpe acaba)
// Perto do corpo ele é igual ao da folha. Nas armas de alcance maior, o corte já formado se solta e voa na direção
// do golpe até onde a arma acerta, e lá se desfaz (o desenho não estica: os pixels continuam do mesmo tamanho).
function desenharRastro(P) {
  const nome = ANIM_GOLPE[p.gTipo] || 'ataque', A = P.anim[nome], R = P.golpes && P.golpes[nome];
  if (!A || !R || p.gT == null || p.gT > 1) return;
  const im = carregarImagem(P.pasta + P.golpes.arquivo); if (!imagemPronta(im)) return;
  const [cw, ch] = P.quadro, [px0, py0] = P.pes, e = P.escala, pe = p.h + 1;
  const n = A.quadros.length, k = Math.floor(p.gT * A.fps), r = SW[p.wp].r;
  // quanto falta (em px na tela) para o rastro chegar até onde o golpe acerta (mesmas contas da caixa de acerto em nucleo.js)
  const alvo = R.eixo == 'x' ? r + 5 : R.eixo == '-y' ? r + 31 : r;
  const nativo = (R.eixo == 'x' ? R.ponta - px0 : R.eixo == '-y' ? py0 - R.ponta : R.ponta - py0) * e;
  const extra = Math.max(0, alvo - nativo), voa = extra > 16, t0 = R.solta / A.fps;
  const quadro = (q, d) => g.drawImage(im, A.quadros[q] * cw, A.linha * ch, cw, ch,
    Math.round(-px0 * e) + (R.eixo == 'x' ? d : 0), Math.round(pe - py0 * e) + (R.eixo == '-y' ? -d : R.eixo == 'y' ? d : 0), cw * e, ch * e);
  g.save(); g.imageSmoothingEnabled = false;
  if (p.gf && p.gf != p.f) g.scale(-1, 1);         // o rastro fica para o lado em que o golpe foi dado
  if (k < n && !(voa && k == R.solta)) quadro(k, 0);                       // junto do corpo, como na folha
  if (voa && p.gT >= t0) {                                                 // o corte que voa até o alcance da arma
    const kv = R.solta + Math.floor(Math.max(0, p.gT - t0 - .06) * A.fps);
    if (kv < n) quadro(kv, Math.round(extra * suave(clamp((p.gT - t0) / .14, 0, 1))));
  }
  g.restore();
}
