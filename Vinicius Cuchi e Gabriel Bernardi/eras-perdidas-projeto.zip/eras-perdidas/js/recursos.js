// ===== Carregador de imagens (assets) =====
// Cada imagem é pedida uma vez e guardada. O jogo desenha só quando ela terminou de carregar.
const IMG_CACHE = {};

// Caminho de um arquivo do jogo. Na versão de arquivo único (ferramentas/montar_arquivo_unico.py) as imagens e
// sons vêm embutidos em window.EMBUTIDO; na versão normal é o próprio caminho.
function arquivo(caminho) {
  const E = typeof window != 'undefined' && window.EMBUTIDO;
  if (!E || !caminho) return caminho;
  const partes = [];
  for (const p of String(caminho).split('/')) { if (p == '..') partes.pop(); else if (p && p != '.') partes.push(p); }
  return E[partes.join('/')] || caminho;
}

function carregarImagem(caminho) {
  if (typeof Image == 'undefined' || !caminho) return null;
  let im = IMG_CACHE[caminho];
  if (!im) {
    try { im = new Image(); im.src = arquivo(caminho); }
    catch (e) { im = { complete: true, naturalWidth: 0 }; }
    IMG_CACHE[caminho] = im;
  }
  return im;
}

function imagemPronta(im) {
  return !!(im && im.complete && im.naturalWidth > 0);
}
