// ===== Chefes =====
// Quatro guardiões, cada um com seu jeito de lutar e seu desenho:
//   Roma          -> Legionário de Pedra: escudo que bloqueia de frente, investida, lanças (pila), salto
//   Navegações    -> Espectro da Caravela: voa, some e reaparece, mergulha, balas de canhão, onda
//   Rev. Industr. -> Colosso a Vapor: pisão com ondas de choque, colunas de vapor, engrenagens; superaquece
//   2ª Guerra     -> Máquina Enigma: três rotores protegem o núcleo; feixes, bombardeio e drones
const CHEFES = {
  6:  { id: 'legionario', nome: 'Legionário de Pedra',  hp: 26, w: 66,  h: 112, esc: 1.3, bw: 56, bh: 84 },
  13: { id: 'espectro',   nome: 'Espectro da Caravela', hp: 30, w: 88,  h: 100 },
  20: { id: 'colosso',    nome: 'Colosso a Vapor',      hp: 44, w: 100, h: 140, esc: 1.15, bw: 100, bh: 128 },
  27: { id: 'enigma',     nome: 'Máquina Enigma',       hp: 30, w: 50,  h: 50 }
};

const lado = b => (p.x + p.w / 2 < b.x + b.w / 2 ? -1 : 1);

function mkBoss(R, s) {
  const c = CHEFES[R.i], x0 = s.x0 * T, x1 = s.x1 * T;
  const b = { k: 'B', id: c.id, name: c.nome, w: c.w, h: c.h, hp: c.hp, mh: c.hp, fl: 0, vx: 0, vy: 0, st: 'idle', t: 1.2, d: -1, on: 0, dead: 0, ph2: 0, g: false,
    sec: s.k, ax0: x0 + T, ax1: x1 - 3 * T, n: 0, esc: c.esc || 1, bw: c.bw, bh: c.bh };
  if (c.id == 'espectro') { b.x = x1 - 14 * T; b.ay = 6.5 * T; b.y = b.ay; b.ax = b.x; b.fly = 1; b.alfa = 1; b.inv = 0; }
  else if (c.id == 'enigma') {
    b.corpo = x1 - 10 * T;                       // de onde saem os feixes (lado esquerdo da máquina)
    b.x = b.corpo + 1.6 * T - 25; b.y = 7.4 * T - 25; b.noContact = 1; b.fly = 1;   // núcleo = olho vermelho no centro da máquina
    b.rot = [FY * T - 62, 11.4 * T - 16, 6 * T - 16].map((y, j) => ({ k: 'rot', x: b.corpo - 112 + j * 12, y: y - 3, w: 44, h: 40, hp: 14, mh: 14, fl: 0, dead: 0, noContact: 1, sec: s.k, j, chefe: b }));
  } else { b.x = x1 - 14 * T; b.y = FY * T - c.h; }
  R.es.push(b); if (b.rot) b.rot.forEach(r => R.es.push(r));
  return b;
}

// --- projéteis (todos os ataques que voam ou aparecem no chão) ---
function proj(R, o) { R.pr.push(Object.assign({ vx: 0, vy: 0, gr: 0, t: 3, warn: 0, k: 'onda' }, o)); }
function atualizarProjeteis(dt) {
  const R = G.rm;
  for (const q of R.pr) {
    q.t -= dt;
    if (q.warn > 0) { q.warn -= dt; continue; }
    if (q.k == 'bomba' && !q.caindo) { q.caindo = 1; }
    q.vy += q.gr * dt; q.x += q.vx * dt; q.y += q.vy * dt;
    if (q.gr && q.y + q.h >= FY * T) {
      if (q.k == 'engrenagem') { q.y = FY * T - q.h; q.vy = -Math.abs(q.vy) * .55; if (Math.abs(q.vy) < 120) q.vy = 0; }
      else if (q.k == 'bomba' || q.k == 'bala') { q.t = 0; proj(R, { k: 'explosao', x: q.x + q.w / 2 - 34, y: FY * T - 60, w: 68, h: 60, t: .32 }); burst(q.x + q.w / 2, FY * T - 10, 16, '#ffb347'); G.shake = Math.max(G.shake, .2); }
      else if (q.k == 'pilum') { q.t = Math.min(q.t, .5); q.vx = q.vy = q.gr = 0; q.y = FY * T - q.h; q.preso = 1; }
    }
    if (!q.preso && q.k != 'marca' && ov(p, q)) hurt(1, q.vx > 0 ? 1 : (q.vx < 0 ? -1 : (p.x + 11 < q.x + q.w / 2 ? -1 : 1)));
  }
  R.pr = R.pr.filter(q => q.t > 0 && q.x > -200 && q.x < R.W * T + 200);
}

// segurança: chefe nunca sai da arena nem fica preso em cima de paredes
function manterNaArena(b, R) {
  const s = R.secs[b.sec];
  b.x = clamp(b.x, s.x0 * T + T, s.gx - b.w);
  if (b.y < 2 * T) { b.y = FY * T - b.h; b.vy = 0; }
}

// --- o escudo/forma do chefe bloqueia o golpe? ---
function chefeDefende(b, hb) {
  if (b.id == 'legionario') return b.st != 'atordoado' && !p.dn && !p.up && lado(b) == b.d;   // golpe de frente bate no escudo
  if (b.id == 'espectro') return b.inv > 0;
  if (b.id == 'enigma') return b.rot.some(r => !r.dead);
  return false;
}
function multiplicadorChefe(b) { return b.id == 'colosso' && b.st == 'superaquecido' ? 2 : 1; }

function ativarChefe(b, R) {
  const s = R.secs[b.sec];
  if (p.x > s.x0 * T + 8 * T) { b.on = 1; R.lock = true; R.lockX = s.x0 * T; G.ban = { t: 3.4, a: b.name, b: 'Guardião de ' + R.E.n, retrato: b.id }; G.dica = { s: DICA_CHEFE[b.id], t: 7 }; }
}
const DICA_CHEFE = {
  legionario: 'O escudo bloqueia golpes de frente. Ataque pelas costas, quique na cabeça (↓ + golpe) ou acerte quando ele bater na parede.',
  espectro: 'Ele só pode ser atingido quando está visível. Espere o mergulho para acertar de perto.',
  colosso: 'Pule as ondas do pisão e fuja das colunas de vapor. Depois do vapor ele superaquece e leva dano dobrado.',
  enigma: 'Destrua os três rotores para expor o núcleo. Pule os feixes baixos; fique no chão nos feixes altos.'
};

function updBoss(b, dt, S) {
  const R = G.rm; b.fl -= dt; if (b.bloq > 0) b.bloq -= dt;
  if (!b.on) { ativarChefe(b, R); if (!b.fly) { b.vy = Math.min(900, b.vy + 2200 * dt); const [, hy] = mv(b, 0, b.vy * dt, S); if (hy) b.vy = 0; } return; }
  if (!b.ph2 && b.hp <= b.mh / 2 && b.id != 'enigma') { b.ph2 = 1; G.shake = .4; toast(b.name + ' está furioso!', 2); if (b.id == 'espectro') invocar(R, b, 2); }
  b.t -= dt;
  IA_CHEFE[b.id](b, dt, S, R);
}
function invocar(R, b, n) {
  for (let k = 0; k < n; k++) {
    const e = mkEnemy({ k: 'f', x: b.x + b.w / 2 + (k ? 60 : -90), y: 6 * T, hp: 3 }); e.sec = b.sec; e.onda = 0;
    // os ajudantes usam a arte do chefe: morcegos no navio fantasma, drones na Enigma
    if (b.id == 'espectro') { e.arte = { id: 'espectro', nome: 'morcego', esc: 1, anima: 1 }; e.w = 34; e.h = 32; }
    if (b.id == 'enigma') { e.arte = { id: 'enigma', nome: 'drone', esc: 1.3, q: Math.floor(Math.random() * 5) }; e.w = 34; e.h = 26; }
    R.es.push(e); burst(e.x + e.w / 2, e.y + e.h / 2, 12, b.id == 'enigma' ? '#ff6a4a' : '#9ff');
  }
}

const IA_CHEFE = {
  // ---------------- Legionário de Pedra ----------------
  legionario(b, dt, S, R) {
    b.vy = Math.min(900, b.vy + 2200 * dt);
    const dist = Math.abs(p.x - b.x);
    if (b.st == 'idle') {
      b.d = lado(b); b.vx = dist > 190 ? b.d * (b.ph2 ? 90 : 70) : 0;   // caminha na sua direção
      if (b.t <= 0) {
        b.vx = 0; const r = Math.random();
        if (dist > 200 && r < .45) { b.st = 'prep'; b.nx = 'investida'; b.t = .55; }
        else if (r < .78) { b.st = 'prep'; b.nx = 'pilum'; b.t = .45; }
        else { b.st = 'salto'; b.vy = -820; b.vx = b.d * Math.min(360, dist * 1.1); b.t = .3; }
      }
    } else if (b.st == 'prep') {
      b.vx = 0;
      if (b.t <= 0) {
        if (b.nx == 'investida') { b.st = 'investida'; b.t = 1.7; b.vx = b.d * (b.ph2 ? 640 : 540); }
        else {
          const n = b.ph2 ? 3 : 1;
          for (let k = 0; k < n; k++) {
            const x0 = b.x + b.w / 2, y0 = b.y + 18, tx = p.x + 11 + (k - (n - 1) / 2) * 110, Tf = .85, gr = 1100;
            proj(R, { k: 'pilum', x: x0 - 10, y: y0, w: 20, h: 8, vx: clamp((tx - x0) / Tf, -560, 560), vy: (p.y + 19 - y0) / Tf - .5 * gr * Tf, gr, t: 3 });
          }
          b.st = 'idle'; b.t = b.ph2 ? .75 : 1.05;
        }
      }
    } else if (b.st == 'investida') { if (b.t <= 0) { b.st = 'idle'; b.t = .8; b.vx = 0; } }
    else if (b.st == 'atordoado') { b.vx = 0; if (b.t <= 0) { b.st = 'idle'; b.t = .5; } }
    const [hx, hy] = mv(b, b.vx * dt, b.vy * dt, S);
    b.g = hy > 0; if (hy) b.vy = 0;
    manterNaArena(b, R);
    if (hx && b.st == 'investida') { b.st = 'atordoado'; b.t = 1.5; b.vx = 0; G.shake = .45; burst(b.x + (b.d > 0 ? b.w : 0), b.y + 30, 18, '#ddd'); toast('O escudo caiu — ataque!', 1.4); }
    if (b.st == 'salto' && b.g && b.t <= 0) {
      b.st = 'idle'; b.t = .9; b.vx = 0; G.shake = .35;
      const sp = b.ph2 ? 330 : 260;
      proj(R, { k: 'onda', x: b.x + b.w / 2, y: FY * T - 22, w: 26, h: 22, vx: sp, t: 2.2 });
      proj(R, { k: 'onda', x: b.x + b.w / 2 - 26, y: FY * T - 22, w: 26, h: 22, vx: -sp, t: 2.2 });
    }
  },

  // ---------------- Espectro da Caravela ----------------
  espectro(b, dt, S, R) {
    b.inv = Math.max(0, (b.inv || 0) - dt);
    const tx = p.x + 11 - b.w / 2;
    const voltar = sp => { const dy = b.ay - b.y; b.y += clamp(dy, -sp * dt, sp * dt); };
    if (b.st == 'idle') {
      b.ax += clamp(tx - b.ax, -70, 70) * dt; b.x = b.ax + Math.sin(G.time * 1.3) * 26; b.y = b.ay + Math.sin(G.time * 1.9) * 14; b.alfa = Math.min(1, b.alfa + dt * 2);
      if (b.t <= 0) {
        b.n++; const r = Math.random();
        if (b.ph2 && b.n % 3 == 0) { b.st = 'onda'; b.t = .6; }
        else if (r < .36) { b.st = 'prep_mergulho'; b.t = .6; }
        else if (r < .68) { b.st = 'prep_canhao'; b.t = .45; }
        else { b.st = 'some'; b.t = 1.0; b.inv = 1.6; }
      }
    } else if (b.st == 'prep_mergulho') {
      b.x += Math.sin(G.time * 40) * 1.5;
      if (b.t <= 0) { const dx = tx - b.x, dy = (FY * T - b.h) - b.y, d = Math.hypot(dx, dy) || 1, sp = b.ph2 ? 540 : 460; b.vx = dx / d * sp; b.vy = dy / d * sp; b.st = 'mergulho'; b.t = 1.6; }
    } else if (b.st == 'mergulho') {
      b.x += b.vx * dt; b.y += b.vy * dt;
      if (b.y + b.h >= FY * T - 4 || b.t <= 0) { b.y = Math.min(b.y, FY * T - b.h - 4); b.st = 'rasante'; b.t = .7; b.vx = Math.sign(b.vx || 1) * 230; }
    } else if (b.st == 'rasante') {
      b.x += b.vx * dt; if (b.t <= 0) { b.st = 'sobe'; b.t = 2; }
    } else if (b.st == 'sobe') {
      voltar(260); b.ax = b.x; if (Math.abs(b.y - b.ay) < 4 || b.t <= 0) { b.st = 'idle'; b.t = b.ph2 ? .8 : 1.2; }
    } else if (b.st == 'prep_canhao') {
      if (b.t <= 0) {
        const n = b.ph2 ? 5 : 3;
        for (let k = 0; k < n; k++) {
          const x0 = b.x + b.w / 2, y0 = b.y + b.h / 2, alvo = p.x + 11 + (k - (n - 1) / 2) * 120, Tf = 1.0, gr = 900;
          proj(R, { k: 'bala', x: x0 - 9, y: y0, w: 18, h: 18, vx: (alvo - x0) / Tf, vy: (FY * T - 9 - y0) / Tf - .5 * gr * Tf, gr, t: 3 });
        }
        b.st = 'idle'; b.t = b.ph2 ? .9 : 1.3;
      }
    } else if (b.st == 'some') {
      b.alfa = Math.max(.12, b.alfa - dt * 3);
      if (b.t <= 0) { const meio = (b.ax0 + b.ax1) / 2; b.ax = p.x < meio ? b.ax1 - 5 * T : b.ax0 + 4 * T; b.x = b.ax; b.st = 'aparece'; b.t = .5; burst(b.x + b.w / 2, b.y + b.h / 2, 14, '#9ff'); }
    } else if (b.st == 'aparece') {
      b.alfa = Math.min(1, b.alfa + dt * 2.5); if (b.t <= 0) { b.inv = 0; b.st = 'idle'; b.t = .9; }
    } else if (b.st == 'onda') {
      if (b.t <= 0) {
        const daEsq = p.x > (b.ax0 + b.ax1) / 2;
        proj(R, { k: 'agua', x: daEsq ? b.ax0 : b.ax1 - 40, y: FY * T - 64, w: 40, h: 64, vx: daEsq ? 300 : -300, t: 5 });
        b.st = 'idle'; b.t = 1.0; toast('Onda!', 1);
      }
    }
    b.x = clamp(b.x, b.ax0, b.ax1 - b.w);
  },

  // ---------------- Colosso a Vapor ----------------
  colosso(b, dt, S, R) {
    b.vy = Math.min(900, b.vy + 2200 * dt);
    if (b.st == 'idle' || b.st == 'anda') {
      b.d = lado(b); b.vx = b.d * (b.ph2 ? 120 : 85); b.st = 'anda';
      if (b.t <= 0) {
        const r = Math.random(); b.vx = 0;
        if (r < .4) { b.st = 'prep_pisao'; b.t = .75; b.seg = 0; }
        else if (r < .72) { b.st = 'prep_vapor'; b.t = .4; }
        else { b.st = 'prep_eng'; b.t = .55; }
      }
    } else if (b.st == 'prep_pisao') {
      b.vx = 0;
      if (b.t <= 0) {
        G.shake = .5; const sp = b.ph2 ? 360 : 300;
        proj(R, { k: 'onda', x: b.x + b.w, y: FY * T - 28, w: 30, h: 28, vx: sp, t: 2.6 });
        proj(R, { k: 'onda', x: b.x - 30, y: FY * T - 28, w: 30, h: 28, vx: -sp, t: 2.6 });
        if (b.ph2 && !b.seg) { b.seg = 1; b.st = 'prep_pisao'; b.t = .55; } else { b.st = 'anda'; b.t = 1.4; }
      }
    } else if (b.st == 'prep_vapor') {
      b.vx = 0;
      if (b.t <= 0) {
        const xs = [p.x + 11]; for (let k = 0; k < (b.ph2 ? 4 : 3); k++) xs.push(b.ax0 + 2 * T + Math.random() * (b.ax1 - b.ax0 - 4 * T));
        xs.forEach(x => proj(R, { k: 'vapor', x: x - 22, y: 3 * T, w: 44, h: FY * T - 3 * T, warn: .95, t: 1.95 }));
        b.st = 'vapor'; b.t = 1.9;
      }
    } else if (b.st == 'vapor') {
      b.vx = 0; if (b.t <= 0) { b.st = 'superaquecido'; b.t = 2.3; toast('Superaquecido! Dano dobrado', 1.6); }
    } else if (b.st == 'superaquecido') {
      b.vx = 0; if (Math.random() < dt * 10) burst(b.x + b.w / 2, b.y + 20, 2, '#ccc'); if (b.t <= 0) { b.st = 'anda'; b.t = 1.2; }
    } else if (b.st == 'prep_eng') {
      b.vx = 0;
      if (b.t <= 0) {
        for (let k = 0; k < 2; k++) proj(R, { k: 'engrenagem', x: b.x + b.w / 2 - 16, y: b.y + 40, w: 32, h: 32, vx: b.d * (240 + k * 110), vy: -420 - k * 80, gr: 1400, t: 4 });
        b.st = 'anda'; b.t = 1.1;
      }
    }
    const [hx, hy] = mv(b, b.vx * dt, b.vy * dt, S); b.g = hy > 0; if (hy) b.vy = 0;
    manterNaArena(b, R);
  },

  // ---------------- Máquina Enigma ----------------
  enigma(b, dt, S, R) {
    b.rot.forEach(r => { r.fl -= dt; });
    const vivos = b.rot.filter(r => !r.dead).length;
    if (!vivos && !b.ph2) { b.ph2 = 1; G.shake = .6; toast('O núcleo está exposto!', 2.2); b.t = Math.min(b.t, .8); }
    if (b.t > 0) return;
    const ciclo = ['feixe', 'bombas', 'feixe', 'drones'];
    const atk = ciclo[b.n++ % ciclo.length];
    const xEsq = R.secs[b.sec].x0 * T + T, larg = b.corpo - xEsq;
    b.ataque = atk == 'feixe' ? 'raio' : atk == 'bombas' ? 'bombas' : null; b.ataqueT = G.time;
    if (atk == 'feixe') {
      const alto = Math.random() < .5;
      const y = alto ? FY * T - 128 : FY * T - 44, h = alto ? 36 : 32;
      proj(R, { k: 'feixe', x: xEsq, y, w: larg, h, warn: 1.0, t: 1.5 });
      if (b.ph2) proj(R, { k: 'feixe', x: xEsq, y: alto ? FY * T - 44 : 8 * T, w: larg, h: 32, warn: 1.8, t: 2.3 });
    } else if (atk == 'bombas') {
      const xs = [p.x + 11]; for (let k = 0; k < (b.ph2 ? 5 : 3); k++) xs.push(xEsq + 40 + Math.random() * (larg - 80));
      xs.forEach(x => { proj(R, { k: 'marca', x: x - 20, y: FY * T - 6, w: 40, h: 6, t: 1.05 }); proj(R, { k: 'bomba', x: x - 12, y: 2 * T, w: 24, h: 30, warn: 1.0, gr: 1800, t: 3 }); });
    } else {
      const vivosD = R.es.filter(e => e.k == 'f' && e.sec == b.sec && !e.dead).length;
      if (vivosD < 3) invocar(R, b, 2);
    }
    b.t = b.ph2 ? 1.5 : 2.3;
  }
};

// ======================= DESENHO DOS CHEFES =======================
function desenharChefe(b) {
  if (typeof desenharChefeArte == 'function' && desenharChefeArte(b)) return;   // imagens de assets/chefes (js/chefes_arte.js)
  if (b.dead && b.id != 'enigma') return;
  let x = b.x - cam.x, y = b.y - cam.y;
  g.save();
  if (!b.fly && !b.dead) glow(G.rm.E.hu, x + b.w / 2, y + b.h * .55, b.h * .95, .22, 60);   // contraluz para destacar do fundo
  if (b.esc && b.esc != 1) { g.translate(x + b.w / 2, y + b.h); g.scale(b.esc, b.esc); x = -b.bw / 2; y = -b.bh; }
  DESENHO_CHEFE[b.id](b, x, y, b.fl > 0);
  g.restore();
}
const DESENHO_CHEFE = {
  legionario(b, x, y, fl) {
    const d = b.d, cx = x + 28, ferro = fl ? '#fff' : '#3a3a46', borda = fl ? '#fff' : '#6a6a78';
    g.lineJoin = 'round';
    // pernas e saiote
    g.fillStyle = fl ? '#fff' : '#1b1b22'; g.fillRect(cx - 14, y + 62, 10, 22); g.fillRect(cx + 4, y + 62, 10, 22);
    g.fillStyle = fl ? '#fff' : '#5a1c1c'; for (let k = 0; k < 5; k++) g.fillRect(cx - 18 + k * 7.5, y + 50, 6, 16);
    // tronco com armadura de placas
    g.fillStyle = ferro; g.fillRect(cx - 18, y + 22, 36, 32); g.strokeStyle = borda; g.lineWidth = 2;
    for (let k = 0; k < 4; k++) { g.beginPath(); g.moveTo(cx - 18, y + 28 + k * 7); g.lineTo(cx + 18, y + 28 + k * 7); g.stroke(); }
    // cabeça com elmo (galea) e crista vermelha transversal
    g.fillStyle = ferro; g.beginPath(); g.arc(cx, y + 14, 13, Math.PI, 0); g.fill(); g.fillRect(cx - 13, y + 14, 26, 8);
    g.fillStyle = fl ? '#fff' : '#b0201c'; g.beginPath(); g.ellipse(cx, y + 1, 18, 6, 0, Math.PI, 0); g.fill();
    g.fillStyle = b.ph2 ? '#ff5a4a' : '#ffd27a'; g.fillRect(cx + d * 4 - 3, y + 15, 6, 3);
    // lança (atrás)
    g.strokeStyle = fl ? '#fff' : '#6b5a3a'; g.lineWidth = 3; g.beginPath(); g.moveTo(cx - d * 20, y + 80); g.lineTo(cx - d * 26, y - 6); g.stroke();
    g.fillStyle = '#ccc'; g.beginPath(); g.moveTo(cx - d * 26 - 4, y - 4); g.lineTo(cx - d * 27, y - 18); g.lineTo(cx - d * 26 + 4, y - 4); g.fill();
    // escudo (scutum) na frente; abaixado quando atordoado
    const caido = b.st == 'atordoado', sx = cx + d * (caido ? 10 : 20) - 13, sy = y + (caido ? 46 : 18);
    g.save(); g.translate(sx + 13, sy + 22); if (caido) g.rotate(d * 1.1);
    g.fillStyle = fl ? '#fff' : (b.st == 'prep' && b.nx == 'investida' ? '#d23a2a' : '#8a1d1a'); g.fillRect(-13, -26, 26, 52);
    g.strokeStyle = '#d7b45a'; g.lineWidth = 2.5; g.strokeRect(-13, -26, 26, 52); g.fillStyle = '#d7b45a'; g.beginPath(); g.arc(0, 0, 5, 0, 7); g.fill();
    g.restore();
    if (caido) for (let k = 0; k < 3; k++) { const a = G.time * 5 + k * 2.1; diamond(cx + Math.cos(a) * 16, y - 6 + Math.sin(a) * 4, 4, '#ffe9a0'); }
    if (b.st == 'prep' && b.nx == 'pilum') { g.strokeStyle = '#e0d0a0'; g.lineWidth = 3; g.beginPath(); g.moveTo(cx - d * 4, y + 24); g.lineTo(cx - d * 18, y - 14); g.stroke(); }
  },

  espectro(b, x, y, fl) {
    const cx = x + b.w / 2, t = G.time, a = b.alfa == null ? 1 : b.alfa;
    g.globalAlpha = a * .9;
    glow(185, cx, y + 34, 90, .35 * a, 70);
    // manto em farrapos que vira fumaça
    g.fillStyle = fl ? '#fff' : 'rgba(150,235,230,.55)';
    g.beginPath(); g.moveTo(cx - 22, y + 20);
    for (let k = 0; k <= 8; k++) { const px = cx - 26 + k * 6.5, py = y + 66 + Math.sin(t * 6 + k) * 6 + (k % 2) * 8; g.lineTo(px, py); }
    g.lineTo(cx + 22, y + 20); g.closePath(); g.fill();
    g.fillStyle = fl ? '#fff' : 'rgba(60,110,120,.85)'; g.fillRect(cx - 16, y + 20, 32, 26);
    // braços com corrente
    g.strokeStyle = 'rgba(170,240,235,.7)'; g.lineWidth = 3; g.beginPath(); g.moveTo(cx - 16, y + 26); g.lineTo(cx - 30, y + 40 + Math.sin(t * 3) * 4); g.moveTo(cx + 16, y + 26); g.lineTo(cx + 30, y + 40 - Math.sin(t * 3) * 4); g.stroke();
    // cabeça (caveira) e tricórnio
    g.fillStyle = fl ? '#fff' : '#d8f6f2'; g.beginPath(); g.arc(cx, y + 12, 11, 0, 7); g.fill();
    g.fillStyle = '#0a1418'; g.fillRect(cx - 6, y + 9, 4, 4); g.fillRect(cx + 2, y + 9, 4, 4);
    g.fillStyle = b.ph2 ? '#ff6a5a' : '#7ffff0'; g.fillRect(cx - 5, y + 10, 2, 2); g.fillRect(cx + 3, y + 10, 2, 2);
    g.fillStyle = fl ? '#fff' : '#1a2a30'; g.beginPath(); g.moveTo(cx - 20, y + 4); g.lineTo(cx, y - 10); g.lineTo(cx + 20, y + 4); g.lineTo(cx, y); g.closePath(); g.fill();
    // lanterna
    glow(50, cx + 30, y + 46, 26, .5 * a, 70); g.fillStyle = '#ffd27a'; g.fillRect(cx + 27, y + 42, 6, 8);
    if (b.st == 'prep_mergulho' || b.st == 'prep_canhao') glow(0, cx, y + 12, 40, .4, 60);
    g.globalAlpha = 1;
  },

  colosso(b, x, y, fl) {
    const cx = x + 50, d = b.d || -1, t = G.time, quente = b.st == 'superaquecido';
    const anda = b.st == 'anda' ? Math.sin(t * 6) * 4 : 0, pisa = b.st == 'prep_pisao' ? -14 : 0;
    const metal = fl ? '#fff' : '#34343c', escuro = fl ? '#fff' : '#1d1d23';
    // pernas de pistão
    g.fillStyle = escuro; g.fillRect(cx - 34, y + 92 + anda + pisa, 22, 36 - anda - pisa); g.fillRect(cx + 12, y + 92 - anda, 22, 36 + anda);
    g.fillStyle = '#6a6a72'; g.fillRect(cx - 28, y + 86 + pisa, 10, 12); g.fillRect(cx + 18, y + 86, 10, 12);
    // caldeira (corpo)
    g.fillStyle = metal; g.beginPath(); g.ellipse(cx, y + 58, 48, 40, 0, 0, 7); g.fill();
    g.fillStyle = '#5a5a62'; for (let k = 0; k < 10; k++) { const a = k / 10 * Math.PI * 2; g.beginPath(); g.arc(cx + Math.cos(a) * 42, y + 58 + Math.sin(a) * 34, 2.2, 0, 7); g.fill(); }
    // fornalha (ponto fraco brilha quando superaquecido)
    const brilho = quente ? .9 + .1 * Math.sin(t * 20) : .45;
    glow(22, cx, y + 64, quente ? 70 : 40, brilho * .6, 55);
    g.fillStyle = quente ? '#ffd27a' : '#c2501c'; g.fillRect(cx - 16, y + 54, 32, 22);
    g.strokeStyle = escuro; g.lineWidth = 3; for (let k = 0; k < 4; k++) { g.beginPath(); g.moveTo(cx - 16 + k * 10.6, y + 54); g.lineTo(cx - 16 + k * 10.6, y + 76); g.stroke(); }
    // manômetro
    g.fillStyle = '#d8d0b8'; g.beginPath(); g.arc(cx + d * 26, y + 36, 9, 0, 7); g.fill(); g.strokeStyle = '#b02020'; g.lineWidth = 2; g.beginPath(); g.moveTo(cx + d * 26, y + 36); g.lineTo(cx + d * 26 + Math.cos(t * (quente ? 9 : 2)) * 7, y + 36 + Math.sin(t * (quente ? 9 : 2)) * 7); g.stroke();
    // braços
    g.fillStyle = metal; g.fillRect(cx + d * 44 - 9, y + 46, 18, 34); g.fillStyle = '#6a6a72'; g.beginPath(); g.arc(cx + d * 44, y + 84, 12, 0, 7); g.fill();
    // chaminé com fumaça
    g.fillStyle = escuro; g.fillRect(cx - d * 18 - 8, y - 6, 16, 30); g.fillRect(cx - d * 18 - 12, y - 10, 24, 6);
    for (let k = 0; k < 4; k++) { const u = (t * .7 + k / 4) % 1; g.fillStyle = 'rgba(140,140,150,' + (.35 * (1 - u)) + ')'; g.beginPath(); g.arc(cx - d * 18 + Math.sin(t + k) * 6, y - 14 - u * 60, 7 + u * 14, 0, 7); g.fill(); }
    // olhos
    g.fillStyle = b.ph2 ? '#ff5a4a' : '#ffcf6a'; g.fillRect(cx + d * 10 - 12, y + 30, 8, 5); g.fillRect(cx + d * 10 + 2, y + 30, 8, 5);
  },

  enigma(b, x, y, fl) {
    const R = G.rm, t = G.time, cx0 = b.corpo - cam.x, topo = 2 * T - cam.y, base = FY * T - cam.y, morto = b.dead;
    // cabos no teto
    g.strokeStyle = '#111'; g.lineWidth = 4; for (let k = 0; k < 5; k++) { g.beginPath(); g.moveTo(cx0 + 20 + k * 44, topo); g.quadraticCurveTo(cx0 + 40 + k * 40, topo + 40, cx0 + 30 + k * 44, topo + 70); g.stroke(); }
    // gabinete
    g.fillStyle = morto ? '#151515' : '#24221e'; g.fillRect(cx0, topo + 60, 7 * T, base - topo - 60);
    g.strokeStyle = '#4a4436'; g.lineWidth = 3; g.strokeRect(cx0, topo + 60, 7 * T, base - topo - 60);
    // teclado e painel de lâmpadas com letras
    g.font = 'bold 11px monospace'; g.textAlign = 'center';
    for (let r = 0; r < 3; r++) for (let c = 0; c < 8; c++) {
      const lx = cx0 + 28 + c * 22, ly = base - 120 + r * 26, on = !morto && Math.sin(t * 3 + r * 7 + c * 13) > .7;
      g.fillStyle = on ? '#ffe38a' : '#3a3628'; g.beginPath(); g.arc(lx, ly, 8, 0, 7); g.fill();
      g.fillStyle = on ? '#3a2a00' : '#8a8060'; g.fillText('QWERTZUIOASDFGHJKPYXCVBNML'[(r * 8 + c) % 26], lx, ly + 4);
    }
    // rotores (pontos fracos)
    b.rot.forEach((r, j) => {
      const rx = r.x + r.w / 2 - cam.x, ry = r.y + r.h / 2 - cam.y;
      g.strokeStyle = '#3a3428'; g.lineWidth = 6; g.beginPath(); g.moveTo(rx, ry); g.lineTo(cx0 + 4, ry); g.stroke();
      if (r.dead) { g.fillStyle = '#1a1a1a'; g.beginPath(); g.arc(rx, ry, 12, 0, 7); g.fill(); return; }
      glow(48, rx, ry, 34, .3, 60);
      g.save(); g.translate(rx, ry); g.rotate(t * (1.5 + j));
      g.fillStyle = r.fl > 0 ? '#fff' : '#b8a678'; g.beginPath(); g.arc(0, 0, 17, 0, 7); g.fill();
      g.fillStyle = '#3a3020'; for (let k = 0; k < 8; k++) { g.rotate(Math.PI / 4); g.fillRect(-1.5, -17, 3, 6); }
      g.fillStyle = '#222'; g.font = 'bold 12px monospace'; g.fillText('ABC'[j], 0, 4); g.restore();
    });
    // núcleo
    const nx = b.x + b.w / 2 - cam.x, ny = b.y + b.h / 2 - cam.y, exposto = !b.rot.some(r => !r.dead);
    g.strokeStyle = '#3a3428'; g.lineWidth = 8; g.beginPath(); g.moveTo(nx, ny); g.lineTo(cx0 + 4, ny); g.stroke();
    if (!morto) {
      glow(0, nx, ny, exposto ? 60 : 34, exposto ? .55 + .2 * Math.sin(t * 8) : .25, 55);
      g.fillStyle = fl ? '#fff' : (exposto ? '#ff4a3a' : '#6a2a22'); g.beginPath(); g.arc(nx, ny, 20, 0, 7); g.fill();
      if (!exposto) { g.strokeStyle = '#8a8070'; g.lineWidth = 4; for (let k = -1; k <= 1; k++) { g.beginPath(); g.moveTo(nx - 22, ny + k * 9); g.lineTo(nx + 22, ny + k * 9); g.stroke(); } }
    }
  }
};

// projéteis e avisos
function desenharProjeteis() {
  const R = G.rm, t = G.time;
  for (const q of R.pr) {
    if (typeof desenharProjetilArte == 'function' && desenharProjetilArte(q)) continue;
    const x = q.x - cam.x, y = q.y - cam.y, w = q.w, h = q.h, aviso = q.warn > 0;
    switch (q.k) {
      case 'onda': g.fillStyle = '#ff6a55'; g.beginPath(); g.moveTo(x, y + h); g.lineTo(x + w / 2, y); g.lineTo(x + w, y + h); g.fill(); break;
      case 'pilum': { g.save(); g.translate(x + w / 2, y + h / 2); g.rotate(Math.atan2(q.vy, q.vx || .001) * (q.preso ? 0 : 1) + (q.preso ? -1.2 : 0)); g.strokeStyle = '#8a6a40'; g.lineWidth = 3; g.beginPath(); g.moveTo(-18, 0); g.lineTo(12, 0); g.stroke(); g.fillStyle = '#ddd'; g.beginPath(); g.moveTo(12, -4); g.lineTo(22, 0); g.lineTo(12, 4); g.fill(); g.restore(); break; }
      case 'bala': g.fillStyle = '#1a1a20'; g.beginPath(); g.arc(x + w / 2, y + h / 2, w / 2, 0, 7); g.fill(); glow(185, x + w / 2, y + h / 2, 18, .4, 70); break;
      case 'agua': { const gr = g.createLinearGradient(0, y, 0, y + h); gr.addColorStop(0, 'rgba(200,255,250,.9)'); gr.addColorStop(1, 'rgba(40,120,140,.85)'); g.fillStyle = gr; g.beginPath(); g.moveTo(x, y + h); g.quadraticCurveTo(x + w * .2, y - 6 + Math.sin(t * 9) * 4, x + w, y + h * .2); g.lineTo(x + w, y + h); g.fill(); break; }
      case 'vapor':
        if (aviso) { g.fillStyle = 'rgba(220,220,230,' + (.25 + .2 * Math.sin(t * 20)) + ')'; for (let k = 0; k < 3; k++) { g.beginPath(); g.arc(x + w / 2 + (k - 1) * 12, FY * T - cam.y - 6 - k * 4, 8, 0, 7); g.fill(); } }
        else { const gr = g.createLinearGradient(0, y, 0, y + h); gr.addColorStop(0, 'rgba(230,230,240,0)'); gr.addColorStop(.3, 'rgba(230,230,240,.55)'); gr.addColorStop(1, 'rgba(255,255,255,.85)'); g.fillStyle = gr; g.fillRect(x + Math.sin(t * 30) * 2, y, w, h); }
        break;
      case 'engrenagem': g.save(); g.translate(x + w / 2, y + h / 2); g.rotate(t * 8 * Math.sign(q.vx || 1)); g.fillStyle = '#6a6a72'; g.beginPath(); g.arc(0, 0, 12, 0, 7); g.fill(); for (let k = 0; k < 8; k++) { g.rotate(Math.PI / 4); g.fillRect(-3, -17, 6, 7); } g.fillStyle = '#222'; g.beginPath(); g.arc(0, 0, 4, 0, 7); g.fill(); g.restore(); break;
      case 'feixe':
        if (aviso) { g.strokeStyle = 'rgba(255,60,60,' + (.4 + .3 * Math.sin(t * 25)) + ')'; g.lineWidth = 2; g.setLineDash && g.setLineDash([10, 8]); g.beginPath(); g.moveTo(x, y + h / 2); g.lineTo(x + w, y + h / 2); g.stroke(); g.setLineDash && g.setLineDash([]); }
        else { g.fillStyle = 'rgba(255,80,60,.35)'; g.fillRect(x, y - 6, w, h + 12); g.fillStyle = 'rgba(255,230,220,.95)'; g.fillRect(x, y + h * .3, w, h * .4); }
        break;
      case 'marca': g.strokeStyle = 'rgba(255,70,50,' + (.5 + .4 * Math.sin(t * 18)) + ')'; g.lineWidth = 3; g.beginPath(); g.moveTo(x, y - 6); g.lineTo(x + w, y + 6); g.moveTo(x + w, y - 6); g.lineTo(x, y + 6); g.stroke(); break;
      case 'bomba': if (aviso) break; g.fillStyle = '#2a2a24'; g.beginPath(); g.ellipse(x + w / 2, y + h / 2, w / 2, h / 2, 0, 0, 7); g.fill(); g.fillStyle = '#555'; g.fillRect(x + 4, y - 4, w - 8, 6); break;
      case 'explosao': glow(25, x + w / 2, y + h * .6, 60, .8 * (q.t / .32), 60); break;
    }
  }
}
