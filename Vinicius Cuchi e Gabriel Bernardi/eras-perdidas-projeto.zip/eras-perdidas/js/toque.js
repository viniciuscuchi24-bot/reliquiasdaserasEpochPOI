// ===== Controles de toque (celular), música e efeitos sonoros =====
(function(){
 const body=document.body,cvs=document.getElementById('c');
 const coarse=!!(window.matchMedia&&(matchMedia('(pointer:coarse)').matches||(navigator.maxTouchPoints>0&&matchMedia('(hover:none)').matches)));
 const relayout=()=>{if(window.ajustarTela)ajustarTela()};
 if(coarse)body.classList.add('touch');
 const tg=document.getElementById('tg');
 if(tg)tg.onclick=()=>{body.classList.toggle('touch');relayout()};
 addEventListener('touchstart',()=>{if(!body.classList.contains('touch')){body.classList.add('touch');relayout()}},{once:true,passive:true});
 relayout();
 document.addEventListener('contextmenu',e=>e.preventDefault());
 const press=c=>{K[c]=1;P[c]=1},release=c=>{K[c]=0};
 // --- botões redondos: cada dedo segura um botão
 const active=new Map();
 function up(e){
  const cur=active.get(e.pointerId);
  if(cur){release(cur.el.dataset.k);cur.el.classList.remove('on');active.delete(e.pointerId)}
 }
 document.querySelectorAll('.tb[data-k]').forEach(b=>{
  b.addEventListener('pointerdown',e=>{e.preventDefault();try{b.setPointerCapture(e.pointerId)}catch(_){}
   up(e);press(b.dataset.k);b.classList.add('on');active.set(e.pointerId,{el:b})});
  b.addEventListener('pointerup',up);b.addEventListener('pointercancel',up);b.addEventListener('lostpointercapture',up);
 });
 // --- joystick: esquerda/direita andam; para cima/baixo só mudam a direção do golpe (não atacam nem interagem)
 const stick=document.getElementById('stick'),knob=stick&&stick.querySelector('.knob');
 const dirs={KeyA:0,KeyD:0,StickUp:0,StickDown:0};let dedo=null,caixa=null,kx=0,ky=0,pedido=0;
 const liga=(c,on)=>{if(!!dirs[c]===on)return;dirs[c]=on?1:0;on?press(c):release(c)};
 // a bolinha é desenhada no máximo uma vez por quadro (o dedo manda muito mais eventos que isso)
 const pinta=()=>{pedido=0;knob.style.transform='translate3d('+kx.toFixed(1)+'px,'+ky.toFixed(1)+'px,0)'};
 function mexe(e){
  if(!caixa)caixa=stick.getBoundingClientRect();         // medido só quando o dedo encosta (medir a cada movimento força a página a recalcular)
  const R=caixa.width/2,m=R*.6;
  let dx=e.clientX-(caixa.left+R),dy=e.clientY-(caixa.top+R);const d=Math.hypot(dx,dy);if(d>m){dx*=m/d;dy*=m/d}
  kx=dx;ky=dy;if(!pedido)pedido=requestAnimationFrame(pinta);
  const nx=dx/m,ny=dy/m;
  const vert=Math.abs(ny)>Math.abs(nx)*1.2;           // cima/baixo só quando o dedo está bem na vertical
  liga('KeyA',nx<-.3);liga('KeyD',nx>.3);liga('StickUp',vert&&ny<-.55);liga('StickDown',vert&&ny>.55);
 }
 function solta(e){if(e&&e.pointerId!==dedo)return;dedo=null;caixa=null;kx=ky=0;if(knob&&!pedido)pedido=requestAnimationFrame(pinta);if(stick)stick.classList.remove('on');for(const c in dirs)liga(c,false)}
 if(stick&&knob){
  stick.addEventListener('pointerdown',e=>{e.preventDefault();dedo=e.pointerId;caixa=null;try{stick.setPointerCapture(dedo)}catch(_){}stick.classList.add('on');mexe(e)});
  stick.addEventListener('pointermove',e=>{if(e.pointerId===dedo)mexe(e)});
  ['pointerup','pointercancel','lostpointercapture'].forEach(t=>stick.addEventListener(t,solta));
 }
 window.addEventListener('blur',()=>{active.forEach(c=>{release(c.el.dataset.k);c.el.classList.remove('on')});active.clear();solta()});
 cvs.addEventListener('pointerdown',()=>{
  const m=G&&G.mode;
  if(m=='title'||m=='dialog')P.Enter=1;else if(m=='end')P.KeyR=1;else if(m=='map')P.KeyM=1;
 });
 const mus=new Audio(arquivo(CONFIG.audio.musica));mus.loop=true;mus.volume=1;mus.preload='auto';
 let muted=false,started=false;
 function startMusic(){if(started||muted)return;const pr=mus.play();if(pr&&pr.then)pr.then(()=>{started=true}).catch(()=>{})}
 ['pointerdown','keydown','touchstart'].forEach(t=>addEventListener(t,startMusic,{passive:true}));
 window.toggleMusic=()=>{muted=!muted;if(muted){mus.pause();started=false}else startMusic();if(window.toast)toast(muted?'Música desligada':'Música ligada',1.5)};
 window.__mus=mus;
 // troca de música ao mudar de fase (se houver música própria em CONFIG.audio.musicasPorFase)
 let faixa=CONFIG.audio.musica;
 setInterval(()=>{
  if(typeof G=='undefined'||!G||!G.rm)return;
  const lista=CONFIG.audio.musicasPorFase||{},quer=lista[G.ri+1]||CONFIG.audio.musica;
  if(quer===faixa)return;faixa=quer;const tocava=!mus.paused;mus.src=arquivo(quer);mus.load();
  if(tocava&&!muted){const pr=mus.play();if(pr&&pr.catch)pr.catch(()=>{})}
 },600);
 const SF={j:new Audio(arquivo(CONFIG.audio.pulo)),d:new Audio(arquivo(CONFIG.audio.esquiva))};
 for(const k in SF){SF[k].preload='auto';SF[k].volume=k=='j'?.7:.8}
 // corte e acerto: sons feitos na hora (ruído filtrado), sem arquivo
 let AC=null;const sint=k=>{try{AC=AC||new (window.AudioContext||window.webkitAudioContext)();const t=AC.currentTime,d=k=='corte'?.16:.12,n=Math.floor(AC.sampleRate*d),buf=AC.createBuffer(1,n,AC.sampleRate),x=buf.getChannelData(0);for(let i=0;i<n;i++){const u=i/n;x[i]=(Math.random()*2-1)*(k=='corte'?Math.sin(u*Math.PI):Math.pow(1-u,3))}
  const src=AC.createBufferSource();src.buffer=buf;const f=AC.createBiquadFilter();f.type=k=='corte'?'bandpass':'lowpass';f.Q.value=k=='corte'?1.4:.8;f.frequency.setValueAtTime(k=='corte'?900:1400,t);f.frequency.exponentialRampToValueAtTime(k=='corte'?3400:220,t+d);
  const gn=AC.createGain();gn.gain.value=k=='corte'?.22:.5;src.connect(f);f.connect(gn);gn.connect(AC.destination);src.start(t)}catch(_){}};
 window.sfx=k=>{if(k=='corte'||k=='acerto')return sint(k);try{const a=SF[k].cloneNode();a.volume=SF[k].volume;const pr=a.play();if(pr&&pr.catch)pr.catch(()=>{})}catch(_){}};
})();
