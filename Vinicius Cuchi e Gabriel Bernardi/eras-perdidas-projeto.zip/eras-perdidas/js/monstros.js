// ===== Monstros =====
// Desenha os inimigos comuns a partir das folhas de sprite de assets/monstros (manifesto em monstros.js).
// Escolhe a animação pelo que o inimigo está fazendo: parado, andando, atacando, levando dano ou morrendo.

function animacaoMonstro(e, M) {
  const cx = e.x + e.w / 2, dx = p.x + p.w / 2 - cx, dy = p.y + p.h / 2 - (e.y + e.h / 2);
  const perto = Math.abs(dx) < 64 + e.w / 2 && Math.abs(dy) < 70;
  let olha = e.k == 'w' ? (e.vx + e.kx * .2 >= 0 ? 1 : -1) : (dx >= 0 ? 1 : -1);
  if (e.dead) return { nome: 'morte', t: G.time - e.morte, laco: false, olha: e.olha || olha };
  e.olha = olha;
  if (e.dano > 0) return { nome: 'dano', t: .3 - e.dano, laco: false, olha };
  if (e.k == 'w') return { nome: perto ? 'ataque' : 'andar', t: G.time + e.ph, laco: true, olha };
  if (e.k == 'h') {
    if (e.salto != null && G.time - e.salto < .7) return { nome: 'ataque', t: G.time - e.salto, laco: false, olha };
    if (perto) return { nome: 'ataque', t: G.time + e.ph, laco: true, olha };
    return { nome: Math.abs(e.vx) > 30 ? 'andar' : 'parado', t: G.time + e.ph, laco: true, olha };
  }
  const longe = Math.hypot(dx, dy) > 320;   // o voador só persegue quando o jogador está perto
  return { nome: perto ? 'ataque' : longe ? 'parado' : 'andar', t: G.time + e.ph, laco: true, olha };
}

// devolve false se a imagem ainda não carregou (aí o jogo usa o desenho simples)
function desenharMonstro(e) {
  if (e.arte && typeof desenharArteAjudante == 'function' && desenharArteAjudante(e)) return true;
  const M = MONSTROS && MONSTROS[e.k]; if (!M) return false;
  const a = animacaoMonstro(e, M), info = M.anim[a.nome];
  const im = carregarImagem(MONSTROS.pasta + M.pasta + info[0]);
  if (!imagemPronta(im)) return false;
  const n = info[1]; let q = Math.floor(a.t * info[2]);
  if (a.laco) q = ((q % n) + n) % n;
  else if (q >= n) { if (a.nome == 'morte') return true; q = n - 1; }
  const [fw, fh] = M.quadro, esc = M.escala;
  const cx = Math.round(e.x + e.w / 2 - cam.x), base = Math.round(e.y + e.h - cam.y);
  if (cx < -120 || cx > VW + 120) return true;
  if (M.flutua && !e.dead) glow(M.brilho == null ? 205 : M.brilho, cx, base + 4, 34, .22 + .06 * Math.sin(G.time * 3 + e.ph), 70);
  g.save(); g.translate(cx, base);
  if ((a.olha > 0) != M.direita) g.scale(-1, 1);
  g.imageSmoothingEnabled = false;
  const sx = q * fw, dw = Math.round(fw * esc), dh = Math.round(fh * esc), ox = -Math.round(M.centro * esc), oy = -Math.round(M.pe * esc);
  g.drawImage(im, sx, 0, fw, fh, ox, oy, dw, dh);
  if (e.fl > 0 && !e.dead) { g.globalCompositeOperation = 'lighter'; g.globalAlpha = .75; g.drawImage(im, sx, 0, fw, fh, ox, oy, dw, dh); }
  g.restore();
  return true;
}

// tempo da animação de morte (para o desenho continuar depois do golpe final)
function duracaoMorte(e) {
  if (e.arte) return .5;
  const M = MONSTROS && MONSTROS[e.k]; if (!M) return 0;
  const a = M.anim.morte; return a[1] / a[2];
}
