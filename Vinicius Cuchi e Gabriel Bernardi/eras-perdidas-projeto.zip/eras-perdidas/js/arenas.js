// ===== Arenas dos chefes =====
// Cada chefe luta num cenário próprio, em pixel art que combina com o resto do jogo:
//   legionario -> ruínas de um Coliseu (arcos de pedra, colunas, estandartes, sacadas de mármore)
//   espectro   -> um navio atracado no cais (casco, convés, mastros, velas rasgadas, cordas e o mar)
//   colosso    -> uma fábrica a vapor (tijolos, janelões, engrenagens, canos, fornalhas, correntes)
//   enigma     -> uma casamata da 2ª Guerra (concreto, seteiras, sacos de areia, holofote, alarmes)
//
// Como a arena se mistura com o jogo:
//   * o chão continua sendo o do estilo (só o navio troca o chão pelo casco, depois do cais);
//   * tudo é pintado numa tela com metade do tamanho e ampliado 2x sem suavizar (pixels de 2 px);
//   * cada camada recebe o tom e o escurecimento do estilo atual e um grão de textura;
//   * na entrada, a arena aparece aos poucos com um pontilhado (dither), sem corte seco;
//   * as camadas de fundo do estilo (cipós, cogumelos, colinas) continuam por cima nas arenas ao ar livre.
// A geometria (plataformas, mastros, casco) está em js/trechos.js, no trecho 'chefe'.

// ---------------------------------------------------------------- utilidades de pixel (2 px)
const px = (x, y, w, h, cor) => {
  g.fillStyle = cor;
  g.fillRect(Math.round(x / 2) * 2, Math.round(y / 2) * 2, Math.max(2, Math.round(w / 2) * 2), Math.max(2, Math.round(h / 2) * 2));
};
const hx = (a, b) => hh(a * 12.9898 + b * 78.233 + 0.5);                     // ruído fixo 0..1
function linha(x0, y0, x1, y1, cor, esp) {                                      // linha de pixels
  const n = Math.max(1, Math.ceil(Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0)) / 2));
  for (let k = 0; k <= n; k++) px(x0 + (x1 - x0) * k / n, y0 + (y1 - y0) * k / n, esp || 2, esp || 2, cor);
}
function corda(x0, y0, x1, y1, flecha, cor) {                                   // corda caída (curva)
  const n = Math.max(2, Math.ceil(Math.hypot(x1 - x0, y1 - y0) / 2));
  for (let k = 0; k <= n; k++) { const u = k / n; px(x0 + (x1 - x0) * u, y0 + (y1 - y0) * u + Math.sin(u * Math.PI) * flecha, 2, 2, cor); }
}
function disco(cx, cy, r, cor) {
  for (let y = -r; y <= r; y += 2) { const w = Math.sqrt(Math.max(0, r * r - y * y)); px(cx - w, cy + y, w * 2, 2, cor); }
}
function aberturaArco(x, y, w, h, cor) {                                        // vão com topo em arco
  const r = w / 2;
  for (let yy = 0; yy < h; yy += 2) {
    const d = yy < r ? Math.sqrt(Math.max(0, r * r - (r - yy) * (r - yy))) : r;
    px(x + r - d, y + yy, d * 2, 2, cor);
  }
}
function ret(x, y, w, h, base, luz, sombra) {                                   // bloco com luz e sombra
  px(x, y, w, h, base); if (luz) { px(x, y, w, 2, luz); px(x, y, 2, h, luz); }
  if (sombra) { px(x, y + h - 2, w, 2, sombra); px(x + w - 2, y, 2, h, sombra); }
}
function pontilhado(x, y, w, h, cor, passo) {                                   // pontilhado (sombra suave em pixel art)
  const nivel = { 2: 8, 4: 4, 6: 3, 8: 2 }[passo || 4] || 4;
  const L = ladrilho('pt_' + cor + '_' + nivel, 4, 4, (c) => { c.fillStyle = cor; for (let k = 0; k < 16; k++) if (BAYER[k] < nivel) c.fillRect(k % 4, k >> 2, 1, 1); });
  if (L) preencherLadrilho(L, x, y, w, h, cam.x, cam.y);
  else for (let yy = 0; yy < h; yy += 2) for (let xx = ((yy / 2) % 2) * 2; xx < w; xx += passo || 4) px(x + xx, y + yy, 2, 2, cor);
}
function brilhoArena(x, y, r, rgb, a) {
  const gr = g.createRadialGradient(x, y, 2, x, y, r);
  gr.addColorStop(0, 'rgba(' + rgb + ',' + a + ')'); gr.addColorStop(1, 'rgba(' + rgb + ',0)');
  g.fillStyle = gr; g.fillRect(x - r, y - r, 2 * r, 2 * r);
}
// posição na tela de algo do fundo com parallax (P = 0 parado, 1 anda com o chão)
const comParallax = (P, X) => (X - cam.x) * P + VW * (1 - P) / 2;

// ---------------------------------------------------------------- a tela da arena e a mistura
const ARENA_TOM = {   // tom de cada estilo por camada (fundo, meio = construções, piso = casco e plataformas)
  pantano:   { fundo: 'rgba(64,58,96,.42)', meio: 'rgba(48,40,78,.28)', piso: 'rgba(40,32,64,.18)' },
  cemiterio: { fundo: 'rgba(10,18,46,.56)', meio: 'rgba(10,18,46,.40)', piso: 'rgba(10,18,46,.30)' }
};
const tomArena = k => (ARENA_TOM[EST.id] || ARENA_TOM.pantano)[k];
const BAYER = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5];
let ARENA = null;   // { cv, x, mascara, mx, padroes[], grao, ladrilhos{} } ou false (sem tela extra, ex.: testes)
function telaArena() {
  if (ARENA !== null) return ARENA;
  try {
    const nova = (w, h) => { const c = document.createElement('canvas'); c.width = w; c.height = h; const x = c.getContext('2d'); if (!x || !x.drawImage || !x.createPattern) throw 0; x.imageSmoothingEnabled = false; return [c, x]; };
    const [cv, x] = nova(VW / 2, VH / 2);
    const padroes = [];
    for (let n = 0; n <= 16; n++) {
      const [p, pc] = nova(4, 4); pc.fillStyle = '#000';
      for (let k = 0; k < 16; k++) if (BAYER[k] < n) pc.fillRect(k % 4, k >> 2, 1, 1);
      padroes.push(x.createPattern(p, 'repeat'));
    }
    const [gr, gc] = nova(64, 64), rnd = mul(77);
    for (let yy = 0; yy < 64; yy++) for (let xx = 0; xx < 64; xx++) {
      const v = rnd();
      if (v < .14) { gc.fillStyle = 'rgba(0,0,0,' + (.14 + v) + ')'; gc.fillRect(xx, yy, 1, 1); }
      else if (v > .95) { gc.fillStyle = 'rgba(255,255,255,.08)'; gc.fillRect(xx, yy, 1, 1); }
    }
    ARENA = { cv, x, padroes, grao: x.createPattern(gr, 'repeat'), nova, ladrilhos: {}, guardadas: {} };
  } catch (e) { ARENA = false; }
  return ARENA;
}
// ladrilho guardado (desenhado uma vez, em pixels da tela pequena) e repetido como padrão
function ladrilho(nome, w, h, desenhar) {
  const A = telaArena(); if (!A) return null;
  if (!A.ladrilhos[nome]) { const [c, x] = A.nova(w, h); desenhar(x, w, h); A.ladrilhos[nome] = { c, p: A.x.createPattern(c, 'repeat') }; }
  return A.ladrilhos[nome];
}
// quando a arena é pintada em pedaços numa tela guardada, DESLOC diz onde fica o pedaço (px da tela pequena)
let DESLOC = 0;
// preenche um retângulo (coords da tela cheia) com um ladrilho, deslocado por (ox, oy) px da tela cheia
function preencherLadrilho(L, x, y, w, h, ox, oy) {
  if (!L) return;
  g.save(); g.setTransform(1, 0, 0, 1, DESLOC, 0);
  const dx = pmod(Math.round(ox / 2), L.c.width), dy = pmod(Math.round(oy / 2), L.c.height);
  g.translate(-dx, -dy); g.fillStyle = L.p; g.fillRect(Math.round(x / 2) + dx, Math.round(y / 2) + dy, Math.ceil(w / 2), Math.ceil(h / 2));
  g.restore();
}
// apaga (deixa ver o que está atrás) — usado em janelas e vãos do fundo
function furo(desenhar) { const op = g.globalCompositeOperation; g.globalCompositeOperation = 'destination-out'; desenhar(); g.globalCompositeOperation = op; }

// Pinta uma camada: 'pintar' desenha com g em coordenadas da tela cheia.
// tom = cor por cima (source-atop); passagem = [ini, fim] em px do mundo: antes de ini nada, depois de fim tudo,
// e no meio um pontilhado que vai enchendo.
function camadaArena(tom, escurecer, passagem, pintar) {
  const A = telaArena();
  if (!A) {   // sem tela extra (testes no Node): desenha direto
    const ini = passagem ? (passagem[0] + passagem[1]) / 2 - cam.x : -100;
    g.save(); g.beginPath(); g.rect(ini, -100, VW * 8, VH + 200); g.clip(); pintar(); g.restore(); return;
  }
  const W = VW / 2, H = VH / 2, lo = A.x, tela = g;
  lo.setTransform(1, 0, 0, 1, 0, 0); lo.globalCompositeOperation = 'source-over'; lo.globalAlpha = 1; lo.clearRect(0, 0, W, H);
  lo.setTransform(.5, 0, 0, .5, 0, 0); lo.imageSmoothingEnabled = false;
  g = lo; try { pintar(); } finally { g = tela; }
  lo.setTransform(1, 0, 0, 1, 0, 0); lo.globalAlpha = 1;
  lo.globalCompositeOperation = 'source-atop';
  lo.fillStyle = tom; lo.fillRect(0, 0, W, H);
  if (escurecer) {
    const e = EST.escurecer || [0, 0, 0], gr = lo.createLinearGradient(0, 0, 0, H);
    gr.addColorStop(0, 'rgba(4,5,10,' + e[0] + ')'); gr.addColorStop(.6, 'rgba(4,5,10,' + e[1] + ')'); gr.addColorStop(1, 'rgba(4,5,10,' + e[2] + ')');
    lo.fillStyle = gr; lo.fillRect(0, 0, W, H);
  }
  const ox = pmod(Math.round(cam.x / 2), 64), oy = pmod(Math.round(cam.y / 2), 64);
  lo.save(); lo.translate(-ox, -oy); lo.fillStyle = A.grao; lo.fillRect(0, 0, W + 64, H + 64); lo.restore();
  if (passagem && passagem[1] - cam.x > -8) {   // entrada na tela: apaga o que fica antes dela, com pontilhado
    const [ini, fim] = passagem, dx = pmod(Math.round(cam.x / 2), 4), xl = wm => Math.round((wm - cam.x) / 2);
    lo.globalCompositeOperation = 'destination-out'; lo.fillStyle = '#000';
    if (xl(ini) > 0) lo.fillRect(0, 0, xl(ini), H);
    lo.save(); lo.translate(-dx, 0);
    for (let wm = Math.floor(Math.max(ini, cam.x - 16) / 8) * 8; wm < Math.min(fim, cam.x + VW + 16); wm += 8) {
      let u = clamp((wm + 4 - ini) / (fim - ini), 0, 1); u = u * u * (3 - 2 * u);
      const n = 16 - Math.round(u * 16); if (!n) continue;
      lo.fillStyle = A.padroes[n]; lo.fillRect(xl(wm) + dx, 0, 4, H);
    }
    lo.restore();
  }
  lo.globalCompositeOperation = 'source-over';
  g.save(); g.imageSmoothingEnabled = false; g.drawImage(A.cv, 0, 0, W, H, 0, 0, VW, VH); g.restore();
}

// O que não se mexe é pintado uma vez numa tela comprida (por fase) e depois só copiado.
// P = parallax da camada (1 = anda com o chão). A tela cobre todas as posições da câmera perto da arena.
function guardada(s, nome, P, pintar) {
  const A = telaArena(); if (!A) { pintar(s); return; }
  const R = G.rm, chave = nome + '_' + R.i;
  let C = A.guardadas[chave];
  if (!C) {
    const camMin = Math.max(0, (s.x0 - 10) * T - VW), camMax = Math.max(camMin, R.W * T - VW);
    const larg = Math.ceil(((camMax - camMin) * P + VW) / 2) + 8, alt = Math.ceil(RH * T / 2) + 4;
    const [cv, x] = A.nova(larg, alt), salvo = [cam.x, cam.y, DESLOC], tela = g;
    for (let k = 0; k * VW / 2 < larg; k++) {
      cam.x = camMin + k * VW / P; cam.y = 0; DESLOC = k * VW / 2;
      x.setTransform(.5, 0, 0, .5, DESLOC, 0); g = x;
      try { pintar(s); } finally { g = tela; }
    }
    [cam.x, cam.y, DESLOC] = salvo;
    C = A.guardadas[chave] = { cv, camMin, P };
  }
  const sx = Math.round((cam.x - C.camMin) * C.P / 2), sy = Math.round(cam.y / 2);
  g.save(); g.setTransform(1, 0, 0, 1, 0, 0); g.drawImage(C.cv, sx, sy, VW / 2, VH / 2, 0, 0, VW / 2, VH / 2); g.restore();
}
function esquecerArenas() { const A = telaArena(); if (A) A.guardadas = {}; }

// ---------------------------------------------------------------- ligação com o resto do jogo
function arenaDaSala() {
  const R = G.rm; if (!R || !R.boss) return null;
  return R.secs.find(s => s.arena) || null;
}
const dentroDaArena = (s, xMundo) => xMundo >= s.x0 * T && xMundo < s.x1 * T;
const passagemFundo = s => [(s.x0 - 8) * T, (s.x0 + 1) * T];
const passagemMeio = s => [(s.x0 - 3) * T, (s.x0 + 1) * T];
const arenaNaTela = s => (s.x0 - 9) * T - cam.x < VW + 40 && G.rm.W * T - cam.x > -40;

// fundo: chamado duas vezes em drawBG (antes das camadas do estilo = arena ao ar livre; depois = arena coberta)
function desenharArenaFundo(depoisDasCamadas) {
  const s = arenaDaSala(); if (!s || !arenaNaTela(s)) return; const A = ARENAS[s.arena]; if (!A || !(A.fundoFixo || A.fundoVivo)) return;
  if (!!A.coberta != !!depoisDasCamadas) return;
  camadaArena(tomArena('fundo'), true, passagemFundo(s), () => { if (A.fundoFixo) guardada(s, s.arena + '_fundo', A.P || 1, A.fundoFixo); if (A.fundoVivo) A.fundoVivo(s); });
}
// construções do meio (colunas, mastros, fornalhas...) — atrás do terreno, como os objetos do estilo
function desenharArenaMeio() {
  const s = arenaDaSala(); if (!s || !arenaNaTela(s)) return; const A = ARENAS[s.arena]; if (!A) return;
  // numa passada só: o que não se mexe (casco, construções, plataformas) vem da tela guardada; depois o que se mexe
  camadaArena(tomArena('meio'), false, passagemMeio(s), () => {
    guardada(s, s.arena + '_meio', 1, () => {
      if (A.casco && s.casco) A.casco(s);
      if (A.meioFixo) A.meioFixo(s);
      if (A.plataforma) for (const r of G.rm.sol) if (r[4] && dentroDaArena(s, r[0] + 1) && r[0] + r[2] - cam.x > -60 && r[0] - cam.x < VW + 60) A.plataforma(r[0] - cam.x, r[1] - cam.y, r[2], r[3], s);
    });
    if (A.meioVivo) A.meioVivo(s);
  });
  if (A.luzes) A.luzes(s);   // luzes por cima, sem tom (lanternas, fogo, alarmes)
}
// chão: o navio troca o chão do estilo pelo casco; nas outras arenas o chão do estilo continua
function desenharChaoArena(r, x, y, w, h, sem, esq, dir) {
  const s = arenaDaSala(); const A = s && ARENAS[s.arena];
  if (!A || !A.casco || !s.casco) return false;
  const c0 = s.casco[0] * T, c1 = s.casco[1] * T, r0 = r[0], r1 = r[0] + r[2];
  if (r1 <= c0 || r0 >= c1) return false;
  if (r0 < c0) desenharChao(r0 - cam.x, y, c0 - r0, h, sem, esq, true);          // cais antes do navio
  if (r1 > c1) desenharChao(c1 - cam.x, y, r1 - c1, h, sem, true, dir);          // cais depois do navio
  return true;
}
function desenharBlocoArena(r, x, y, w, h) {
  const s = arenaDaSala(); const A = s && ARENAS[s.arena];
  return !!(A && A.casco && s.casco && r[0] >= s.casco[0] * T && r[0] + r[2] <= s.casco[1] * T);   // castelos do navio: o casco desenha
}
function desenharArenaPiso() { }   // (o casco e as plataformas saem junto com o meio, em desenharArenaMeio)
const ehPlataformaDaArena = r => { const s = arenaDaSala(); return !!(s && ARENAS[s.arena] && ARENAS[s.arena].plataforma && dentroDaArena(s, r[0] + 1)); };
function desenharArenaFrente() {
  const s = arenaDaSala(); if (!s || !arenaNaTela(s)) return; const A = ARENAS[s.arena]; if (!A || !A.frente) return;
  A.frente(s);
}

// ---------------------------------------------------------------- ladrilhos de textura (pixels da tela pequena)
function texturaPedra(x, w, h) {          // blocos de pedra do Coliseu (travertino)
  const tons = ['#a08a6a', '#968062', '#aa9474', '#8c7658'];
  x.fillStyle = '#5c4a36'; x.fillRect(0, 0, w, h);
  for (let fila = 0; fila < h / 8; fila++) {
    let bx = fila % 2 ? -6 : 0;
    while (bx < w) {
      const bw = 12 + Math.floor(hx(fila, bx) * 3) * 2, c = tons[Math.floor(hx(bx, fila + 7) * 4)];
      x.fillStyle = c; x.fillRect(bx + 1, fila * 8 + 1, bw - 1, 7);
      x.fillStyle = '#baa482'; x.fillRect(bx + 1, fila * 8 + 1, bw - 1, 1);
      x.fillStyle = '#76624a'; x.fillRect(bx + 1, fila * 8 + 7, bw - 1, 1);
      for (let k = 0; k < 3; k++) { const sx = bx + 2 + Math.floor(hx(bx + k, fila * 3) * (bw - 4)), sy = fila * 8 + 2 + Math.floor(hx(fila + k, bx * 2) * 4); x.fillStyle = hx(k, bx + fila) < .5 ? '#7c684e' : '#b29c7a'; x.fillRect(sx, sy, 1, 1); }
      bx += bw;
    }
  }
}
function texturaTijolo(x, w, h) {         // tijolos de fábrica com fuligem
  const tons = ['#5e3426', '#54301f', '#68392a', '#4c2a1e', '#5a3a2c'];
  x.fillStyle = '#26160f'; x.fillRect(0, 0, w, h);
  for (let fila = 0; fila < h / 6; fila++) for (let k = -1; k < w / 16 + 1; k++) {
    const bx = k * 16 + (fila % 2) * 8, c = tons[Math.floor(hx(k + 3, fila) * tons.length)];
    x.fillStyle = c; x.fillRect(bx + 1, fila * 6 + 1, 15, 5);
    x.fillStyle = 'rgba(255,190,150,.12)'; x.fillRect(bx + 1, fila * 6 + 1, 15, 1);
    x.fillStyle = 'rgba(0,0,0,.25)'; x.fillRect(bx + 1, fila * 6 + 5, 15, 1);
    if (hx(k, fila + 11) < .18) { x.fillStyle = '#3c2218'; x.fillRect(bx + 3 + Math.floor(hx(k, fila) * 9), fila * 6 + 2, 2, 2); }
  }
}
function texturaConcreto(x, w, h) {       // placas de concreto com marcas da forma de madeira
  x.fillStyle = '#6c6c64'; x.fillRect(0, 0, w, h);
  for (let yy = 0; yy < h; yy++) for (let xx = 0; xx < w; xx++) {
    const v = hx(xx * 1.3, yy * 0.7);
    if (v < .1) { x.fillStyle = '#5c5c56'; x.fillRect(xx, yy, 1, 1); } else if (v > .94) { x.fillStyle = '#6a6a62'; x.fillRect(xx, yy, 1, 1); }
  }
  x.fillStyle = 'rgba(0,0,0,.18)'; for (let yy = 7; yy < h; yy += 8) x.fillRect(0, yy, w, 1);
  x.fillStyle = '#3e3e3a'; x.fillRect(0, 0, 1, h); x.fillRect(0, 0, w, 1);
  x.fillStyle = '#6e6e66'; x.fillRect(1, 1, w - 1, 1);
  x.fillStyle = '#44443e'; for (const [cx, cy] of [[6, 6], [w - 7, 6], [6, h - 7], [w - 7, h - 7]]) x.fillRect(cx, cy, 2, 2);
  x.fillStyle = 'rgba(30,26,20,.35)'; for (let k = 0; k < 3; k++) { const sx = 10 + Math.floor(hx(k, 4) * (w - 20)); x.fillRect(sx, 1, 2, 12 + Math.floor(hx(4, k) * 20)); }
}
function texturaCasco(x, w, h) {          // tábuas do casco do navio
  const tons = ['#5e3a1c', '#6a4220', '#563418', '#704822'];
  for (let fila = 0; fila < h / 6; fila++) {
    x.fillStyle = tons[fila % tons.length]; x.fillRect(0, fila * 6, w, 6);
    x.fillStyle = '#2e1a0a'; x.fillRect(0, fila * 6 + 5, w, 1);
    x.fillStyle = 'rgba(255,210,150,.10)'; x.fillRect(0, fila * 6, w, 1);
    const off = (fila * 37) % w; x.fillStyle = '#2e1a0a'; x.fillRect(off, fila * 6, 1, 5); x.fillRect((off + w / 2) % w, fila * 6, 1, 5);
    x.fillStyle = '#c8a060'; x.fillRect((off + 3) % w, fila * 6 + 2, 1, 1); x.fillRect((off + w / 2 + 3) % w, fila * 6 + 2, 1, 1);
    for (let k = 0; k < 4; k++) { x.fillStyle = 'rgba(30,16,6,.35)'; x.fillRect(Math.floor(hx(fila, k) * w), fila * 6 + 1 + (k % 3), 3 + k, 1); }
  }
}

// ---------------------------------------------------------------- engrenagens em pixel art (girando aos saltos)
function engrenagemSprite(r, passo) {
  const A = telaArena(); if (!A) return null;
  const chave = 'eng' + r + '_' + passo; if (A.ladrilhos[chave]) return A.ladrilhos[chave];
  const n = (r + 6) * 2 + 2, [c, x] = A.nova(n, n), dentes = Math.max(8, Math.round(r / 4.5)), ang0 = passo * (Math.PI * 2 / dentes) / 4;
  const img = x.createImageData(n, n), d8 = img.data;
  const rgb = h => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
  const C = { aro: rgb('#6a5a4a'), aro2: rgb('#54483c'), corpo: rgb('#463c32'), sulco: rgb('#2a2420'), raio: rgb('#4e4438'), eixo: rgb('#7a6a56'), luz: rgb('#8a7a64'), furo: rgb('#16120e') };
  for (let yy = 0; yy < n; yy++) for (let xx = 0; xx < n; xx++) {
    const dx = xx - n / 2 + .5, dy = yy - n / 2 + .5, d = Math.hypot(dx, dy), a = Math.atan2(dy, dx) - ang0;
    const dente = Math.cos(a * dentes) > .1;
    if (d > r + (dente ? 5 : 0) || d < r * .14) continue;
    let cor;
    if (d > r - 2) cor = dente ? C.aro : C.aro2;
    else if (d > r * .62) cor = C.corpo;
    else if (d > r * .55) cor = C.sulco;
    else cor = Math.abs(Math.sin(a * 3)) < .22 ? C.raio : null;
    if (d < r * .26) cor = C.eixo;
    if (d < r * .14 + 1) cor = C.furo;
    if (!cor) continue;
    if (dx + dy < -d * .6 && d > r * .5) cor = C.luz;
    const i = (yy * n + xx) * 4; d8[i] = cor[0]; d8[i + 1] = cor[1]; d8[i + 2] = cor[2]; d8[i + 3] = 255;
  }
  x.putImageData(img, 0, 0);
  return (A.ladrilhos[chave] = { c });
}
function desenharEngrenagem(cx, cy, r, vel) {
  const passo = pmod(Math.floor(G.time * vel * 6), 4), sp = engrenagemSprite(Math.round(r / 2), passo); if (!sp) return;
  g.save(); g.setTransform(1, 0, 0, 1, DESLOC, 0); g.drawImage(sp.c, Math.round(cx / 2 - sp.c.width / 2), Math.round(cy / 2 - sp.c.height / 2)); g.restore();
}

// ---------------------------------------------------------------- peças reutilizadas
function chamas(x, y, w, h, t, sem) {     // fogo em pixel art (colunas que sobem e descem)
  for (let k = 0; k < w; k += 2) {
    const v = Math.sin(t * 9 + k * .45 + sem) * .5 + Math.sin(t * 13 + k * .9) * .3 + hx(k, sem) * .4;
    const hh2 = Math.max(4, Math.round(h * (.45 + v * .5) * (1 - Math.abs(k / w - .5) * .9) / 2) * 2);
    px(x + k, y - hh2, 2, hh2, '#c8401a'); px(x + k, y - hh2 * .75, 2, hh2 * .75, '#ff7a1a'); px(x + k, y - hh2 * .45, 2, hh2 * .45, '#ffc244');
    if (hh2 > h * .5) px(x + k, y - hh2 * .25, 2, hh2 * .25, '#fff2a8');
  }
}
function barril(x, y, sem) {              // x = centro, y = chão
  ret(x - 12, y - 30, 24, 30, '#7a4a22', '#9a6430', '#4e2e14');
  px(x - 12, y - 30, 4, 30, '#5e3818'); px(x + 4, y - 30, 2, 30, '#8e5a2a');
  for (const yy of [y - 26, y - 8]) { px(x - 13, yy, 26, 4, '#3a3a40'); px(x - 13, yy, 26, 2, '#6a6a74'); }
  px(x - 10, y - 32, 20, 2, '#a06a36');
}
function caixote(x, y, w, h, faixa) {     // x = esquerda, y = chão
  ret(x, y - h, w, h, '#7a5428', '#9a6c34', '#4a3218');
  px(x + 2, y - h + 2, w - 4, 2, '#5a3c1c'); px(x + 2, y - 4, w - 4, 2, '#5a3c1c');
  linha(x + 4, y - 6, x + w - 6, y - h + 4, '#5a3c1c');
  if (faixa) for (let k = 0; k < w - 8; k += 8) { px(x + 4 + k, y - h / 2 - 3, 4, 6, '#d8b028'); px(x + 8 + k, y - h / 2 - 3, 4, 6, '#1a1a1e'); }
}
function sacoDeAreia(x, y) {
  px(x + 2, y, 24, 12, '#9a845a'); px(x, y + 2, 28, 8, '#9a845a');
  px(x + 2, y, 22, 2, '#bca476'); px(x + 2, y + 10, 24, 2, '#6a5a3a'); px(x + 26, y + 2, 2, 8, '#6a5a3a');
  px(x + 12, y + 2, 2, 8, '#7e6c48'); pontilhado(x + 4, y + 4, 20, 4, '#8a7650', 6);
}

// ======================================================================================
const ARENAS = {
  // ====================================================================================
  //  COLISEU — Legionário de Pedra
  // ====================================================================================
  legionario: {
    P: .55,
    fundoFixo(s) {
      const yc = FY * T - cam.y, P = .55, MOD = 112, topo = yc - 320;
      const ox = comParallax(P, s.x0 * T);
      const pedra = ladrilho('pedra', 48, 32, texturaPedra);
      const ini = Math.floor((-ox - MOD) / MOD), fim = Math.ceil((VW - ox + MOD) / MOD);
      // parede dos dois andares, com o topo em ruínas (altura muda aos poucos, com pedras soltas)
      for (let k = ini; k <= fim; k++) {
        const x = ox + k * MOD, ruina = Math.floor(hx(k, 3) * 4) * 16 + (hx(k, 9) < .2 ? 120 : 0);
        preencherLadrilho(pedra, x, topo + ruina, MOD, yc - topo - ruina, -ox, 0);
        let alt = Math.floor(hx(k, 21) * 4) * 4;
        for (let q = 0; q < MOD; q += 4) {
          alt = clamp(alt + (hx(k * 53 + q, 7) < .5 ? -4 : 4) * (hx(q, k * 3) < .45 ? 1 : 0), 0, 28);
          if (alt) { px(x + q, topo + ruina - alt, 4, alt + 2, '#9a8464'); px(x + q, topo + ruina - alt, 4, 2, '#b8a07e'); }
          if (hx(q, k + 40) < .06) px(x + q, topo + ruina - alt - 4, 4, 4, '#8c7658');
        }
      }
      const andar1 = yc - 150, andar2 = yc - 290;
      for (let k = ini; k <= fim; k++) {
        const x = ox + k * MOD, ruina = Math.floor(hx(k, 3) * 4) * 16 + (hx(k, 9) < .2 ? 120 : 0);
        // vãos de baixo (escuros, com fundo da galeria)
        aberturaArco(x + 26, andar1 + 26, 60, yc - andar1 - 26, '#3a2c1e');
        aberturaArco(x + 30, andar1 + 32, 52, yc - andar1 - 32, '#2a1e14');
        pontilhado(x + 30, yc - 40, 52, 40, '#3e3022', 4);
        // vãos de cima: abertos (vê-se o céu da época por eles)
        if (andar2 + 26 > topo + ruina) furo(() => aberturaArco(x + 30, andar2 + 30, 52, andar1 - andar2 - 46, '#000'));
        else aberturaArco(x + 30, Math.max(andar2 + 30, topo + ruina + 6), 52, andar1 - Math.max(andar2 + 30, topo + ruina + 6) - 16, '#2e2218');
        // aduelas (pedras do arco) mais claras
        for (const [ay, aw] of [[andar1 + 26, 60], [andar2 + 26, 60]]) {
          if (ay < topo + ruina) continue;
          const r = aw / 2, cx = x + 26 + r;
          for (let a = Math.PI; a <= Math.PI * 2 + .01; a += .22) px(cx + Math.cos(a) * (r + 1), ay + r + Math.sin(a) * (r + 1), 4, 4, '#b8a27e');
        }
        // meia-coluna entre os arcos (luz à esquerda, sombra à direita)
        for (const [y0, y1] of [[andar1 + 12, yc], [Math.max(andar2 + 12, topo + ruina), andar1]]) {
          if (y1 - y0 < 20) continue;
          const cx = x + 4; px(cx, y0, 14, y1 - y0, '#a89070'); px(cx, y0, 4, y1 - y0, '#c4ae8a'); px(cx + 10, y0, 4, y1 - y0, '#7a664c');
          px(cx - 4, y0, 22, 6, '#c4ae8a'); px(cx - 4, y0 + 6, 22, 2, '#6e5a42');
          for (let yy = y0 + 14; yy < y1 - 4; yy += 6) px(cx + 6, yy, 2, 4, '#947c5e');
        }
      }
      // cornijas (faixas entre os andares) com dentículos
      for (const y of [andar1, andar1 + 10]) {
        for (let k = ini; k <= fim; k++) {
          const x = ox + k * MOD, ruina = Math.floor(hx(k, 3) * 4) * 16 + (hx(k, 9) < .2 ? 120 : 0); if (y < topo + ruina) continue;
          px(x, y, MOD, 8, '#bca682'); px(x, y, MOD, 2, '#d4c09c'); px(x, y + 8, MOD, 2, '#5e4c38');
          for (let q = 0; q < MOD; q += 8) px(x + q, y + 10, 4, 4, '#a08a6a');
        }
      }
      brilhoArena(VW / 2, yc - 80, 460, '255,190,120', .10);
    },
    meioFixo(s) {
      const yc = FY * T - cam.y, wx = X => X - cam.x;
      // colunas: tambores caídos antes da arena, uma quebrada na entrada e uma inteira no fim
      const coluna = (x, h, quebrada) => {
        const y0 = yc - h;
        px(x - 22, yc - 12, 44, 12, '#b8a07c'); px(x - 22, yc - 12, 44, 2, '#d8c4a0'); px(x - 18, yc - 18, 36, 6, '#a89070');
        px(x - 14, y0, 28, h - 18, '#ad9674');
        for (let k = 0; k < 28; k += 6) { px(x - 14 + k, y0, 2, h - 18, '#8e785a'); px(x - 12 + k, y0, 2, h - 18, '#c8b290'); }
        px(x - 14, y0, 4, h - 18, '#c8b290'); px(x + 10, y0, 4, h - 18, '#76624a');
        if (quebrada) for (let k = 0; k < 28; k += 4) px(x - 14 + k, y0 - Math.floor(hx(k, x) * 4) * 4, 4, 12, '#ad9674');
        else { px(x - 22, y0 - 14, 44, 8, '#c8b290'); px(x - 18, y0 - 6, 36, 6, '#a08a6a'); px(x - 24, y0 - 20, 48, 6, '#b8a07c'); px(x - 24, y0 - 20, 48, 2, '#dccaa6'); }
      };
      const tambor = (x, y, w) => { px(x, y - 22, w, 22, '#a89070'); px(x, y - 22, w, 4, '#c8b290'); px(x, y - 4, w, 4, '#7a664c'); px(x + w - 8, y - 22, 8, 22, '#d0bc98'); px(x + w - 6, y - 18, 4, 14, '#b8a07c'); };
      tambor(wx((s.x0 - 3.2) * T), yc, 40); tambor(wx((s.x0 - 1.6) * T), yc, 30); px(wx((s.x0 - 2.4) * T), yc - 8, 16, 8, '#a08a6a');
      coluna(wx((s.x0 + 2) * T), 190, true);
      coluna(wx((s.x1 - 3) * T), 300, false);
    },
    meioVivo(s) {
      const topo = 2 * T - cam.y, t = G.time, wx = X => X - cam.x;
      // estandartes vermelhos presos no teto, com dobras e a águia dourada (balançam com o vento)
      for (let xb = s.x0 + 6; xb < s.x1 - 5; xb += 11) {
        const x = wx(xb * T), bal = Math.round(Math.sin(t * 1.3 + xb) * 1.5) * 2; if (x < -80 || x > VW + 80) continue;
        px(x - 6, topo, 60, 6, '#5a3a1a'); px(x - 6, topo, 60, 2, '#7a5226');
        for (let k = 0; k < 48; k += 2) {
          const dobra = Math.floor(k / 6) % 4, cor = ['#a01818', '#8a1414', '#741010', '#8a1414'][dobra];
          const comp = 150 + (k % 12 < 6 ? 0 : 4) + Math.floor(hx(k, xb) * 3) * 4, dx = k > 24 ? bal / 2 : 0;
          px(x + k + dx, topo + 6, 2, comp, k < 4 || k > 43 ? '#c89a28' : cor);
          if (k % 4 == 0) px(x + k + dx, topo + 6 + comp, 2, 4, k < 4 || k > 43 ? '#c89a28' : '#5a0c0c');
        }
        px(x, topo + 14, 48, 4, '#c89a28'); px(x, topo + 130, 48, 4, '#c89a28');
        const AGUIA = ['...c..c...', '..cc..cc..', '.cccccccc.', 'cc.cccc.cc', 'c..cccc..c', '...cccc...', '...c..c...', '..cc..cc..'];
        AGUIA.forEach((ln, j) => { for (let i = 0; i < ln.length; i++) if (ln[i] == 'c') px(x + 14 + i * 2 + (j > 3 ? bal / 2 : 0), topo + 50 + j * 4, 2, 4, '#e0b43a'); });
        px(x + 18, topo + 86, 12, 4, '#e0b43a'); px(x + 22, topo + 82, 4, 16, '#e0b43a');
      }
    },
    luzes(s) {   // braseiros acesos dentro da arena
      for (const xb of [s.x0 + 4.5, s.x1 - 6]) {
        const x = xb * T - cam.x, y = FY * T - cam.y; if (x < -80 || x > VW + 80) continue;
        glow(30, x, y - 40, 90, .42 + .06 * Math.sin(G.time * 9 + xb), 58);
        obj('braseiro', x, y + 2); obj('chama_' + (Math.floor(G.time * 10 + xb) % 4), x, y - 18);
      }
    },
    plataforma(x, y, w) {   // sacada de mármore com mísulas
      px(x - 6, y - 6, w + 12, 14, '#d6ccb4'); px(x - 6, y - 6, w + 12, 4, '#f0e8d4'); px(x - 6, y + 6, w + 12, 2, '#9a8e78');
      for (let k = 0; k < w + 12; k += 14) { px(x - 6 + k, y - 2, 6, 2, '#c4b89e'); px(x - 2 + k, y + 2, 4, 2, '#e4dcc8'); }
      for (let k = 8; k < w - 6; k += 40) { px(x + k, y + 8, 12, 6, '#c4b89e'); px(x + k + 2, y + 14, 8, 6, '#b0a48a'); px(x + k + 4, y + 20, 4, 4, '#9a8e78'); }
    }
  },

  // ====================================================================================
  //  NAVIO — Espectro da Caravela
  // ====================================================================================
  espectro: {
    coberta: true,   // o mar é pintado depois das camadas do estilo (o céu acima do horizonte fica livre)
    P: .5,
    fundoFixo(s) {   // o mar e o horizonte
      const yc = FY * T - cam.y, hz = yc - 128;
      const faixas = ['#6aa6c0', '#4f8eaa', '#3d7a98', '#2f6886', '#245672', '#1b465e'];
      faixas.forEach((c, k) => { px(-4, hz + k * 22, VW + 8, 24, c); if (k) pontilhado(-4, hz + k * 22, VW + 8, 4, faixas[k - 1], 4); });
      px(-4, hz - 2, VW + 8, 2, '#d8eef8');
    },
    fundoVivo(s) {
      const t = G.time, yc = FY * T - cam.y, hz = yc - 128;
      // ilhas e rochedos distantes, e uma caravela ao longe
      const ilha = comParallax(.2, (s.x0 + 14) * T);
      for (const [dx, w, h] of [[0, 140, 22], [110, 70, 12], [520, 180, 30], [640, 60, 10]]) {
        const x = ilha + dx; px(x, hz - h, w, h, '#4c6a78'); px(x + 10, hz - h - 6, w * .4, 6, '#4c6a78'); px(x, hz - h, w, 2, '#6a8896');
      }
      const nav = comParallax(.15, (s.x0 + 30) * T) + Math.sin(t * .1) * 30;
      px(nav, hz - 8, 40, 6, '#3c5866'); px(nav + 18, hz - 34, 2, 26, '#3c5866'); px(nav + 8, hz - 30, 12, 16, '#5a7684'); px(nav + 22, hz - 28, 10, 14, '#5a7684');
      // ondas (cristas claras andando)
      for (let k = 1; k < 6; k++) {
        const yy = hz + k * 22 + 6, vel = 8 + k * 6, esp = 90 - k * 10, P = .3 + k * .1;
        for (let xx = -pmod(t * vel + cam.x * P + k * 37, esp); xx < VW + esp; xx += esp)
          px(xx, yy + Math.round(Math.sin(t * 2 + xx * .05 + k)) * 2, 16 - k * 2, 2, 'rgba(225,245,255,' + (.6 - k * .08) + ')');
      }
      // gaivotas
      for (let k = 0; k < 3; k++) { const gx = pmod(t * (20 + k * 6) + k * 300, VW + 200) - 100, gy = hz - 90 - k * 26 + Math.sin(t * 2 + k) * 6, asa = Math.sin(t * 8 + k) > 0 ? 2 : 0;
        px(gx - 6, gy - asa, 6, 2, '#e8eef2'); px(gx, gy, 2, 2, '#e8eef2'); px(gx + 2, gy - asa, 6, 2, '#e8eef2'); }
    },
    meioVivo(s) {   // bandeiras no alto dos mastros
      const t = G.time, topo = 2 * T - cam.y;
      for (const m of s.mastros) {
        const mx = m * T - cam.x; if (mx < -60 || mx > VW + 60) continue;
        const ond = k => Math.round(Math.sin(t * 6 + k * .6 + m) * 1.2) * 2;
        for (let k = 0; k < 28; k += 2) px(mx + 8 + k, topo + 6 + ond(k) + Math.floor(k / 4), 2, Math.max(2, 14 - Math.floor(k / 2)), k < 14 ? '#b01818' : '#e8e0c8');
      }
    },
    meioFixo(s) {   // amurada, mastros, enxárcias, velas rasgadas, gurupés, carga no convés
      const yc = FY * T - cam.y, topo = 2 * T - cam.y, wx = X => X - cam.x;
      const c0 = wx(s.casco[0] * T), c1 = wx(s.casco[1] * T);
      // gurupés (mastro inclinado da proa) e a figura de proa, por cima do cais
      linha(c0 + 30, yc - 40, c0 - 110, yc - 120, '#5a3a1e', 6); linha(c0 + 30, yc - 44, c0 - 110, yc - 124, '#7a5230', 2);
      corda(c0 - 104, yc - 120, wx((s.mastros[0]) * T), topo + 40, 18, '#2a1c10');
      corda(c0 - 80, yc - 106, c0 + 10, yc - 30, 6, '#2a1c10');
      // amurada atrás do convés (com castelos mais altos na proa e na popa)
      const altos = [[s.casco[0] * T, (s.casco[0] + 4) * T], [(s.casco[1] - 4) * T, s.casco[1] * T]];
      for (let x = Math.max(c0, -20); x < Math.min(c1, VW + 20); x += 2) {
        const alto = altos.some(([a, b]) => x + cam.x >= a && x + cam.x < b), y = alto ? yc - 64 - 28 : yc - 28;
        px(x, y, 2, 4, '#8a5a30'); px(x, y + 4, 2, 2, '#3a2412');
        if (pmod(x + cam.x, 26) < 4) px(x, y + 6, 2, alto ? 22 : 22, pmod(x + cam.x, 26) < 2 ? '#7a4e28' : '#4a2c14');
      }
      // mastros com enxárcias (escadas de corda), cesto da gávea e bandeira
      for (const m of s.mastros) {
        const mx = wx(m * T); if (mx < -260 || mx > VW + 260) continue;
        for (const d of [-1, 1]) {
          const p0 = [mx + d * 6, 4.4 * T - cam.y], p1 = [mx + d * 3.4 * T, yc - 28], p2 = [mx + d * 1.7 * T, yc - 28];
          linha(p0[0], p0[1], p1[0], p1[1], '#2a1c10'); linha(p0[0], p0[1], p2[0], p2[1], '#2a1c10');
          for (let u = .1; u < .98; u += .07) { const ax = p0[0] + (p1[0] - p0[0]) * u, ay = p0[1] + (p1[1] - p0[1]) * u, bx = p0[0] + (p2[0] - p0[0]) * u; px(Math.min(ax, bx), ay, Math.abs(bx - ax) + 2, 2, '#3e2a16'); }
          corda(mx, topo + 18, mx + d * 7.5 * T, yc - 30, 10, '#24180c');
        }
        px(mx - 8, topo, 16, yc - topo, '#5a3a1e'); px(mx - 8, topo, 4, yc - topo, '#7e5632'); px(mx - 4, topo, 2, yc - topo, '#8e6438'); px(mx + 6, topo, 2, yc - topo, '#2e1c0e');
        for (let yy = topo + 50; yy < yc - 20; yy += 84) { px(mx - 10, yy, 20, 6, '#3a3a42'); px(mx - 10, yy, 20, 2, '#6a6a74'); }
        const yg = 4 * T - cam.y; ret(mx - 26, yg, 52, 16, '#6a4426', '#8a5c34', '#3a2412'); for (let k = 0; k < 52; k += 8) px(mx - 26 + k, yg + 4, 2, 10, '#3a2412');
      }
      // velas rasgadas penduradas nas vergas de cima e velas recolhidas nas de baixo
      for (const r of G.rm.sol) {
        if (!r[4] || !dentroDaArena(s, r[0] + 1)) continue;
        const x = wx(r[0]), y = r[1] - cam.y, w = r[2]; if (x > VW + 40 || x + w < -40) continue;
        if (r[1] <= 9 * T) {
          const alt = 2.4 * T, inf = 2;
          for (let k = 6; k < w - 6; k += 2) {
            const u = (k - 6) / (w - 12), barriga = Math.sin(u * Math.PI) * (8 + inf), base = alt - 4 + Math.round(barriga / 2) * 2;
            const rasgo = hx(k >> 3, r[0]) < .3 ? Math.floor(hx(k, r[0]) * 5) * 6 : 0, hh2 = base - rasgo;
            const tom = u < .1 || u > .9 ? '#b8aa88' : (Math.floor(k / 14) % 2 ? '#e4d8bc' : '#d6c9aa');
            px(x + k, y + 6, 2, hh2, tom);
            for (let yy = y + 18; yy < y + 6 + hh2; yy += 14) px(x + k, yy, 2, 2, '#bdae8e');
          }
          const cx = x + w / 2, cy = y + 6 + alt / 2;   // cruz da Ordem de Cristo
          px(cx - 12, cy - 4, 24, 8, '#a01c1c'); px(cx - 4, cy - 14, 8, 28, '#a01c1c'); px(cx - 2, cy - 2, 4, 4, '#e8e0c8');
          furo(() => { for (let k = 0; k < 5; k++) { const hxp = x + 10 + Math.floor(hx(k, r[0]) * (w - 20)), hyp = y + 30 + Math.floor(hx(r[0], k) * 30); px(hxp, hyp, 4 + (k % 2) * 2, 6, '#000'); } });
        } else {
          for (let k = 8; k < w - 8; k += 2) px(x + k, y + 6, 2, 12 + Math.round(Math.sin(k * .3) * 1) * 2, Math.floor(k / 10) % 2 ? '#d6c9aa' : '#c4b694');
          for (let k = 16; k < w - 12; k += 26) px(x + k, y + 4, 4, 16, '#6a4a28');
        }
      }
      // carga no convés: canhões, barris, caixotes, rolo de corda e âncora
      const canhao = x => { ret(x - 20, yc - 14, 40, 14, '#5a3a1e', '#7a5230', '#2e1c0e'); disco(x - 12, yc - 4, 5, '#2a1a0c'); disco(x + 12, yc - 4, 5, '#2a1a0c');
        px(x - 18, yc - 26, 38, 12, '#2c2c34'); px(x - 18, yc - 26, 38, 2, '#5c5c68'); px(x + 16, yc - 28, 10, 16, '#2c2c34'); px(x - 22, yc - 24, 6, 8, '#3c3c46'); };
      canhao(wx((s.x0 + 7) * T)); canhao(wx((s.x0 + 34) * T));
      barril(wx((s.x0 + 20) * T), yc); barril(wx((s.x0 + 21.2) * T), yc); barril(wx((s.x0 + 20.6) * T), yc - 30);
      caixote(wx((s.x0 + 23) * T), yc, 34, 28);
      const rolo = wx((s.x0 + 16) * T); for (let k = 0; k < 4; k++) { px(rolo - 16 + k * 2, yc - 4 - k * 4, 32 - k * 4, 4, k % 2 ? '#a8885a' : '#8e7048'); }
      // leme na popa
      const lx = wx((s.casco[1] - 2) * T), ly = yc - 64 - 50; disco(lx, ly, 18, '#5a3a1e');
      for (let a = 0; a < 8; a++) linha(lx, ly, lx + Math.cos(a * Math.PI / 4) * 24, ly + Math.sin(a * Math.PI / 4) * 24, '#6a4426');
      furo(() => disco(lx, ly, 12, '#000')); disco(lx, ly, 4, '#8a6a40'); px(lx - 3, ly + 18, 6, 32, '#4a2c14');
    },
    luzes(s) {   // lanternas dos mastros e da popa
      const t = G.time;
      for (const m of s.mastros) { const x = m * T - cam.x + 18, y = 7.4 * T - cam.y; if (x < -60 || x > VW + 60) continue;
        glow(40, x + 6, y + 8, 60, .38 + .05 * Math.sin(t * 6 + m), 62); px(x, y, 12, 2, '#2a2a2a'); px(x, y + 2, 12, 12, '#ffcf6a'); px(x + 2, y + 4, 8, 8, '#fff2b0'); px(x, y + 14, 12, 2, '#2a2a2a'); px(x + 5, y - 6, 2, 6, '#2a2a2a'); }
      const x = (s.casco[1] - 0.5) * T - cam.x, y = FY * T - cam.y - 150;
      if (x > -60 && x < VW + 60) { glow(40, x, y + 8, 70, .4, 62); px(x - 6, y, 12, 16, '#ffcf6a'); px(x - 4, y + 2, 8, 12, '#fff2b0'); px(x - 2, y + 16, 4, 40, '#3a2412'); }
    },
    casco(s) {   // casco e convés (no lugar do chão, depois do cais)
      const yc = FY * T - cam.y, yb = RH * T - cam.y + 8, wx = X => X - cam.x, c0 = wx(s.casco[0] * T), c1 = wx(s.casco[1] * T);
      const L = ladrilho('casco', 96, 48, texturaCasco);
      const trechos = [[s.casco[0] * T, (s.casco[0] + 4) * T, yc - 64], [(s.casco[0] + 4) * T, (s.casco[1] - 4) * T, yc], [(s.casco[1] - 4) * T, s.casco[1] * T, yc - 64]];
      for (const [A0, A1, top] of trechos) {
        const a = Math.max(wx(A0), -8), b = Math.min(wx(A1), VW + 8); if (b <= a) continue;
        preencherLadrilho(L, a, top, b - a, yb - top, cam.x, cam.y);
        px(a, top - 2, b - a, 12, '#8a5a32'); px(a, top - 2, b - a, 2, '#b07a46');                    // convés visto de cima
        for (let X = Math.ceil((a + cam.x) / 48) * 48; X - cam.x < b; X += 48) { px(X - cam.x, top, 2, 10, '#3a2412'); px(X - cam.x + 6, top + 4, 2, 2, '#d8b070'); }
        px(a, top + 26, b - a, 8, '#4a2a12'); px(a, top + 26, b - a, 2, '#9a6838');                   // cinta (faixa grossa do casco)
        if (top < yc) { px(a, yc + 26, b - a, 8, '#4a2a12'); px(a, yc + 26, b - a, 2, '#9a6838'); }
      }
      // a proa curva para dentro embaixo, e a popa tem um degrau
      furo(() => {
        for (let d = 0; d < 120; d += 2) { const x = c0 + d; if (x < -4 || x > VW + 4) continue; const recua = Math.round((1 - d / 120) * (1 - d / 120) * 90 / 2) * 2; px(x, yb - recua, 2, recua + 4, '#000'); }
        for (let d = 0; d < 20; d += 2) { const x = c1 - d - 2; if (x < -4 || x > VW + 4) continue; px(x, yb - (20 - d), 2, 24 - d, '#000'); }
      });
      // portinholas de canhão com aro de latão
      for (let X = (s.casco[0] + 6) * T; X < (s.casco[1] - 5) * T; X += 5 * T) {
        const x = wx(X); if (x < -40 || x > VW + 40) continue;
        px(x - 2, yc + 42, 26, 22, '#c8a048'); px(x, yc + 44, 22, 18, '#160c04'); px(x + 6, yc + 50, 10, 6, '#2c2c34');
      }
      // janelas da popa
      const xp = c1 - 3 * T; for (let k = 0; k < 3; k++) { px(xp + k * 28, yc - 44, 18, 16, '#c8a048'); px(xp + k * 28 + 2, yc - 42, 14, 12, '#ffd47a'); px(xp + k * 28 + 8, yc - 42, 2, 12, '#7a5a2a'); }
      // prancha de embarque, do cais até o convés
      px(c0 - 42, yc - 2, 54, 6, '#9a6a3a'); px(c0 - 42, yc - 2, 54, 2, '#c08850'); for (let k = 0; k < 54; k += 10) px(c0 - 40 + k, yc + 2, 4, 2, '#5a3a1e');
      px(c0 - 44, yc - 22, 2, 22, '#6a4426'); corda(c0 - 44, yc - 22, c0 + 4, yc - 30, 4, '#2a1c10');
    },
    plataforma(x, y, w) {   // verga: vara de madeira presa ao mastro, com cabos
      px(x - 6, y - 4, w + 12, 10, '#6a4224'); px(x - 6, y - 4, w + 12, 2, '#9a6838'); px(x - 6, y + 4, w + 12, 2, '#3a2412');
      px(x - 8, y - 6, 6, 14, '#3a3a42'); px(x + w + 2, y - 6, 6, 14, '#3a3a42');
      corda(x, y + 8, x + w, y + 8, 10, '#2a1c10');
    },
    frente(s) {   // ondas batendo no casco, na frente de tudo (somem nas pontas do navio)
      const t = G.time, yb = RH * T - cam.y, a = s.casco[0] * T - cam.x - 40, b = s.casco[1] * T - cam.x + 40;
      if (b < 0 || a > VW) return;
      for (let k = 0; k < 3; k++) {
        const yy = yb - 30 + k * 10;
        for (let xx = Math.max(-4, a) - pmod(t * (30 + k * 20) + k * 50, 4); xx < Math.min(VW + 4, b); xx += 4) {
          const ponta = clamp(Math.min(xx - a, b - xx) / 120, 0, 1), v = Math.sin(xx * .05 + t * 2.4 + k + cam.x * .05);
          const h = Math.round((10 + v * 6) * ponta / 2) * 2; if (h <= 0) continue;
          px(xx, yy + 14 - h, 4, 40, ['#1d5674', '#286a8c', '#3884a6'][k]); if (v > .7) px(xx, yy + 14 - h, 4, 2, '#e0f4ff');
        }
      }
    }
  },

  // ====================================================================================
  //  FÁBRICA — Colosso a Vapor
  // ====================================================================================
  colosso: {
    coberta: true,
    P: .7,
    fundoVivo(s) {   // engrenagens girando, ponteiros dos manômetros e vapor das válvulas
      const t = G.time, topo = 2 * T - cam.y, P = .7, yCano = topo + 86;
      const eg = (X, Y, r, v) => desenharEngrenagem(comParallax(P, X), Y, r, v);
      eg((s.x0 + 15) * T, topo + 200, 120, .5); eg((s.x0 + 19.6) * T, topo + 120, 74, -.8); eg((s.x0 + 36) * T, topo + 210, 104, .45); eg((s.x0 + 6) * T, topo + 150, 60, -.7);
      for (let X = s.x0 - 8; X < s.x1 + 8; X += 7) {
        const x = comParallax(P, X * T); if (x < -40 || x > VW + 40) continue;
        if (pmod(X, 14) == pmod(s.x0 + 2, 14)) { const a = Math.sin(t * 2 + X) * 1.2 - .8; linha(x + 4, yCano + 60, x + 4 + Math.cos(a) * 7, yCano + 60 + Math.sin(a) * 7, '#a01c1c'); }
        if (pmod(X, 21) == pmod(s.x0 + 5, 21)) for (let q = 0; q < 4; q++) { const u = pmod(t * .6 + q / 4, 1); g.globalAlpha = .45 * (1 - u); px(x - 6 + Math.sin(t + q) * 6, yCano - 12 - u * 70, 14 + u * 16, 10 + u * 8, '#d8d8de'); g.globalAlpha = 1; }
      }
    },
    fundoFixo(s) {
      const yc = FY * T - cam.y, topo = 2 * T - cam.y, P = .7, ox = comParallax(P, s.x0 * T);
      preencherLadrilho(ladrilho('tijolo', 64, 48, texturaTijolo), -4, topo, VW + 8, yc - topo + 10, -ox, 0);
      // janelões em arco (vidros quebrados deixam ver o céu da época) e fachos de luz empoeirados
      for (let k = -1; k < 8; k++) {
        const x = ox + k * 300 + 60; if (x < -160 || x > VW + 60) continue;
        const y = topo + 40, w = 96, h = 180;
        aberturaArco(x - 6, y - 6, w + 12, h + 12, '#2a1a12');
        aberturaArco(x, y, w, h, '#3a3a40');
        furo(() => { for (let gy = 0; gy < 6; gy++) for (let gx = 0; gx < 4; gx++) { if (hx(gx + k * 4, gy) < .25) continue; aberturaArco(x + 4 + gx * 23, y + 4 + gy * 29, 19, 25, '#000'); } });
        px(x, y + h * .5, w, 4, '#3a3a40');
        g.globalAlpha = .1; for (let q = 0; q < 6; q++) { const sx = x + 10 + q * 14; for (let yy = y + h; yy < yc; yy += 2) px(sx + (yy - y - h) * .5, yy, 14, 2, '#fff0c8'); } g.globalAlpha = 1;
      }
      // fuligem no alto
      pontilhado(-4, topo, VW + 8, 30, 'rgba(10,6,4,.5)', 2); pontilhado(-4, topo + 30, VW + 8, 30, 'rgba(10,6,4,.4)', 4);
      // canos de cobre com flanges, manômetros e válvulas soltando vapor
      const yCano = topo + 86, xa = comParallax(P, s.x0 * T) - 400, xb = comParallax(P, s.x1 * T) + 400;
      px(xa, yCano, xb - xa, 16, '#7a4a26'); px(xa, yCano, xb - xa, 4, '#b8804a'); px(xa, yCano + 8, xb - xa, 2, '#8e5a30'); px(xa, yCano + 14, xb - xa, 2, '#3a2010');
      for (let X = s.x0 - 8; X < s.x1 + 8; X += 7) {
        const x = comParallax(P, X * T); if (x < -40 || x > VW + 40) continue;
        ret(x - 4, yCano - 4, 12, 24, '#5a5a62', '#8a8a94', '#2a2a30');
        px(x, yCano + 20, 8, yc - yCano - 80, '#6a4022'); px(x, yCano + 20, 2, yc - yCano - 80, '#a06a3a'); px(x + 6, yCano + 20, 2, yc - yCano - 80, '#3a2010');
        if (pmod(X, 14) == pmod(s.x0 + 2, 14)) { disco(x + 4, yCano + 60, 12, '#3a3a40'); disco(x + 4, yCano + 60, 9, '#d8d0b8'); }
      }
    },
    meioVivo(s) {   // fogo das fornalhas e correntes balançando
      const t = G.time, yc = FY * T - cam.y, topo = 2 * T - cam.y, wx = X => X - cam.x;
      for (const xb of [s.x0 + 2.6, s.x1 - 3.6]) {
        const x = wx(xb * T); if (x < -100 || x > VW + 100) continue;
        chamas(x - 32, yc, 64, 70, t, x); for (let k = 0; k < 68; k += 12) px(x - 34 + k, yc - 104, 4, 104, '#2a2a30');
      }
      for (const xc of [s.x0 + 9, s.x0 + 24.5, s.x0 + 34]) {   // correntes com ganchos balançando
        const x0 = wx(xc * T), ang = Math.sin(t * 1.1 + xc) * .07, comp = 4.5 * T + (xc % 3) * 20; if (x0 < -60 || x0 > VW + 60) continue;
        for (let k = 0; k < comp; k += 8) { const x = x0 + Math.sin(ang) * k; px(x - 2, topo + k, 4, 6, (k / 8) % 2 ? '#4a4a52' : '#6a6a74'); px(x - 2, topo + k, 2, 6, '#8a8a94'); }
        const x = x0 + Math.sin(ang) * comp, y = topo + comp; px(x - 2, y, 4, 12, '#7a7a84'); px(x - 10, y + 10, 16, 4, '#7a7a84'); px(x - 10, y + 2, 4, 10, '#7a7a84'); px(x - 10, y + 10, 16, 2, '#9a9aa4');
      }
    },
    meioFixo(s) {   // fornalhas, carvão, caixotes e a tubulação da entrada
      const yc = FY * T - cam.y, topo = 2 * T - cam.y, wx = X => X - cam.x;
      const fornalha = (x) => {
        const y = yc - 150;
        preencherLadrilho(ladrilho('tijolo', 64, 48, texturaTijolo), x - 60, y, 120, 150, cam.x, 0);
        px(x - 64, y - 8, 128, 10, '#3a3a42'); px(x - 64, y - 8, 128, 2, '#6a6a74');
        px(x - 20, topo, 40, y - topo - 8, '#2c2a2e'); px(x - 20, topo, 6, y - topo - 8, '#4a4850'); px(x + 14, topo, 6, y - topo - 8, '#18161a');   // chaminé
        aberturaArco(x - 40, y + 40, 80, 110, '#1a1a1e'); aberturaArco(x - 34, y + 46, 68, 104, '#0c0604');
      };
      fornalha(wx((s.x0 + 2.6) * T)); fornalha(wx((s.x1 - 3.6) * T));
      const carvao = x => { for (let k = 0; k < 70; k += 4) { const h = Math.round(Math.sin(k / 70 * Math.PI) * 26 / 2) * 2 + 2; px(x + k, yc - h, 4, h, hx(k, x) < .3 ? '#2c2c30' : '#1c1c20'); if (hx(x, k) < .2) px(x + k, yc - h, 2, 2, '#4a4a52'); } };
      carvao(wx((s.x0 + 5.6) * T)); carvao(wx((s.x1 - 7.8) * T));
      caixote(wx((s.x0 + 13) * T), yc, 40, 32, true); caixote(wx((s.x0 + 14.3) * T), yc, 30, 26); caixote(wx((s.x0 + 13.4) * T), yc - 32, 28, 22, true);
      // tubulação que entra na fábrica (já aparece antes da arena)
      const xi = wx((s.x0 - 4) * T); px(xi, yc - 18, wx((s.x0 + 2) * T) - xi, 14, '#6a4022'); px(xi, yc - 18, wx((s.x0 + 2) * T) - xi, 4, '#a8743e'); for (let k = 0; k < 6 * T; k += 64) ret(xi + k, yc - 22, 10, 22, '#5a5a62', '#8a8a94', '#2a2a30');
    },
    luzes(s) {
      for (const xb of [s.x0 + 2.6, s.x1 - 3.6]) { const x = xb * T - cam.x, y = FY * T - cam.y; if (x < -150 || x > VW + 150) continue; glow(22, x, y - 40, 150, .32 + .08 * Math.sin(G.time * 7 + xb), 55); }
    },
    plataforma(x, y, w) {   // passarela de grade com guarda-corpo
      for (let k = 0; k < w; k += 16) px(x + k, y - 24, 2, 24, '#6a6a74');
      px(x - 2, y - 26, w + 4, 4, '#8a8a94'); px(x - 2, y - 26, w + 4, 2, '#aaaab4');
      px(x - 4, y - 2, w + 8, 10, '#4e4e58'); px(x - 4, y - 2, w + 8, 2, '#9a9aa4');
      for (let k = 0; k < w + 4; k += 6) px(x - 2 + k, y + 2, 2, 4, '#16161c');
      px(x - 4, y + 8, w + 8, 2, '#26262c');
      for (let k = 16; k < w - 10; k += 64) { linha(x + k, y + 10, x + k + 20, y + 40, '#3a3a42'); linha(x + k + 40, y + 10, x + k + 20, y + 40, '#3a3a42'); }
    },
    frente(s) {   // fagulhas subindo das fornalhas
      const t = G.time, yc = FY * T - cam.y;
      for (const xb of [s.x0 + 2.6, s.x1 - 3.6]) {
        const x0 = xb * T - cam.x; if (x0 < -100 || x0 > VW + 100) continue;
        for (let k = 0; k < 12; k++) { const u = pmod(t * .5 + k * .137, 1); px(x0 - 30 + hx(k, xb) * 60 + Math.sin(t * 3 + k) * 8, yc - 60 - u * 200, 2, 2, 'rgba(255,' + (150 + k * 6) + ',60,' + (1 - u) + ')'); }
      }
    }
  },

  // ====================================================================================
  //  CASAMATA — Máquina Enigma
  // ====================================================================================
  enigma: {
    coberta: true,
    P: .75,
    fundoFixo(s) {
      const yc = FY * T - cam.y, topo = 2 * T - cam.y, P = .75, ox = comParallax(P, s.x0 * T);
      preencherLadrilho(ladrilho('concreto', 64, 64, texturaConcreto), -4, topo, VW + 8, yc - topo + 10, -ox, 0);
      // seteiras (aberturas estreitas) mostrando o céu de fora
      for (let k = -1; k < 8; k++) {
        const x = ox + k * 260 + 40; if (x < -200 || x > VW + 40) continue;
        const y = topo + 70;
        px(x - 8, y - 8, 156, 36, '#3c3c38'); px(x - 8, y - 8, 156, 4, '#6e6e66'); px(x - 8, y + 24, 156, 4, '#2c2c28');
        furo(() => px(x, y, 140, 20, '#000'));
        for (let q = 12; q < 140; q += 24) px(x + q, y, 4, 20, '#2a2a2e');
        pontilhado(x - 8, y + 28, 156, 40, 'rgba(20,20,18,.4)', 4);   // escorrido
      }
      // cabos pendurados, canos e placas de aviso
      const xa = ox - 400;
      for (let k = 0; k < 4; k++) corda(xa + k * 37, topo + 24 + k * 6, xa + 1400 + k * 23, topo + 30 + k * 4, 30 + k * 8, ['#1c1c1e', '#2a2018', '#1c2418', '#241c1c'][k]);
      px(-4, topo + 150, VW + 8, 10, '#4a4a50'); px(-4, topo + 150, VW + 8, 2, '#7a7a84'); px(-4, topo + 158, VW + 8, 2, '#2a2a2e');
      for (let k = -1; k < 10; k++) { const x = ox + k * 180 + 120; if (x < -40 || x > VW + 40) continue; ret(x, topo + 146, 8, 18, '#5a5a62', '#8a8a94', '#2a2a30'); }
      for (let k = -1; k < 6; k++) {   // placa triangular amarela e preta
        const x = ox + k * 360 + 250, y = yc - 150; if (x < -60 || x > VW + 60) continue;
        for (let r = 0; r < 28; r += 2) px(x + 14 - r / 2, y + r, r + 2, 2, r > 23 ? '#1a1a1a' : '#e0b828');
        px(x + 13, y + 8, 4, 10, '#1a1a1a'); px(x + 13, y + 20, 4, 4, '#1a1a1a');
      }
      // luminárias de parede com grade
      for (let k = -1; k < 8; k++) { const x = ox + k * 260 + 170, y = topo + 118; if (x < -40 || x > VW + 40) continue; ret(x - 8, y, 16, 14, '#3a3a40', '#5a5a62'); px(x - 6, y + 4, 12, 8, '#ffe0a0'); px(x - 2, y + 4, 2, 8, '#3a3a40'); px(x + 2, y + 4, 2, 8, '#3a3a40'); }
    },
    meioFixo(s) {   // sacos de areia, arame farpado, caixas de munição, tambores, holofote
      const yc = FY * T - cam.y, wx = X => X - cam.x;
      const muro = (X, filas, larg) => {
        const x0 = wx(X * T); if (x0 > VW + 200 || x0 + larg * 26 < -200) return;
        for (let f = 0; f < filas; f++) for (let k = 0; k < larg - (f % 2); k++) sacoDeAreia(x0 + k * 26 + (f % 2) * 13, yc - 12 - f * 11);
        const y = yc - 12 - filas * 11 - 4;
        for (let x = x0; x < x0 + larg * 26; x += 2) { const v = Math.sin((x - x0) * .4); px(x, y + Math.round(v * 3) * 2, 2, 2, '#8a8a92'); if (pmod(x - x0, 14) < 2) { px(x - 2, y - 4 + Math.round(v * 3) * 2, 2, 2, '#aaaab2'); px(x + 2, y + 4 + Math.round(v * 3) * 2, 2, 2, '#aaaab2'); } }
      };
      muro(s.x0 - 3, 3, 5); muro(s.x0 + 1.4, 2, 3); muro(s.x1 - 6, 3, 5);
      const tambor = x => { ret(x - 12, yc - 34, 24, 34, '#3a4a32', '#5a6a48', '#222c1c'); px(x - 12, yc - 26, 24, 2, '#2a3424'); px(x - 12, yc - 10, 24, 2, '#2a3424'); px(x - 4, yc - 30, 8, 4, '#c8b030'); };
      tambor(wx((s.x0 + 12) * T)); tambor(wx((s.x0 + 12.9) * T));
      const municao = (x, y) => { ret(x, y - 18, 36, 18, '#4a5232', '#6a7448', '#2a3018'); px(x + 4, y - 14, 10, 4, '#c8c090'); px(x + 22, y - 12, 10, 2, '#2a3018'); };
      municao(wx((s.x0 + 25) * T), yc); municao(wx((s.x0 + 25.4) * T), yc - 18); municao(wx((s.x0 + 26.4) * T), yc);
      // holofote no tripé
      const hxp = wx((s.x0 + 7) * T); linha(hxp, yc - 40, hxp - 16, yc, '#2a2a2e'); linha(hxp, yc - 40, hxp + 16, yc, '#2a2a2e'); px(hxp - 2, yc - 44, 4, 44, '#3a3a40');
      ret(hxp - 16, yc - 62, 32, 22, '#3a3a40', '#5a5a64', '#1e1e22'); disco(hxp + 10, yc - 51, 8, '#fff2b0');
    },
    luzes(s) {   // luminárias, facho do holofote varrendo e alarmes piscando
      const t = G.time, yc = FY * T - cam.y, topo = 2 * T - cam.y, hxp = (s.x0 + 7) * T - cam.x + 10;
      const ox = comParallax(.75, s.x0 * T);
      if (s.x0 * T - cam.x < VW) for (let k = -1; k < 8; k++) { const x = ox + k * 260 + 170; if (x < -100 || x > VW + 100 || x < s.x0 * T - cam.x) continue; glow(40, x, topo + 124, 110, .16, 60); }
      if (hxp > -500 && hxp < VW + 500) {
        const ang = -Math.PI / 2 + .55 + Math.sin(t * .5) * .5;
        for (let k = 0; k < 40; k++) { const L = k * 14, w = 8 + k * 2.2; g.fillStyle = 'rgba(255,240,180,' + (.11 * (1 - k / 40)) + ')'; g.fillRect(Math.round((hxp + Math.cos(ang) * L - w / 2) / 2) * 2, Math.round((yc - 51 + Math.sin(ang) * L) / 2) * 2, Math.round(w / 2) * 2, 14); }
      }
      for (let xb = s.x0 + 4; xb < s.x1 - 2; xb += 9) {
        const x = xb * T - cam.x; if (x < -80 || x > VW + 80) continue; const on = Math.sin(t * 5 + xb) > 0;
        px(x - 8, topo, 16, 6, '#2a2a2e'); px(x - 6, topo + 6, 12, 10, on ? '#ff3a20' : '#5a1a14'); px(x - 4, topo + 8, 4, 4, on ? '#ffb090' : '#7a2a20');
        if (on) glow(5, x, topo + 14, 90, .32, 50);
      }
    },
    plataforma(x, y, w) {   // viga de aço (perfil I) com rebites
      px(x - 6, y - 4, w + 12, 4, '#7a7a84'); px(x - 6, y - 4, w + 12, 2, '#9a9aa4'); px(x - 2, y, w + 4, 6, '#3e3e46'); px(x - 6, y + 6, w + 12, 4, '#5a5a64');
      for (let k = 2; k < w + 8; k += 14) { px(x - 4 + k, y - 2, 2, 2, '#b0b0ba'); px(x - 4 + k, y + 8, 2, 2, '#8a8a94'); }
      px(x - 6, y + 10, w + 12, 2, '#26262c');
    },
    frente(s) {   // poeira caindo do teto
      const t = G.time, a = (s.x0 - 2) * T - cam.x; if (a > VW) return;
      for (let k = 0; k < 16; k++) { const u = pmod(t * .22 + k * .19, 1), x = Math.max(a, 0) + hx(k, 2) * VW; px(x, 2 * T - cam.y + u * 380, 2, 2, 'rgba(210,205,190,' + (.45 * (1 - u)) + ')'); }
    }
  }
};
