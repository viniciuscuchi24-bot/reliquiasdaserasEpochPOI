"use strict";
// ===== Núcleo do jogo: física, salas, inimigos, combate, progresso =====
const cv=document.getElementById('c');let g=cv.getContext('2d');   // 'let': as arenas dos chefes pintam numa tela menor e depois ampliam
const VW=960,VH=540,T=32,RH=18,FY=15,NR=ERAS.length;
const K={},P={},cam={x:0,y:0};
const kd=(...a)=>a.some(k=>K[k]),kp=(...a)=>a.some(k=>P[k]);
const hsl=(h,s,l,a=1)=>"hsla("+h+","+s+"%,"+l+"%,"+a+")";
const ov=(a,b)=>a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;
const ovr=(o,r)=>o.x<r[0]+r[2]&&o.x+o.w>r[0]&&o.y<r[1]+r[3]&&o.y+o.h>r[1];
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const solidAt=(S,x,y)=>S.some(r=>x>=r[0]&&x<r[0]+r[2]&&y>=r[1]&&y<r[1]+r[3]);
function mul(a){return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
const ABIL={
 2:{k:'dash',n:'Esquiva Veloz',t:'Bronze e ferro mudaram a guerra e o trabalho. Sua esquiva fica mais rápida e recarrega mais depressa.',d:'Esquiva Veloz: pule e aperte Z (ou botão direito) no ar para cruzar vãos longos.'},
 5:{k:'dj',n:'Asas de Dédalo',t:'Na lenda grega, Dédalo voou com asas de cera. Agora você pode pular uma segunda vez no ar: aperte Pular de novo durante o salto.',d:'Asas: aperte Pular de novo no ar para dar um segundo pulo.'},
 11:{k:'wall',n:'Garras de Muralha',t:'Poucos escalaram as muralhas de Constantinopla. Agora você se agarra às paredes: no ar, encoste numa parede segurando a direção dela e aperte Pular para saltar para o outro lado.',d:'Garras: no ar, segure a direção da parede para se agarrar e aperte Pular para saltar dela.'},
 16:{k:'lamp',n:'Lanterna da Razão',t:'O Iluminismo acendeu a luz da razão. Seu raio de visão aumentou: use a lanterna nas áreas escuras para achar os braseiros.',d:'Lanterna: nas áreas escuras você agora enxerga bem mais longe.'}};
const SW=[
 {n:'Espada de Madeira',r:70,d:1,c:'#d8c9a0',t:'Uma lâmina simples, talhada em madeira dura. Foi assim que a humanidade começou a se defender.'},
 {n:'Lâmina de Pedra',r:100,d:1.5,c:'#e6e2d6',t:'Com a pedra polida do Neolítico, a lâmina ficou mais longa e afiada. Seu alcance aumentou.'},
 {n:'Espada de Ferro',r:135,d:2,c:'#cfd6de',t:'A Idade dos Metais forjou espadas de ferro, fortes e duráveis. Seu alcance e dano aumentaram.'},
 {n:'Aço de Damasco',r:170,d:2.5,c:'#bfe3ff',t:'Os ferreiros do mundo islâmico criaram o aço de Damasco, flexível e quase inquebrável.'},
 {n:'Aço Temperado',r:205,d:3,c:'#ffe2a0',t:'Fornos melhores e têmpera precisa deram à lâmina um gume que corta armaduras.'},
 {n:'Liga Bessemer',r:240,d:4,c:'#ffb27a',t:'A Revolução Industrial produziu aço em massa. A lâmina agora é longa e pesada como um trilho.'},
 {n:'Liga de Duralumínio',r:280,d:5,c:'#a0ffe0',t:'Ligas leves e resistentes, nascidas das guerras modernas. O alcance máximo da sua lâmina.'}];
const WP={1:1,2:2,8:3,23:6},WB={13:4,20:5};
const ROOMS=[];
let G,p;
const MOTES=[];for(let i=0;i<70;i++)MOTES.push({x:Math.random()*VW,y:Math.random()*VH,vx:(Math.random()-.5)*10,vy:-4-Math.random()*10,s:1+Math.random()*2,a:.1+Math.random()*.3});

function newGame(){
 p={x:0,y:0,w:22,h:38,vx:0,vy:0,f:1,hp:5,mhp:5,soul:0,g:false,dj:0,dashT:0,dashCd:0,dAir:false,atk:0,atkCd:0,up:false,dn:false,pg:0,wp:0,hit:[],inv:0,heal:0,coy:0,jb:0,wall:0,wallT:0,dor:0,pouso:0,asas:0,auto:0,autoD:1,ab:{dash:0,dj:0,wall:0,lamp:0},safe:{x:0,y:0}};
 G={rm:null,ri:0,coins:0,echo:null,bench:{ri:0},vis:{},RS:{},mode:'title',fade:0,fdir:0,pend:null,ban:{t:0,a:'',b:''},shake:0,hs:0,dlg:null,runes:0,time:0,fx:[],S:[],toast:{s:'',t:0},near:null,mapOpen:false,dica:null,avisoEscudo:0};
}
function startGame(){newGame0()}
function newGame0(){G.mode='trans';G.fade=1;G.fdir=-1;enterRoom(0,'bench');}
function restart(){newGame();newGame0()}

function mkEnemy(e){
 // tamanho da caixa vem do manifesto dos monstros (assets/monstros/monstros.js); y de quem anda = chão - 26
 const hp=e.hp,M=typeof MONSTROS!='undefined'&&MONSTROS&&MONSTROS[e.k],w=M?M.caixa[0]:28,h=M?M.caixa[1]:28,ph=Math.random()*10;
 if(e.k=='w')return{k:'w',x:e.x,y:e.y+26-h,w,h,vx:(Math.random()<.5?-1:1)*55,vy:0,kx:0,hp,mh:hp,fl:0,dano:0,ph,dead:0};
 if(e.k=='h')return{k:'h',x:e.x,y:e.y+26-h,w,h,vx:0,vy:0,kx:0,hp,mh:hp,fl:0,dano:0,ph,t:Math.random()*1.5,dead:0};
 return{k:'f',x:e.x,y:e.y,w,h,bx:e.x,by:e.y,ph,kx:0,hp,mh:hp,fl:0,dano:0,dead:0};
}
function enterRoom(i,how){
 const R=ROOMS[i]||(ROOMS[i]=genRoom(i));G.rm=R;G.ri=i;G.vis[i]=1;
 R.st=G.RS[i]||(G.RS[i]={read:0,xr:0,done:0,open:0,gate:0,sh:[0,0,0],boss:0,alt:0});
 reiniciarTrechos(R);posicionarMoveis(R);spawnEnemies(R);if(how=='left'&&i>G.bench.ri)G.bench.ri=i;
 p.vx=p.vy=0;p.dashT=0;p.heal=0;p.atk=0;p.wall=0;p.wallT=0;p.auto=0;p.inv=Math.max(p.inv,.5);
 if(how=='left'){p.x=1.2*T;p.auto=.4;p.autoD=1;p.f=1}
 else if(how=='right'){p.x=(R.W-1.8)*T;p.auto=.4;p.autoD=-1;p.f=-1}
 else{p.x=R.bench.x-p.w/2}
 p.y=FY*T-p.h;p.safe={x:p.x,y:p.y};p.g=true;
 G.ban={t:3.4,a:R.E.n,b:R.E.y};
 prepararSala(R);camUpdate(1,0);
}
function go(i,how){G.pend={i,how};G.mode='trans';G.fdir=1}
function say(title,text,cb){G.dlg={title,text,n:0,cb};G.mode='dialog'}
function toast(s,t){G.toast={s,t:t||2.4}}
// penas soltas no pulo duplo e impacto do golpe (desenhados em personagem.js)
function penas(x,y){for(let k=0;k<7;k++)G.fx.push({x:x+(Math.random()-.5)*16,y:y+(Math.random()-.5)*10,vx:(Math.random()-.5)*160,vy:40+Math.random()*120,t:.5+Math.random()*.4,c:k%3?'#f4ecd6':'#e8bc54',s:2+Math.random()*2,pena:1})}
function impacto(x,y){G.imp=G.imp||[];G.imp.push({x,y,t:.16});typeof sfx=='function'&&sfx('acerto')}
function burst(x,y,n,c){for(let k=0;k<n;k++)G.fx.push({x,y,vx:(Math.random()-.5)*320,vy:(Math.random()-.8)*300,t:.4+Math.random()*.4,c,s:2+Math.random()*3})}

function buildSolids(R){
 const a=R.sol.slice();
 for(const m of R.mov)a.push([m.x,m.y,m.w,16,1]);      // plataformas móveis (fases.js)
 solidosTrechos(R,a);
 if(R.i==0)a.push([-T,0,T,RH*T]);
 return a;
}
function mv(o,dx,dy,S){
 let hx=0,hy=0;
 o.x+=dx;
 for(const r of S)if(!r[4]&&ovr(o,r)){if(dx>0){o.x=r[0]-o.w;hx=1}else if(dx<0){o.x=r[0]+r[2];hx=-1}}
 const pb=o.y+o.h;
 o.y+=dy;
 if(dy<0&&S.some(r=>!r[4]&&ovr(o,r))){
  out:for(const s of[4,8,12,16])for(const sg of[1,-1]){
   const t={x:o.x+s*sg,y:o.y,w:o.w,h:o.h};
   if(!S.some(r=>!r[4]&&ovr(t,r))){o.x=t.x;break out}
  }
 }
 for(const r of S)if(ovr(o,r)){
  if(r[4]){if(dy>0&&pb<=r[1]+.5){o.y=r[1]-o.h;hy=1}}
  else if(dy>0){o.y=r[1]-o.h;hy=1}else if(dy<0){o.y=r[1]+r[3];hy=-1}
 }
 return[hx,hy];
}

addEventListener('keydown',e=>{
 if(['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Tab'].includes(e.code))e.preventDefault();
 if(!K[e.code])P[e.code]=1;K[e.code]=1;
});
addEventListener('keyup',e=>{K[e.code]=0});
addEventListener('blur',()=>{for(const k in K)K[k]=0});
addEventListener('pointerdown',e=>{
 if(e.pointerType!=='mouse')return;
 if(e.target&&e.target.closest&&e.target.closest('#tc,.tb,#h'))return;   // controles de toque (mesmo usados com o mouse) não contam como clique de golpe
 if(e.button===0){if(!K.Mouse0)P.Mouse0=1;K.Mouse0=1}
 else if(e.button===2){if(!K.Mouse2)P.Mouse2=1;K.Mouse2=1}
});
addEventListener('pointerup',e=>{if(e.button===0)K.Mouse0=0;else if(e.button===2)K.Mouse2=0});
addEventListener('contextmenu',e=>e.preventDefault());

function hurt(n,dir){
 if(p.inv>0||G.mode!='play')return;
 p.hp-=n;p.inv=1.2;p.dor=.3;p.pouso=0;p.vx=dir*260;p.vy=-300;p.dashT=0;p.heal=0;p.atk=0;p.gT=9;G.shake=.35;G.hs=.12;
 burst(p.x+11,p.y+19,14,'#fff');
 if(p.hp<=0)die();
}
function die(){
 G.echo={ri:G.ri,x:p.x,y:p.y,c:G.coins,cd:1.5};G.coins=0;p.hp=p.mhp;p.soul=0;
 G.pend={i:G.bench.ri,how:'bench'};
 // com animação de morte (Hallokin): a abóbora estoura antes de a tela escurecer
 const M=PERSONAGEM&&PERSONAGEM.anim&&PERSONAGEM.anim.morte;
 if(M){G.mode='morte';G.morteT=G.morteT0=M.quadros.length/M.fps+.25;p.vx=0;p.atk=0;p.gT=9;p.asas=0}else{G.mode='trans';G.fdir=1}
 toast('Você caiu... suas moedas ficaram em um eco',4);
}
function spikeHit(){
 if(p.inv<=0)hurt(1,0);
 if(G.mode=='trans'&&G.fdir>0)return;
 p.x=p.safe.x;p.y=p.safe.y;p.vx=p.vy=0;p.inv=Math.max(p.inv,1.1);
}
function killEnemy(e){
 e.dead=1;e.morte=G.time;const R=G.rm;burst(e.x+e.w/2,e.y+e.h/2,18,'#dde');
 if(e.k=='B'){
  G.coins+=60;R.st.boss=1;R.lock=false;R.pr=[];G.shake=.6;
  R.es.forEach(o=>{if(o!==e&&o.sec==e.sec&&!o.dead){o.dead=1;burst(o.x+o.w/2,o.y+o.h/2,10,'#dde')}});
  concluirTrecho(e.sec);
 }else if(e.k!='rot')G.coins+=3+Math.floor(G.ri/4);
}
function giveWeapon(t){
 if(t>p.wp){p.wp=t;say('Nova arma — '+SW[t].n,SW[t].t)}else toast('Você já tem uma lâmina melhor');
}
function dmg(e,n){
 e.hp-=n;e.fl=.1;e.dano=.3;p.soul=Math.min(99,p.soul+11);G.hs=.05;G.shake=Math.max(G.shake,.12);
 burst(e.x+e.w/2,e.y+e.h/2,6,'#fff');
 if(e.hp<=0&&!e.dead)killEnemy(e);
}

function updEnemy(e,dt,S){
 e.fl-=dt;if(e.dano>0)e.dano-=dt;
 if(e.k=='f'){
  const dx=p.x+11-(e.bx+e.w/2),dy=p.y+19-(e.by+e.h/2),d=Math.hypot(dx,dy)||1;
  if(d<320){e.bx+=dx/d*48*dt;e.by+=dy/d*30*dt}
  e.bx+=e.kx*dt;e.kx*=Math.pow(.001,dt);
  e.bx=clamp(e.bx,4*T,(G.rm.W-5)*T);e.by=clamp(e.by,3*T,(FY-2)*T);
  e.x=e.bx;e.y=e.by+Math.sin(G.time*2+e.ph)*20;return;
 }
 e.vy=Math.min(880,e.vy+2200*dt);e.kx*=Math.pow(.001,dt);
 const[hx,hy]=mv(e,(e.vx+e.kx)*dt,e.vy*dt,S);
 if(hy)e.vy=0;
 if(e.y>RH*T+10){
  e.dead=1;return;
 }
 if(e.k=='w'){
  if(hx)e.vx*=-1;
  if(hy>0&&!solidAt(S,e.vx>0?e.x+e.w+4:e.x-4,e.y+e.h+6))e.vx*=-1;
 }else{
  e.t-=dt;
  if(hy>0){e.vx*=.8;const dx=p.x-e.x;if(e.t<=0&&Math.abs(dx)<380){e.vy=-560;e.vx=Math.sign(dx)*170;e.t=1+Math.random()*.8;e.salto=G.time}}
  if(hx)e.vx=0;
 }
}
function rest(){
 const R=G.rm;p.hp=p.mhp;p.soul=Math.max(p.soul,33);G.bench.ri=G.ri;
 spawnEnemies(R);G.ban={t:2.2,a:'Marco de descanso',b:'Vida restaurada. Os inimigos voltaram.'};
}
function interactables(){
 const R=G.rm,S=R.st,a=[];
 a.push({x:R.rune.x,y:R.rune.y,t:'Ler runa',f:()=>say('Runa — o Passado',R.E.p,()=>{if(!S.read){S.read=1;G.runes++}})});
 a.push({x:R.extra.x,y:R.extra.y,t:'Ler fragmento',f:()=>say('Fragmento de memória',R.E.x,()=>{if(!S.xr){S.xr=1;G.runes++;G.coins+=15;toast('+15 moedas')}})});
 if(R.bench)a.push({x:R.bench.x,y:R.bench.y,t:'Descansar',f:rest});
 interagiveisTrechos(R,a);
 return a;
}

function camUpdate(snap,dt){
 const R=G.rm;
 const tx=clamp(p.x+11-VW/2+p.f*40,0,Math.max(0,R.W*T-VW)),ty=clamp(p.y-VH/2+40,0,RH*T-VH);
 if(snap){cam.x=tx;cam.y=ty}else{const k=Math.min(1,dt*6);cam.x+=(tx-cam.x)*k;cam.y+=(ty-cam.y)*k}
}

function updPlay(dt,lockIn){
 const R=G.rm,S=R.st;atualizarMoveis(R,dt);G.S=buildSolids(R);const SO=G.S;
 const L=!lockIn&&kd('ArrowLeft','KeyA'),Rt=!lockIn&&kd('ArrowRight','KeyD'),U=!lockIn&&kd('ArrowUp','KeyW','StickUp'),DN=!lockIn&&kd('ArrowDown','KeyS','StickDown');   // StickUp/StickDown: joystick de toque (só direção do golpe, não interage)
 let d=(Rt?1:0)-(L?1:0),locked=!!lockIn;
 if(p.auto>0){p.auto-=dt;d=p.autoD;locked=true}
 p.gT=(p.gT==null?9:p.gT)+dt;if(p.inv>0)p.inv-=dt;if(p.dor>0)p.dor-=dt;if(p.pouso>0)p.pouso-=dt;if(p.asas>0)p.asas-=dt;if(p.atkCd>0)p.atkCd-=dt;if(p.dashCd>0)p.dashCd-=dt;if(p.wallT>0)p.wallT-=dt;
 p.coy=p.g?.14:p.coy-dt;
 p.jb=(!locked&&kp('Space','KeyC'))?.15:p.jb-dt;
 if(!locked&&kp('KeyZ','KeyK','ShiftLeft','ShiftRight','Mouse2')&&p.dashCd<=0&&(p.g||!p.dAir)&&p.heal<=0&&p.dashT<=0){typeof sfx=='function'&&sfx('d');p.dashT=.2;p.dashCd=p.ab.dash?.3:.5;p.inv=Math.max(p.inv,.22);p.atk=0;if(!p.g)p.dAir=true;p.f=d||p.f;burst(p.x+11,p.y+34,6,'#ccc')}
 if(!locked&&kp('KeyX','KeyJ','Mouse0')&&p.atkCd<=0&&p.heal<=0&&p.dashT<=0){p.atk=.2;p.atkCd=Math.max(.22,.34-p.wp*.02);p.up=U;p.dn=DN&&!p.g&&!U;p.hit=[];p.pg=0;p.combo=G.time-(p.tGolpe||-9)<.55?1-(p.combo||0):0;p.tGolpe=G.time;p.gT=0;p.gf=p.f;p.gTipo=p.up?'cima':p.dn?'baixo':p.g?'chao':'ar';typeof sfx=='function'&&sfx('corte')}   // golpes seguidos alternam o corte (de cima / de baixo)
 if(p.dashT>0){p.dashT-=dt;p.vy=0;p.vx=p.f*((p.g?520:600)+(p.ab.dash?60:0))}
 else{
  if(p.wallT<=0){const sp=p.heal>0?0:250;p.vx+=(d*sp-p.vx)*Math.min(1,dt*(p.g?16:9));if(d&&p.heal<=0)p.f=d}
  p.vy=Math.min((p.wall&&p.vy>0)?130:880,p.vy+2200*dt);
 }
 if(p.jb>0&&p.heal<=0&&p.dashT<=0&&!locked){
  if(p.coy>0){typeof sfx=='function'&&sfx('j');p.vy=-740;p.coy=0;p.jb=0;p.dj=1;p.g=false;burst(p.x+11,p.y+38,6,'#ccc')}
  else if(p.wall&&p.ab.wall){typeof sfx=='function'&&sfx('j');p.vy=-720;p.vx=-p.wall*300;p.f=-p.wall;p.wallT=.16;p.wall=0;p.jb=0;p.dj=1}
  else if(p.ab.dj&&p.dj==1){typeof sfx=='function'&&sfx('j');p.vy=-680;p.dj=2;p.jb=0;p.asas=.55;p.pouso=0;penas(p.x+p.w/2-p.f*8,p.y+14)}   // pulo duplo: as asas aparecem e batem
 }
 if(!locked&&!kd('Space','KeyC')&&p.vy<-220&&p.dashT<=0&&!p.pb)p.vy*=.55;
 if(p.vy>=0||p.g)p.pb=0;
 if(!p.g&&p.coy<=0&&p.dj==0)p.dj=1;
 const wantHeal=!locked&&kd('KeyF','KeyH')&&p.soul>=33&&p.hp<p.mhp&&p.g&&Math.abs(p.vx)<30&&p.atk<=0&&p.dashT<=0;
 p.heal=wantHeal?p.heal+dt:0;
 if(p.heal>=.9){p.hp++;p.soul-=33;p.heal=0;burst(p.x+11,p.y+19,16,'#9cf')}
 const estavaNoChao=p.g,quedaVy=p.vy;p.g=false;
 const[hx]=mv(p,p.vx*dt,0,SO);if(hx)p.vx=0;
 const[,hy]=mv(p,0,p.vy*dt,SO);
 if(hy>0){if(!estavaNoChao&&quedaVy>520&&p.atk<=0)p.pouso=.22;p.g=true;p.vy=0;p.dj=0;p.dAir=false;p.asas=Math.min(p.asas,.12)}else if(hy<0)p.vy=0;   // pouso depois de uma queda
 p.wall=0;
 if(!p.g&&p.ab.wall&&p.dashT<=0){
  const a={x:p.x-2,y:p.y+4,w:2,h:p.h-8},b={x:p.x+p.w,y:p.y+4,w:2,h:p.h-8};
  if(d<0&&SO.some(r=>!r[4]&&ovr(a,r)))p.wall=-1;else if(d>0&&SO.some(r=>!r[4]&&ovr(b,r)))p.wall=1;
 }
 if(p.g&&solidAt(SO,p.x-6,p.y+p.h+4)&&solidAt(SO,p.x+p.w+6,p.y+p.h+4)&&!sobreMovel(R,p.x-6,p.y+p.h+4)&&!sobreMovel(R,p.x+p.w+6,p.y+p.h+4)){p.safe.x=p.x;p.safe.y=p.y}
 for(const h of R.haz){if(ov(p,{x:h[0]*T,y:h[1]*T+10,w:h[2]*T,h:h[3]*T})){spikeHit();break}}
 for(const s of R.spk){if(ov(p,s)){spikeHit();break}}
 if(p.y>RH*T+40)spikeHit();
 if(p.atk>0){
  p.atk-=dt;
  if(p.atk<.16&&p.atk>.04){
   const w=SW[p.wp],r=w.r;let hb,bounce=0;
   if(p.up)hb={x:p.x+p.w/2-30,y:p.y-r+8,w:60,h:r+8};
   else if(p.dn)hb={x:p.x+p.w/2-30,y:p.y+p.h-14,w:60,h:r+14};
   else hb={x:p.f>0?p.x+p.w-6:p.x-r+6,y:p.y-2,w:r,h:42};
   for(const e of R.es){
    if(e.dead||(e.k=='B'&&!e.on)||(e.k=='rot'&&!e.chefe.on)||p.hit.includes(e))continue;
    if(ov(hb,e)){p.hit.push(e);
     if(e.k=='B'&&chefeDefende(e,hb)){if(e.inv>0)continue;e.bloq=.35;const dir=p.f;burst(hb.x+(dir>0?hb.w*.2:hb.w*.8),hb.y+hb.h/2,10,'#ffe08a');G.shake=Math.max(G.shake,.1);p.vx-=dir*200;if(!G.avisoEscudo){G.avisoEscudo=1;toast(e.id=='enigma'?'Blindado! Destrua os rotores primeiro':'O escudo bloqueia de frente',2.2)}if(p.dn)bounce=1;continue}
     dmg(e,w.d*(e.k=='B'?multiplicadorChefe(e):1));impacto(clamp(p.x+p.w/2+p.f*30,e.x+4,e.x+e.w-4),clamp(p.y+18,e.y+4,e.y+e.h-4));if(p.dn)bounce=1;else{const dir=p.up?0:p.f;if(e.k!='B'&&e.k!='rot')e.kx=dir*260;p.vx-=dir*70}}
   }
   golpearTrechos(hb);
   if(p.dn)for(const h of R.haz)if(ov(hb,{x:h[0]*T,y:h[1]*T+10,w:h[2]*T,h:h[3]*T}))bounce=1;
   if(p.dn)for(const s of R.spk)if(ov(hb,s))bounce=1;
   if(bounce&&!p.pg){p.pg=1;p.vy=-740;p.pb=1;p.dj=1;p.dAir=false;p.inv=Math.max(p.inv,.2);p.dashCd=0;burst(p.x+11,p.y+p.h,8,'#fff')}
  }
 }
 for(const e of R.es){
  if(e.dead)continue;
  if(e.k=='B')updBoss(e,dt,SO);else if(e.k=='rot')continue;else updEnemy(e,dt,SO);
  if((e.k!='B'||e.on)&&!e.noContact&&!(e.inv>0)&&ov(p,e))hurt(1,(p.x+11<e.x+e.w/2)?-1:1);
 }
 atualizarProjeteis(dt);
 atualizarTrechos(dt);
 if(G.mode=='play')pegarItens();
 if(G.echo&&G.mode=='play'&&G.echo.ri==G.ri){
  if(G.echo.cd>0)G.echo.cd-=dt;
  else if(ov(p,{x:G.echo.x,y:G.echo.y,w:22,h:38})){G.coins+=G.echo.c;G.echo=null;toast('Você recuperou suas moedas')}
 }
 G.near=null;
 if(p.g&&!locked){G.near=interactables().find(o=>Math.abs(p.x+11-o.x)<46&&Math.abs(p.y+p.h-o.y)<30)||null;
  if(G.near&&kp('KeyE','ArrowDown'))G.near.f();}
 const cxp=p.x+p.w/2;
 if(G.mode=='play'){
  if(cxp<0&&G.ri>0)go(G.ri-1,'right');
  else if(cxp>R.W*T){if(G.ri<NR-1)go(G.ri+1,'left');else G.mode='end'}
 }
 camUpdate(0,dt);
}

function update(dt){
 G.time+=dt;
 for(const m of MOTES){m.x+=m.vx*dt;m.y+=m.vy*dt;if(m.y<-5){m.y=VH+5;m.x=Math.random()*VW}if(m.x<-5)m.x=VW+5;if(m.x>VW+5)m.x=-5}
 if(kp('KeyN')&&window.toggleMusic)window.toggleMusic();
 if(kp('KeyV'))trocarEstilo();
 if(G.mode=='title'){if(kp('Enter','Space','KeyE','Mouse0'))startGame();return}
 if(G.mode=='end'){if(kp('KeyR'))restart();return}
 if(kp('KeyR')&&G.mode!='dialog'){restart();return}
 if(G.ban.t>0)G.ban.t-=dt;if(G.toast.t>0)G.toast.t-=dt;if(G.shake>0)G.shake=Math.max(0,G.shake-dt);
 for(const f of G.fx){f.x+=f.vx*dt;f.y+=f.vy*dt;f.vy+=(f.pena?60:600)*dt;if(f.pena)f.vx*=Math.pow(.2,dt);f.t-=dt}G.fx=G.fx.filter(f=>f.t>0);
 if(G.imp){for(const q of G.imp)q.t-=dt;G.imp=G.imp.filter(q=>q.t>0)}
 if(G.mode=='dialog'){
  const d=G.dlg;d.n=Math.min(d.text.length,d.n+dt*60);
  if(kp('KeyE','Enter','Space','KeyX','Mouse0')){
   if(d.n<d.text.length)d.n=d.text.length;
   else{G.mode='play';G.dlg=null;if(d.cb)d.cb()}
  }
  return;
 }
 if(G.mode=='map'){if(kp('KeyM','Escape','KeyE','Mouse0','ControlLeft','ControlRight'))G.mode='play';return}
 if(G.hs>0){G.hs-=dt;G.keep=1;return}
 if(G.mode=='morte'){
  G.morteT-=dt;p.vx=0;p.vy=0;                         // parado no lugar enquanto a animação de morte toca
  if(G.morteT<=0){G.mode='trans';G.fdir=1}
  return;
 }
 if(G.mode=='trans'){
  if(G.fdir>0){
   G.fade=Math.min(1,G.fade+dt/.25);
   if(G.fade>=1){const pd=G.pend;enterRoom(pd.i,pd.how);G.fdir=-1}
  }else{
   G.fade=Math.max(0,G.fade-dt/.4);updPlay(dt,true);
   if(G.fade<=0)G.mode='play';
  }
  return;
 }
 if(G.mode=='play'){
  if(kp('KeyM','ControlLeft','ControlRight')){G.mode='map';return}
  updPlay(dt,false);
 }
}
