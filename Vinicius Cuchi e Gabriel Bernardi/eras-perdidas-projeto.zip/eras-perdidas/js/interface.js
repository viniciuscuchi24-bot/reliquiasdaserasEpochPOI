// ===== Interface: caixa de texto em pergaminho e barra de vida dos chefes =====
// As imagens e medidas ficam em assets/interface (interface.js). Se uma imagem ainda não carregou,
// o jogo desenha a caixa preta simples de antes.

function imgInterface(nome) {
  if (typeof INTERFACE == 'undefined' || !INTERFACE) return null;
  const im = carregarImagem(INTERFACE.pasta + nome);
  return imagemPronta(im) ? im : null;
}

// Desenha o pergaminho com moldura ocupando o retângulo (x, y, w, h), esticando só o meio (9 partes).
// Devolve o espaço interno onde o texto cabe { x, y, w, h, k } ou null se a imagem não carregou.
function caixaPergaminho(x, y, w, h, escala) {
  const C = INTERFACE && INTERFACE.caixa, im = C && imgInterface(C.imagem); if (!im) return null;
  const [me, mc, md, mb] = C.margens, W = im.naturalWidth, H = im.naturalHeight;
  const k = escala || clamp(h / 360, .1, .5);
  const e = me * k, c = mc * k, d = md * k, b = mb * k;
  const sx = [0, me, W - md, W], sy = [0, mc, H - mb, H], dx = [x, x + e, x + w - d, x + w], dy = [y, y + c, y + h - b, y + h];
  g.save(); g.imageSmoothingEnabled = true;
  for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) {
    const ow = dx[i + 1] - dx[i], oh = dy[j + 1] - dy[j]; if (ow <= 0 || oh <= 0) continue;
    g.drawImage(im, sx[i], sy[j], sx[i + 1] - sx[i], sy[j + 1] - sy[j], Math.round(dx[i]), Math.round(dy[j]), Math.ceil(ow) + 1, Math.ceil(oh) + 1);
  }
  g.restore();
  const bx = C.borda[0] * k, by = C.borda[1] * k;
  return { x: x + bx, y: y + by, w: w - 2 * bx, h: h - 2 * by, k };
}
const corTinta = qual => (INTERFACE && INTERFACE.caixa && INTERFACE.caixa[qual]) || '#2a1d12';

// caixa simples (fallback) — a de antes
function caixaPreta(x, y, w, h, a) { g.fillStyle = 'rgba(6,6,10,' + (a || .8) + ')'; g.fillRect(x, y, w, h); }

// Barra de vida do chefe: moldura com arabescos e trepadeiras; a vida aparece no vão.
// A parte perdida some devagar (fica um rastro mais claro), e o nome vai escrito na própria barra.
function barraVidaChefe(b, vida, total) {
  const V = INTERFACE && INTERFACE.vida, mol = V && imgInterface(V.moldura), bar = V && imgInterface(V.barra);
  const frac = clamp(vida / total, 0, 1);
  b.rastro = b.rastro == null ? frac : (b.rastro > frac ? Math.max(frac, b.rastro - .25 * (1 / 60)) : frac);
  if (!mol || !bar) return false;
  const L = V.largura, k = L / mol.naturalWidth, H = mol.naturalHeight * k;
  const [vx0, vy0, vw0, vh0] = V.vao, x = Math.round(VW / 2 - L / 2), y = Math.round(VH - 40 - (vy0 + vh0 / 2) * k);
  const vx = x + vx0 * k, vy = y + vy0 * k, vw = vw0 * k, vh = vh0 * k;
  g.save(); g.imageSmoothingEnabled = true;
  g.fillStyle = 'rgba(18,6,6,.9)'; g.fillRect(vx, vy, vw, vh);
  if (b.rastro > frac) { g.globalAlpha = .55; g.drawImage(bar, 0, 0, bar.naturalWidth * b.rastro, bar.naturalHeight, vx, vy, vw * b.rastro, vh); g.globalAlpha = 1; }
  if (frac > 0) g.drawImage(bar, 0, 0, bar.naturalWidth * frac, bar.naturalHeight, vx, vy, vw * frac, vh);
  if (b.fl > 0) { g.fillStyle = 'rgba(255,240,220,.35)'; g.fillRect(vx, vy, vw * frac, vh); }
  g.drawImage(mol, x, y, L, H);
  g.textAlign = 'center'; g.font = 'italic 15px Georgia,serif';
  g.fillStyle = 'rgba(0,0,0,.75)'; g.fillText(b.name, VW / 2 + 1, vy + vh / 2 + 6);
  g.fillStyle = '#f4ead8'; g.fillText(b.name, VW / 2, vy + vh / 2 + 5);
  g.restore();
  return true;
}
