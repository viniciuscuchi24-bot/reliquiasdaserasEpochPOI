// ===== Tipos de trecho =====
// Cada tipo sabe: gerar o terreno, a regra para vencer (atualizar/golpe/interagir),
// o texto do objetivo, uma dica na primeira vez e o desenho das suas peças.
// Medidas em blocos de 32 px. Chão na linha 15; plataformas nas linhas 12, 9 e 6
// (cada degrau de 3 blocos cabe num pulo normal).

const mecanismoUsavel = (R, s, ss, a, rotulo, pode) => {
  if (ss.done) return;
  a.push({ x: s.mech.x, y: s.mech.y, t: s.ult ? R.E.m : rotulo, f: () => { const msg = pode ? pode() : null; if (msg) toast(msg); else concluirTrecho(s.k); } });
};
const golpeEm = (hb, o, w, h) => ov(hb, { x: o.x - w / 2, y: o.y - h, w, h });

const TRECHOS = {

  // ---------------- saltos: vãos, ilhas, plataforma flutuante e um vão longo (esquiva no ar) ----------------
  saltos: {
    nome: 'Saltos',
    dica: (R, s) => (s.v == 'B' ? 'Pule de pilar em pilar sobre o fosso. ' : s.v == 'C' ? 'Espere a plataforma chegar perto e pule nela: ela leva você sobre o fosso. ' : '') +
      (R.i >= 2 ? 'Vão longo à frente: pule e use a esquiva no ar (Z ou botão direito) para alcançar o outro lado.' : 'Atravesse os vãos e ative a alavanca no fim.'),
    gerar(R, x, rnd, k, v) {
      chao(R, x, x + 4); let c = x + 4;
      const ilha = (gap, w, alta) => { fosso(R, c, c + gap); c += gap; chao(R, c, c + w); if (alta) bloco(R, c, 13, w, 2); c += w; };
      const vaoLongo = () => { if (R.i >= 2) { fosso(R, c, c + 6); c += 6; chao(R, c, c + 4); c += 4; } };
      if (v == 'B') {          // pilares de alturas diferentes saindo do fosso
        const alt = R.i >= 9 ? [13, 12, 11, 10, 12] : [13, 12, 11, 12, 13], a = c;
        let q = c;
        alt.forEach((h, j) => { q += 2 + (j % 2 ? 1 : (rnd() < .5 ? 1 : 0)); bloco(R, q, h, 2, 18 - h); q += 2; });
        q += 3; fosso(R, a, q); c = q; chao(R, c, c + 4); inimigo(R, 'f', a + (q - a) / 2, 8, k); c += 4;
        vaoLongo();
      } else if (v == 'C') {   // plataformas que vão e voltam sobre o fosso
        fosso(R, c, c + 14);
        movel(R, c + 1.5, 13, 3, 2, 0, 4, 0);
        movel(R, c + 8, 12, 3, 2, 0, 4, .5);
        inimigo(R, 'f', c + 7, 8, k); c += 14; chao(R, c, c + 4); c += 4;
        vaoLongo();
        if (R.i >= 9) { fosso(R, c, c + 9); movel(R, c + 3, 12, 3, 0, 1.5, 4, .25); c += 9; chao(R, c, c + 3); c += 3; }
      } else {
        ilha(3 + (R.i > 3 ? 1 : 0), 4, false);
        ilha(4, 3, true);
        fosso(R, c, c + 7); plataforma(R, c + 2, 12, 3); inimigo(R, 'f', c + 3.5, 9, k); c += 7; chao(R, c, c + 4); c += 4;
        vaoLongo();
        if (R.i >= 9) ilha(4, 3, true);
        ilha(4, 3, false);
      }
      chao(R, c, c + 8); inimigo(R, 'w', c + 2, null, k);
      return { x1: c + 8, mech: { x: (c + 4) * T + 16, y: FY * T } };
    },
    interagir(R, s, ss, a) { mecanismoUsavel(R, s, ss, a, 'Alavanca'); },
    objetivo: () => 'Chegue à alavanca do outro lado',
    desenhar(R, s, ss, hu) { desenharMecanismo(s.mech, hu, ss.done); }
  },

  // ---------------- espinhos: fosso inteiro; quique (↓ + golpe no ar) nas estacas ----------------
  espinhos: {
    nome: 'Quique nas estacas',
    dica: (R, s) => (s.v == 'C' ? 'As estacas sobem e descem: espere a hora certa. ' : s.v == 'B' ? 'Estacas em zigue-zague! ' : '') + 'No ar, segure ↓ e golpeie a estaca embaixo de você para quicar. Encostar nela machuca.',
    gerar(R, x, rnd, k, v) {
      chao(R, x, x + 5); const a = x + 5, L = R.i > 8 ? 24 : 20;
      fosso(R, a, a + L);
      let j = 0;
      for (let bx = a + 2.5; bx < a + L - 1.5; bx += 4.5, j++) {
        if (R.i < 6 && j == 2) { bloco(R, Math.floor(bx) - 1, 12, 2, 6); continue; }   // pilar de descanso nas primeiras épocas
        if (v == 'B') estaca(R, bx, j % 2 ? 11.5 : 12.5, k);                            // zigue-zague
        else if (v == 'C') estacaMovel(R, bx, 12, 0, 1, 2, j * .25, k);                  // estacas que sobem e descem
        else estaca(R, bx, 12.5, k);
      }
      if (v == 'B') bloco(R, a + 6, 2, 3, 4);   // rocha pendurada no teto
      if (R.i >= 10) inimigo(R, 'f', a + L / 2, 8, k);
      chao(R, a + L, a + L + 8);
      return { x1: a + L + 8, mech: { x: (a + L + 4) * T + 16, y: FY * T } };
    },
    interagir(R, s, ss, a) { mecanismoUsavel(R, s, ss, a, 'Alavanca'); },
    objetivo: () => 'Atravesse quicando nas estacas',
    desenhar(R, s, ss, hu) { desenharMecanismo(s.mech, hu, ss.done); }
  },

  // ---------------- escalada: torre alta; Asas (pulo duplo) antes de Constantinopla, Garras depois ----------------
  escalada: {
    nome: 'Escalada',
    dica: (R, s) => R.i >= 11 ? (s.v == 'B' ? 'Garras: salte entre a coluna pendurada no teto e a torre. No ar, encoste na parede segurando a direção dela e aperte Pular.' : 'Garras: no ar, encoste na parede segurando a direção dela e aperte Pular para saltar para a outra parede.')
      : (s.v == 'B' ? 'Asas: suba pelos degraus e, do último, aperte Pular de novo no ar para alcançar o alto da torre.' : 'Asas: suba na plataforma e aperte Pular de novo no ar para alcançar o alto da torre.'),
    gerar(R, x, rnd, k, v) {
      chao(R, x, x + 26);
      let mech;
      if (R.i < 11) {
        if (v == 'B') { plataforma(R, x + 3, 12, 3); plataforma(R, x + 8, 9, 3); bloco(R, x + 13, 4, 5, 11); mech = { x: (x + 15.5) * T, y: 4 * T }; }   // degraus e torre
        else { plataforma(R, x + 5, 12, 4); bloco(R, x + 12, 7, 6, 8); mech = { x: (x + 15) * T, y: 7 * T }; }
      } else {
        if (v == 'B') { bloco(R, x + 9, 2, 1, 9); bloco(R, x + 12, 4, 6, 11); mech = { x: (x + 15) * T, y: 4 * T }; }   // coluna pendurada no teto
        else { bloco(R, x + 8, 5, 1, 10); bloco(R, x + 12, 4, 6, 11); mech = { x: (x + 15) * T, y: 4 * T }; }
      }
      inimigo(R, 'w', x + 21, null, k); if (R.i >= 9) inimigo(R, 'f', x + 4, 8, k);
      return { x1: x + 26, mech };
    },
    interagir(R, s, ss, a) { mecanismoUsavel(R, s, ss, a, 'Alavanca'); },
    objetivo: (R) => R.i >= 11 ? 'Escale entre as paredes até o topo da torre' : 'Use o pulo duplo para subir na torre',
    desenhar(R, s, ss, hu) { desenharMecanismo(s.mech, hu, ss.done); }
  },

  // ---------------- alavancas: três alavancas para acertar com a espada ----------------
  alavancas: {
    nome: 'Alavancas',
    dica: (R, s) => s.v == 'B' ? 'Acerte as três alavancas com a espada: uma no chão, uma no alto do patamar e uma pendurada sobre o fosso (pule e golpeie).' : 'Acerte as três alavancas com a espada. Uma está no alto: golpeie para cima (↑ + golpe).',
    gerar(R, x, rnd, k, v) {
      if (v == 'B') {        // uma no chão, uma no alto de um patamar, uma pendurada sobre o fosso
        chao(R, x, x + 12); bloco(R, x + 8, 12, 4, 3); bloco(R, x + 6, 13, 2, 2); fosso(R, x + 12, x + 17); chao(R, x + 17, x + 30);
        plataforma(R, x + 20, 12, 3);
        inimigo(R, 'w', x + 24, null, k); inimigo(R, 'f', x + 21, 9, k); inimigo(R, 'h', x + 3, null, k);
        return { x1: x + 30, alvos: [{ x: (x + 3) * T, y: FY * T }, { x: (x + 10) * T, y: 12 * T }, { x: (x + 14.5) * T, y: 9.5 * T, pendurada: 1 }] };
      }
      chao(R, x, x + 12); fosso(R, x + 12, x + 15); chao(R, x + 15, x + 17); bloco(R, x + 15, 14, 2, 1); fosso(R, x + 17, x + 20); chao(R, x + 20, x + 30);
      plataforma(R, x + 8, 12, 3);
      inimigo(R, 'w', x + 24, null, k); inimigo(R, 'f', x + 16, 10, k);
      return { x1: x + 30, alvos: [{ x: (x + 5) * T, y: FY * T }, { x: (x + 9.5) * T, y: 9.2 * T, pendurada: 1 }, { x: (x + 16) * T, y: 14 * T }] };
    },
    golpe(R, s, ss, hb) {
      if (ss.done) return;
      s.alvos.forEach((o, j) => { if (!ss.on[j] && golpeEm(hb, o, 26, 36)) { ss.on[j] = 1; burst(o.x, o.y - 18, 12, '#ffe08a'); G.shake = .12; const n = ss.on.filter(Boolean).length; if (n >= 3) concluirTrecho(s.k); else toast('Alavanca ' + n + '/3'); } });
    },
    objetivo: (R, s, ss) => 'Acerte as alavancas (' + ss.on.filter(Boolean).length + '/3)',
    desenhar(R, s, ss, hu) {
      s.alvos.forEach((o, j) => {
        const x = o.x - cam.x, y = o.y - cam.y; if (x < -40 || x > VW + 40) return; const on = ss.on[j];
        if (!on) glow(40, x, y - 16, 34, .28, 65);
        if (o.pendurada) {   // corrente do teto + alavanca de cabeça para baixo
          g.fillStyle = '#3a3646'; for (let k = 2 * T - cam.y; k < y - 30; k += 8) { g.fillRect(Math.round(x) - 2, k, 4, 4); g.fillRect(Math.round(x) - 1, k + 4, 2, 4); }
          obj(on ? 'alavanca_ligada' : 'alavanca', x, y, 2, false, true);
        } else obj(on ? 'alavanca_ligada' : 'alavanca', x, y + 2);
      });
    }
  },

  // ---------------- guardiões: derrote todos os inimigos do trecho ----------------
  guardioes: {
    nome: 'Guardiões',
    dica: 'Derrote todos os guardiões deste trecho para abrir o portão.',
    gerar(R, x, rnd, k, v) {
      if (v == 'B') {        // patamar no meio, com degraus e plataforma alta
        chao(R, x, x + 30); bloco(R, x + 10, 12, 10, 3); bloco(R, x + 8, 13, 2, 2); bloco(R, x + 20, 13, 2, 2); plataforma(R, x + 13, 9, 4);
        inimigo(R, 'w', x + 4, null, k); inimigo(R, 'h', x + 12, null, k, 12); inimigo(R, 'w', x + 17, null, k, 12); inimigo(R, 'h', x + 25, null, k); inimigo(R, 'f', x + 15, 6, k);
      } else if (v == 'C') { // fosso no meio com plataforma móvel
        chao(R, x, x + 12); fosso(R, x + 12, x + 18); chao(R, x + 18, x + 30); movel(R, x + 13.5, 13, 3, 1.5, 0, 4, 0);
        plataforma(R, x + 4, 12, 3); plataforma(R, x + 23, 12, 3);
        inimigo(R, 'w', x + 6, null, k); inimigo(R, 'h', x + 9, null, k); inimigo(R, 'w', x + 21, null, k); inimigo(R, 'h', x + 26, null, k); inimigo(R, 'f', x + 15, 9, k);
      } else {
        chao(R, x, x + 13); fosso(R, x + 13, x + 16); chao(R, x + 16, x + 30);
        plataforma(R, x + 5, 12, 4); plataforma(R, x + 20, 12, 4);
        inimigo(R, 'w', x + 6, null, k); inimigo(R, 'h', x + 10, null, k); inimigo(R, 'w', x + 19, null, k); inimigo(R, 'h', x + 24, null, k); inimigo(R, 'f', x + 14.5, 9, k);
      }
      if (R.i >= 9) inimigo(R, 'w', x + 27, null, k);
      if (R.i >= 18) inimigo(R, 'f', x + 22, 8, k);
      return { x1: x + 30 };
    },
    atualizar(R, s, ss) { if (!ss.done && G.mode == 'play' && R.es.length && !R.es.some(e => e.sec == s.k && !e.dead)) concluirTrecho(s.k); },
    objetivo: (R, s) => 'Derrote os guardiões (' + R.es.filter(e => e.sec == s.k && !e.dead).length + ' restantes)'
  },

  // ---------------- fragmentos: três fragmentos na escada de plataformas ----------------
  fragmentos: {
    nome: 'Fragmentos',
    dica: 'Pegue os três fragmentos nas plataformas e leve ao mecanismo.',
    gerar(R, x, rnd, k, v) {
      if (v == 'B') {        // pilares no fosso e plataformas altas
        chao(R, x, x + 8); fosso(R, x + 8, x + 20); chao(R, x + 20, x + 32);
        bloco(R, x + 9, 12, 2, 6); bloco(R, x + 13, 10, 2, 8); bloco(R, x + 17, 12, 2, 6);
        plataforma(R, x + 11, 7, 3); plataforma(R, x + 22, 11, 3); plataforma(R, x + 25, 8, 3);
        inimigo(R, 'f', x + 14, 5, k); inimigo(R, 'w', x + 28, null, k);
        return { x1: x + 32, shards: [{ x: (x + 10) * T, y: 12 * T - 22 }, { x: (x + 12.5) * T, y: 7 * T - 22 }, { x: (x + 26.5) * T, y: 8 * T - 22 }], mech: { x: (x + 29) * T + 16, y: FY * T } };
      }
      chao(R, x, x + 7); fosso(R, x + 7, x + 16); chao(R, x + 16, x + 30);
      const p1 = plataforma(R, x + 4, 12, 4), p2 = plataforma(R, x + 10, 9, 4), p3 = plataforma(R, x + 16, 6, 5);
      plataforma(R, x + 12, 12, 2);   // degrau de volta, para quem caiu do outro lado
      inimigo(R, 'f', x + 13, 6, k); inimigo(R, 'w', x + 22, null, k);
      return { x1: x + 30, stairs: [p1, p2, p3], shards: [{ x: (x + 6) * T, y: 12 * T - 22 }, { x: (x + 12) * T, y: 9 * T - 22 }, { x: (x + 18.5) * T, y: 6 * T - 22 }], mech: { x: (x + 25) * T + 16, y: FY * T } };
    },
    atualizar(R, s, ss) {
      s.shards.forEach((o, j) => { if (!ss.sh[j] && ov(p, { x: o.x - 12, y: o.y - 12, w: 24, h: 24 })) { ss.sh[j] = 1; burst(o.x, o.y, 10, '#8cf'); toast('Fragmento ' + ss.sh.filter(Boolean).length + '/3'); } });
    },
    interagir(R, s, ss, a) { mecanismoUsavel(R, s, ss, a, 'Mecanismo', () => { const c = ss.sh.filter(Boolean).length; return c < 3 ? 'Faltam fragmentos (' + c + '/3) — procure nas alturas' : null; }); },
    objetivo: (R, s, ss) => 'Fragmentos ' + ss.sh.filter(Boolean).length + '/3 — depois ative o mecanismo',
    desenhar(R, s, ss, hu) {
      s.shards.forEach((o, j) => { if (!ss.sh[j]) { const x = o.x - cam.x, y = o.y - cam.y; glow(210, x, y, 38, .35, 72); obj(['fragmento_azul', 'fragmento_ouro', 'fragmento_rosa'][j % 3], x, y + 15 + balanco(j * 2, 6)); } });
      desenharMecanismo(s.mech, hu, ss.done);
    }
  },

  // ---------------- arena: portas fecham e chegam ondas de inimigos ----------------
  arena: {
    nome: 'Arena',
    dica: 'Arena! As portas vão fechar: sobreviva às três ondas.',
    gerar(R, x, rnd, k, v) {
      let livres;   // onde os inimigos de chão podem surgir (em blocos a partir do início do trecho)
      if (v == 'B') { chao(R, x, x + 28); bloco(R, x + 11, 13, 6, 2); plataforma(R, x + 4, 11, 4); plataforma(R, x + 20, 11, 4); plataforma(R, x + 12, 9, 4); livres = [4, 7, 9, 19, 21, 24]; }
      else if (v == 'C') { chao(R, x, x + 9); fosso(R, x + 9, x + 11); chao(R, x + 11, x + 17); fosso(R, x + 17, x + 19); chao(R, x + 19, x + 28); plataforma(R, x + 8, 12, 4); plataforma(R, x + 16, 12, 4); livres = [4, 6, 12, 14, 21, 24]; }
      else { chao(R, x, x + 28); plataforma(R, x + 6, 12, 4); plataforma(R, x + 18, 12, 4); }
      const extra = Math.floor(R.i / 9);
      const ondas = [['w', 'w', 'f'], ['h', 'w', 'f', 'f'], ['h', 'h', 'w', 'f', 'f']];
      for (let q = 0; q < extra; q++) ondas[q % 3].push(q % 2 ? 'f' : 'h');
      return { x1: x + 28, ondas, livres };
    },
    atualizar(R, s, ss, dt) {
      if (ss.done || G.mode != 'play') return;
      if (ss.wave < 0) { if (p.x > (s.x0 + 5) * T && p.x < (s.x1 - 3) * T) { ss.wave = 0; this.onda(R, s, ss); G.ban = { t: 2.2, a: 'Arena', b: 'Onda 1 de ' + s.ondas.length }; } return; }
      if (!R.es.some(e => e.sec == s.k && e.onda && !e.dead)) {
        ss.wave++;
        if (ss.wave >= s.ondas.length) { ss.wave = -2; concluirTrecho(s.k); }
        else { this.onda(R, s, ss); toast('Onda ' + (ss.wave + 1) + ' de ' + s.ondas.length, 2); }
      }
    },
    onda(R, s, ss) {
      s.ondas[ss.wave].forEach((k, j) => {
        const xb = s.x0 + (s.livres && k != 'f' ? s.livres[(j * 2 + ss.wave) % s.livres.length] : 4 + ((j * 7 + ss.wave * 3) % 20));
        const e = mkEnemy({ k, x: xb * T, y: k == 'f' ? (8 + (j % 3)) * T : FY * T - 26, hp: k == 'f' ? Math.max(2, R.hpBase - 1) : R.hpBase });
        e.sec = s.k; e.onda = 1; R.es.push(e); burst(e.x + e.w / 2, e.y + e.h / 2, 14, '#c9b8ff');
      });
    },
    objetivo: (R, s, ss) => ss.wave < 0 ? 'Entre na arena' : 'Onda ' + (ss.wave + 1) + ' de ' + s.ondas.length + ' — ' + R.es.filter(e => e.sec == s.k && e.onda && !e.dead).length + ' inimigos'
  },

  // ---------------- escuro: acenda três braseiros no escuro (a Lanterna ajuda a enxergar) ----------------
  escuro: {
    nome: 'Escuridão',
    escuro: true,
    dica: (R) => 'Está escuro! Acenda os três braseiros golpeando-os.' + (R.i >= 16 ? ' A Lanterna da Razão aumenta sua visão.' : ''),
    gerar(R, x, rnd, k, v) {
      if (v == 'B') {        // braseiros no alto: degraus, patamar e fosso com plataforma móvel
        chao(R, x, x + 9); fosso(R, x + 9, x + 15); chao(R, x + 15, x + 34); movel(R, x + 10.5, 13, 3, 1.5, 0, 4, 0);
        plataforma(R, x + 17, 12, 3); plataforma(R, x + 21, 9, 3); bloco(R, x + 27, 12, 4, 3);
        inimigo(R, 'f', x + 12, 9, k); inimigo(R, 'w', x + 19, null, k); inimigo(R, 'f', x + 29, 8, k);
        return { x1: x + 34, alvos: [{ x: (x + 4) * T, y: FY * T }, { x: (x + 22.5) * T, y: 9 * T }, { x: (x + 29) * T, y: 12 * T }] };
      }
      chao(R, x, x + 12); fosso(R, x + 12, x + 15); chao(R, x + 15, x + 22); fosso(R, x + 22, x + 25); chao(R, x + 25, x + 34);
      plataforma(R, x + 16, 12, 3);
      inimigo(R, 'f', x + 10, 9, k); inimigo(R, 'f', x + 20, 8, k); inimigo(R, 'w', x + 28, null, k);
      return { x1: x + 34, alvos: [{ x: (x + 7) * T, y: FY * T }, { x: (x + 17.5) * T, y: 12 * T }, { x: (x + 29) * T, y: FY * T }] };
    },
    golpe(R, s, ss, hb) {
      if (ss.done) return;
      s.alvos.forEach((o, j) => { if (!ss.lit[j] && golpeEm(hb, o, 30, 40)) { ss.lit[j] = 1; burst(o.x, o.y - 26, 16, '#ffb347'); const n = ss.lit.filter(Boolean).length; if (n >= 3) concluirTrecho(s.k); else toast('Braseiro ' + n + '/3'); } });
    },
    objetivo: (R, s, ss) => 'Acenda os braseiros (' + ss.lit.filter(Boolean).length + '/3)',
    desenhar(R, s, ss, hu) {
      s.alvos.forEach((o, j) => {
        const x = o.x - cam.x, y = o.y - cam.y; if (x < -60 || x > VW + 60) return; const on = ss.lit[j];
        obj('braseiro', x, y + 2);
        if (on) { glow(30, x, y - 34, 72, .55 + .1 * Math.sin(G.time * 9 + j), 60); obj('chama_' + (Math.floor(G.time * 10 + j) % 4), x, y - 18); }
        else { g.fillStyle = 'rgba(255,150,60,' + (.35 + .15 * Math.sin(G.time * 2 + j)) + ')'; g.fillRect(Math.round(x) - 6, Math.round(y) - 22, 12, 2); }
      });
    }
  },

  // ---------------- corrida: a alavanca abre o portão por pouco tempo ----------------
  corrida: {
    nome: 'Corrida',
    dica: 'A alavanca abre o portão do fim por poucos segundos. Corra!',
    gerar(R, x, rnd, k, v) {
      if (v == 'B') {        // obstáculos: degraus, teto baixo e um fosso
        chao(R, x, x + 27); fosso(R, x + 27, x + 31); chao(R, x + 31, x + 38);
        bloco(R, x + 9, 13, 2, 2); bloco(R, x + 15, 12, 2, 3); bloco(R, x + 21, 2, 4, 9);
        inimigo(R, 'f', x + 13, 9, k); inimigo(R, 'w', x + 33, null, k); if (R.i >= 15) inimigo(R, 'h', x + 24, null, k);
        return { x1: x + 38, mech: { x: (x + 3.5) * T, y: FY * T }, tempo: Math.round((38 * T / 250) * 1.35 + 4) };
      }
      chao(R, x, x + 7); fosso(R, x + 7, x + 10); chao(R, x + 10, x + 14); fosso(R, x + 14, x + 18); chao(R, x + 18, x + 22);
      fosso(R, x + 22, x + 25); chao(R, x + 25, x + 36); bloco(R, x + 25, 13, 3, 2);
      inimigo(R, 'f', x + 12, 10, k); inimigo(R, 'w', x + 20, null, k); if (R.i >= 15) inimigo(R, 'h', x + 30, null, k);
      return { x1: x + 36, mech: { x: (x + 3.5) * T, y: FY * T }, tempo: Math.round((36 * T / 250) * 1.35 + 3) };
    },
    interagir(R, s, ss, a) {
      if (ss.done || ss.tm > 0) return;
      a.push({ x: s.mech.x, y: s.mech.y, t: 'Alavanca do portão', f: () => { ss.tm = s.tempo; toast('Corra! O portão fecha em ' + s.tempo + ' s', 2); } });
    },
    atualizar(R, s, ss, dt) {
      if (ss.done || ss.tm <= 0) return;
      ss.tm -= dt;
      if (p.x + p.w > s.gx - 2) { ss.tm = 0; concluirTrecho(s.k); }   // encostou no portão aberto: passou
      else if (ss.tm <= 0) { ss.tm = 0; toast('O portão fechou — volte à alavanca', 3); }
    },
    objetivo: (R, s, ss) => ss.tm > 0 ? 'Corra até o portão: ' + Math.ceil(ss.tm) + ' s' : 'Puxe a alavanca e corra até o portão',
    desenhar(R, s, ss, hu) { desenharMecanismo(s.mech, hu, ss.done || ss.tm > 0); }
  },

  // ---------------- chefe: arena do guardião da época ----------------
  chefe: {
    nome: 'Chefe',
    // cada chefe luta num cenário próprio (desenhado por js/arenas.js)
    gerar(R, x, rnd, k, v) {
      chao(R, x, x + 44);
      const c = CHEFES[R.i], sec = { x1: x + 44, arena: c.id };
      if (c.id == 'legionario') {          // Coliseu: duas sacadas de mármore e uma no alto
        plataforma(R, x + 8, 12, 5); plataforma(R, x + 28, 12, 5); plataforma(R, x + 18, 9, 5);
      } else if (c.id == 'espectro') {     // convés de navio: dois mastros com vergas (plataformas) e velas
        bloco(R, x + 1, 13, 4, 2);         // castelo de proa
        bloco(R, x + 37, 13, 4, 2);        // tombadilho (popa)
        plataforma(R, x + 9, 12, 7); plataforma(R, x + 10.5, 9, 4);
        plataforma(R, x + 27, 12, 7); plataforma(R, x + 28.5, 9, 4);
        sec.mastros = [x + 12.5, x + 30.5]; sec.casco = [x + 1, x + 41];   // o casco vai da proa à popa
      } else if (c.id == 'colosso') {      // fábrica: passarelas de ferro
        plataforma(R, x + 8, 12, 5); plataforma(R, x + 28, 12, 5); plataforma(R, x + 17, 9, 6);
      } else {                             // casamata: vigas de aço
        plataforma(R, x + 8, 12, 5); plataforma(R, x + 30, 12, 4); plataforma(R, x + 19, 9, 4);
      }
      return sec;
    },
    objetivo: (R) => { const b = R.es.find(e => e.k == 'B' && !e.dead); return b ? (b.on ? 'Derrote ' + b.name : 'Avance para enfrentar o guardião') : ''; }
  }
};
