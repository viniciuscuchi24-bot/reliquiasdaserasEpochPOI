#!/usr/bin/env python3
"""
gerar_objetos.py — desenha (em pixel art) os objetos do jogo e salva em assets/objetos/:
  objetos.png  folha com todos os desenhos      objetos.js  onde cada desenho está na folha

Objetos: pedras rúnicas (24 runas do alfabeto Futhark, acesas e apagadas), fragmentos de
cristal (dourado, rosa, azul), moeda rúnica, alavanca, braseiro + chamas, pedestal com
cristal, marco de descanso, altar, portão, estaca flutuante e espinhos de fosso.
Tudo é desenhado em tamanho 1x; o jogo mostra com pixel 2x (mesmo tamanho dos pacotes).
Uso: python3 ferramentas/gerar_objetos.py     (precisa de pillow e numpy)
"""
import os, json, math
import numpy as np
from PIL import Image

AQUI = os.path.dirname(os.path.abspath(__file__))
SAIDA = os.path.join(os.path.dirname(AQUI), 'assets', 'objetos')

def hexc(h, a=255):
    h = h.lstrip('#'); return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)

PEDRA = [hexc(c) for c in ['1c1922', '35303f', '4d4858', '67627a', '86819a', 'a9a4bc']]
FERRO = [hexc(c) for c in ['15151b', '2d2d37', '474754', '6a6a7a', '9898aa', 'c8c8d6']]
MADEIRA = [hexc(c) for c in ['1e120a', '3e2614', '5e3c1e', '82562c', 'a87640']]
FOGO = [hexc(c) for c in ['8a1e0e', 'e2481a', 'ff8a1c', 'ffc93a', 'fff2b0']]
GEMAS = {
    'ouro': [hexc(c) for c in ['2a140a', '8a3a10', 'd8661c', 'ffa92a', 'ffd84a', 'fff6c0']],
    'rosa': [hexc(c) for c in ['2a0a1e', '6a1648', 'b02a6e', 'e2509a', 'ff8ec0', 'ffe0f0']],
    'azul': [hexc(c) for c in ['0a1a30', '14407a', '1f72c4', '3aa8ff', '8ad8ff', 'e8fbff']],
    'verde': [hexc(c) for c in ['0a2214', '145a2c', '1f9446', '3ad06a', '9af0b0', 'eafff0']],
    'ciano': [hexc(c) for c in ['08202a', '125a6e', '1d9ab4', '40d4f0', '9ff0ff', 'eaffff']]}
BRILHO = hexc('7fe6ff'); BRILHO2 = hexc('d6fbff'); ENTALHE = hexc('201c28'); ENTALHE2 = hexc('8a849a')

def tela(w, h): return np.zeros((h, w, 4), np.uint8)
def px(a, x, y, c):
    if 0 <= x < a.shape[1] and 0 <= y < a.shape[0]: a[y, x] = c
def linha(a, x0, y0, x1, y1, c):
    dx, dy = abs(x1 - x0), -abs(y1 - y0); sx = 1 if x0 < x1 else -1; sy = 1 if y0 < y1 else -1; e = dx + dy
    while True:
        px(a, x0, y0, c)
        if x0 == x1 and y0 == y1: break
        e2 = 2 * e
        if e2 >= dy: e += dy; x0 += sx
        if e2 <= dx: e += dx; y0 += sy
def contorno(a, c):
    m = a[..., 3] > 0; h, w = m.shape; o = a.copy()
    for y in range(h):
        for x in range(w):
            if not m[y, x] and any(0 <= y + dy < h and 0 <= x + dx < w and m[y + dy, x + dx] for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))):
                o[y, x] = c
    return o
def sombrear(mask, pal, luz=(-0.7, -0.7), ruido=0.0, seed=1):
    """preenche a máscara com a paleta (escuro->claro) usando a distância à borda e uma luz no canto"""
    h, w = mask.shape; a = tela(w, h); rng = np.random.default_rng(seed)
    ys, xs = np.nonzero(mask); cx, cy = xs.mean(), ys.mean()
    from scipy import ndimage as nd
    dist = nd.distance_transform_edt(mask)
    for y, x in zip(ys, xs):
        v = .35 + .18 * min(dist[y, x], 4) / 4 + .45 * ((x - cx) * luz[0] + (y - cy) * luz[1]) / max(w, h) + ruido * (rng.random() - .5)
        k = int(np.clip(v * (len(pal) - 1) + .5, 1, len(pal) - 1))
        a[y, x] = pal[k]
    return a

# ---------------- runas (Futhark antigo) em grade 7x11 ----------------
RUNAS = {
 'fehu': [(1,0,1,10),(1,3,5,0),(1,6,5,3)], 'uruz': [(1,10,1,1),(1,1,5,4),(5,4,5,10)], 'thurisaz': [(1,0,1,10),(1,3,4,5),(4,5,1,7)],
 'ansuz': [(1,0,1,10),(1,1,5,4),(1,4,5,7)], 'raidho': [(1,0,1,10),(1,0,5,2),(5,2,1,5),(1,5,5,10)], 'kaunan': [(5,1,1,5),(1,5,5,9)],
 'gebo': [(0,1,6,9),(6,1,0,9)], 'wunjo': [(1,0,1,10),(1,0,5,2),(5,2,1,5)], 'hagalaz': [(1,0,1,10),(5,0,5,10),(1,3,5,7)],
 'naudiz': [(3,0,3,10),(1,4,5,6)], 'isaz': [(3,0,3,10)], 'jera': [(3,0,0,3),(0,3,3,6),(3,4,6,7),(6,7,3,10)],
 'eiwaz': [(3,0,3,10),(3,0,5,2),(3,10,1,8)], 'pertho': [(1,0,1,10),(1,0,5,3),(1,10,5,7)], 'algiz': [(3,0,3,10),(3,4,0,1),(3,4,6,1)],
 'sowilo': [(5,0,1,4),(1,4,5,6),(5,6,1,10)], 'tiwaz': [(3,0,3,10),(3,0,0,3),(3,0,6,3)],
 'berkanan': [(1,0,1,10),(1,0,5,2),(5,2,1,5),(1,5,5,8),(5,8,1,10)], 'ehwaz': [(1,0,1,10),(5,0,5,10),(1,0,3,3),(3,3,5,0)],
 'mannaz': [(1,0,1,10),(5,0,5,10),(1,0,5,5),(5,0,1,5)], 'laguz': [(1,0,1,10),(1,0,5,3)],
 'ingwaz': [(3,2,6,5),(6,5,3,8),(3,8,0,5),(0,5,3,2)], 'othala': [(3,0,6,3),(6,3,3,6),(3,6,0,3),(0,3,3,0),(2,5,0,10),(4,5,6,10)],
 'dagaz': [(0,0,6,10),(6,0,0,10),(0,0,0,10),(6,0,6,10)]}
NOMES_RUNAS = list(RUNAS)

def forma_pedra(w, h, seed):
    rng = np.random.default_rng(seed); m = np.zeros((h, w), bool)
    pts = []
    for k in range(14):
        ang = k / 14 * 2 * math.pi; r = 1 + .12 * (rng.random() - .5)
        pts.append((w / 2 - .5 + math.cos(ang) * (w / 2 - 1) * r, h / 2 - .5 + math.sin(ang) * (h / 2 - 1) * r * (1.04 if math.sin(ang) > 0 else .98)))
    from PIL import ImageDraw
    im = Image.new('L', (w, h), 0); ImageDraw.Draw(im).polygon(pts, fill=1); m = np.asarray(im) > 0
    return m

def pedra_runica(nome, acesa, seed):
    w, h = 18, 26; m = forma_pedra(w - 2, h - 2, seed); mm = np.zeros((h, w), bool); mm[1:-1, 1:-1] = m
    a = sombrear(mm, PEDRA[1:], ruido=.25, seed=seed)
    # rachaduras e manchas
    rng = np.random.default_rng(seed + 9)
    for _ in range(3):
        x, y = int(rng.integers(4, w - 4)), int(rng.integers(5, h - 5))
        if mm[y, x]: px(a, x, y, PEDRA[1])
    ox, oy = 5, 7
    for (x0, y0, x1, y1) in RUNAS[nome]:
        if acesa:
            linha(a, ox + x0, oy + y0, ox + x1, oy + y1, BRILHO)
        else:
            linha(a, ox + x0 + 1, oy + y0 + 1, ox + x1 + 1, oy + y1 + 1, ENTALHE2)   # luz na borda do entalhe
            linha(a, ox + x0, oy + y0, ox + x1, oy + y1, ENTALHE)
    if acesa:   # halo
        g = a.copy()
        for y in range(h):
            for x in range(w):
                if tuple(a[y, x]) == BRILHO:
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        xx, yy = x + dx, y + dy
                        if 0 <= xx < w and 0 <= yy < h and mm[yy, xx] and tuple(a[yy, xx]) != BRILHO: g[yy, xx] = hexc('4fb6cf')
        a = g
        for (x0, y0, x1, y1) in RUNAS[nome][:1]: px(a, ox + x0, oy + y0, BRILHO2)
    return contorno(a, PEDRA[0])

def gema(cor, w=11, h=15, seed=3):
    pal = GEMAS[cor]; from PIL import ImageDraw
    im = Image.new('L', (w, h), 0); ImageDraw.Draw(im).polygon([(w // 2, 0), (w - 1, h // 3), (w - 2, h - 4), (w // 2, h - 1), (1, h - 4), (0, h // 3)], fill=1)
    m = np.asarray(im) > 0; a = tela(w, h); cx = w // 2
    for y in range(h):
        for x in range(w):
            if not m[y, x]: continue
            if x < cx: k = 4 if y < h // 3 else 3
            elif x == cx: k = 3 if y < h // 2 else 2
            else: k = 2 if y < h // 3 else 1
            a[y, x] = pal[k + 0]
    px(a, cx - 2, 3, pal[5]); px(a, cx - 2, 4, pal[5]); px(a, cx - 1, 2, pal[5])
    linha(a, cx, 1, cx, h - 2, pal[3])
    return contorno(a, pal[0])

def moeda_runica(seed=5):
    w = h = 16; from PIL import ImageDraw
    im = Image.new('L', (w, h), 0); ImageDraw.Draw(im).ellipse((1, 1, w - 2, h - 2), fill=1); m = np.asarray(im) > 0
    a = sombrear(m, GEMAS['ouro'][1:], luz=(-.8, -.8), ruido=.15, seed=seed)
    for (x0, y0, x1, y1) in RUNAS['sowilo']: linha(a, 4 + x0, 3 + y0 // 1, 4 + x1, 3 + y1, hexc('7a1e3a'))
    return contorno(a, GEMAS['ouro'][0])

def de_ascii(linhas, pal):
    h = len(linhas); w = max(len(l) for l in linhas); a = tela(w, h)
    for y, l in enumerate(linhas):
        for x, ch in enumerate(l):
            if ch in pal: a[y, x] = pal[ch]
    return a

def alavanca(ligada):
    P = {'o': FERRO[0], 'd': FERRO[1], 'm': FERRO[2], 'l': FERRO[3], 'h': FERRO[4], 'w': MADEIRA[2], 'W': MADEIRA[3]}
    g = GEMAS['verde' if ligada else 'ouro']; P.update({'1': g[2], '2': g[3], '3': g[5]})
    cabo_esq = ['  o11o        ', ' o1231o       ', ' o1121o       ', '  o11ow       ', '     oWw      ', '      oWw     ', '       oWw    ', '        oWw   ']
    cabo = cabo_esq if not ligada else [l[::-1] for l in cabo_esq]
    base = ['    oooooo    ', '   ohhhhhho   ', '  ollllllllo  ', '  ommmmmmmmo  ', '  odddddddddo ', '  oooooooooo  ']
    return de_ascii(cabo + base, P)

def braseiro():
    P = {'o': FERRO[0], 'd': FERRO[1], 'm': FERRO[2], 'l': FERRO[3], 'h': FERRO[4], 'c': hexc('2a1a14'), 'e': hexc('5a2a14')}
    return de_ascii([
        'oooooooooooooooo',
        'ohhhhhhhhhhhhhho',
        'olcecceccecceclo',
        ' olllllllllllll ',
        '  ommmmmmmmmmo  ',
        '   odddddddddo  ',
        '     odddddo    ',
        '      odmdo     ',
        '      odmdo     ',
        '      odmdo     ',
        '     oddmddo    ',
        '    ommmmmmmo   ',
        '   oooooooooo   '], P)

def chama(k):
    rng = np.random.default_rng(40 + k); w, h = 12, 16; a = tela(w, h)
    for y in range(h):
        larg = (y / h) ** .8 * 5.2 * (1 + .25 * math.sin(k * 1.7 + y * .9))
        c = w / 2 - .5 + math.sin(y * .7 + k * 2.1) * (1 - y / h) * 1.5
        for x in range(w):
            d = abs(x - c)
            if d <= larg:
                f = 1 - d / (larg + .01); t = y / h
                lvl = 4 if (f > .7 and t > .55) else 3 if f > .45 else 2 if f > .2 else 1
                if t < .25 and lvl > 2: lvl = 2
                a[y, x] = FOGO[lvl]
    return a

def pedestal(w=20, h=12):
    m = np.zeros((h, w), bool); m[2:, 1:w - 1] = True; m[0:3, 3:w - 3] = True
    a = sombrear(m, PEDRA[1:], luz=(-.5, -.9), ruido=.15, seed=11)
    linha(a, 2, 4, w - 3, 4, PEDRA[4]); linha(a, 2, h - 3, w - 3, h - 3, PEDRA[1])
    return contorno(a, PEDRA[0])

def cristal(cor):
    pal = GEMAS[cor]; w, h = 10, 16; from PIL import ImageDraw
    im = Image.new('L', (w, h), 0); ImageDraw.Draw(im).polygon([(5, 0), (9, 5), (7, 15), (2, 15), (0, 5)], fill=1); m = np.asarray(im) > 0
    a = tela(w, h)
    for y in range(h):
        for x in range(w):
            if m[y, x]: a[y, x] = pal[4 if x < 4 else 3 if x < 6 else 2]
    linha(a, 2, 4, 3, 10, pal[5]); return contorno(a, pal[0])

def marco():
    P = {'o': PEDRA[0], 'd': PEDRA[1], 'm': PEDRA[2], 'l': PEDRA[3], 'h': PEDRA[4], 'w': PEDRA[5]}
    return de_ascii([
        ' oooooooooooooooooooooooooo ',
        'ohwhhhhhhhhhhhhhhhhhhhhhhhho',
        'ollllllllllllllllllllllllllo',
        'ommmmmmmmmmmmmmmmmmmmmmmmmmo',
        ' oooooooooooooooooooooooooo ',
        '   oddo              oddo   ',
        '   omdo              omdo   ',
        '   omdo              omdo   ',
        '  ommddo            ommddo  ',
        '  oooooo            oooooo  '], P)

def lampiao():
    P = {'o': FERRO[0], 'd': FERRO[1], 'm': FERRO[2], 'l': FERRO[3], 'y': FOGO[4], 'Y': FOGO[3], 'r': FOGO[2]}
    topo = ['  ooooo  ', ' odddddo ', 'oolllllo ', 'olyYYYlo ', 'olYyyYlo ', 'olYyrYlo ', 'olyYYYlo ', 'oolllllo ', ' oddddo  ', '   oo    ']
    haste = ['   om    '] * 26 + ['  ommo   ', ' ommmmo  ', ' oooooo  ']
    return de_ascii(topo + haste, P)

def portao():
    P = {'o': FERRO[0], 'd': FERRO[1], 'm': FERRO[2], 'l': FERRO[3], 'h': FERRO[4]}
    return de_ascii([
        'oo  oo  oo  oo  ',
        'ml  ml  ml  ml  ',
        'ml  ml  ml  ml  ',
        'ml  ml  ml  ml  ',
        'ml  ml  ml  ml  ',
        'ml  ml  ml  ml  ',
        'oooooooooooooooo',
        'hhhhhhhhhhhhhhhh',
        'dddddddddddddddd',
        'oooooooooooooooo',
        'ml  ml  ml  ml  ',
        'ml  ml  ml  ml  ',
        'ml  ml  ml  ml  ',
        'ml  ml  ml  ml  ',
        'ml  ml  ml  ml  ',
        'oo  oo  oo  oo  '], P)

def portao_ponta():
    P = {'o': FERRO[0], 'd': FERRO[1], 'm': FERRO[2], 'l': FERRO[3], 'h': FERRO[4]}
    return de_ascii([
        'ml  ml  ml  ml  ', 'ml  ml  ml  ml  ', 'ml  ml  ml  ml  ', 'hl  hl  hl  hl  ', 'mh  mh  mh  mh  ', 'oh  oh  oh  oh  ', ' o   o   o   o  '], P)

def estaca():
    w = h = 18; a = tela(w, h); c = 8.5
    for k in range(8):
        ang = k * math.pi / 4
        for r in range(6, 9):
            px(a, int(round(c + math.cos(ang) * r)), int(round(c + math.sin(ang) * r)), FERRO[4] if r == 8 else FERRO[3])
    from PIL import ImageDraw
    im = Image.new('L', (w, h), 0); ImageDraw.Draw(im).ellipse((3, 3, 14, 14), fill=1); m = np.asarray(im) > 0
    b = sombrear(m, FERRO[1:], luz=(-.8, -.8), seed=2)
    a[m] = b[m]; px(a, 6, 6, FERRO[5]); px(a, 7, 6, FERRO[5])
    return contorno(a, FERRO[0])

def espinhos(tipo):
    w, h = 16, 14; a = tela(w, h)
    if tipo == 'ferro':   # pontas de lança (combina com a cerca do cemitério)
        P = {'o': FERRO[0], 'd': FERRO[1], 'm': FERRO[2], 'l': FERRO[3], 'h': FERRO[4], 'w': FERRO[5]}
        return de_ascii([
            '   o       o    ', '  owo     owo   ', '  ohl     ohl   ', ' ohlmo   ohlmo  ', ' ohlmo   ohlmo  ', ' ohmmo   ohmmo  ',
            '  odo     odo   ', '  odo  o  odo  o', '  odo owo odo ow', '  odo ohl odo oh', '  odo odo odo od', '  odo odo odo od', 'oooooooooooooooo', 'dddddddddddddddd'], P)
    # espinhos de pedra roxa com pontas alaranjadas (combina com o musgo do pântano)
    pal = [hexc(c) for c in ['15101c', '2a2034', '43365a', '6a5684', 'd06a2c', 'ffb05a']]
    P = {'o': pal[0], 'd': pal[1], 'm': pal[2], 'l': pal[3], 'r': pal[4], 'y': pal[5]}
    return de_ascii([
        '   y        y   ', '   r       or   ', '  oro      orr  ', '  olmo    oldmo ', '  olmo  y olmmo ', ' olmmo  r olmdo ', ' olmdo ormolmdo ',
        ' oldmoolmdoldmdo', 'olmdmoolmdolmddo', 'olmddolmddolmddo', 'olddddlmddolddd ', 'oddddddddddddddo', 'oooooooooooooooo', 'dddddddddddddddd'], P)

# ---------------- montagem da folha ----------------
def main():
    os.makedirs(SAIDA, exist_ok=True)
    itens = []
    for j, n in enumerate(NOMES_RUNAS):
        itens.append(('runa_' + n, pedra_runica(n, True, 30 + j)))
        itens.append(('runa_' + n + '_apagada', pedra_runica(n, False, 30 + j)))
    for c in ('ouro', 'rosa', 'azul'): itens.append(('fragmento_' + c, gema(c)))
    itens += [('moeda_runica', moeda_runica()), ('alavanca', alavanca(False)), ('alavanca_ligada', alavanca(True)), ('braseiro', braseiro())]
    for k in range(4): itens.append(('chama_%d' % k, chama(k)))
    itens += [('pedestal', pedestal()), ('cristal', cristal('ciano')), ('cristal_feito', cristal('verde')), ('marco', marco()), ('lampiao', lampiao()),
              ('portao', portao()), ('portao_ponta', portao_ponta()), ('estaca', estaca()), ('espinhos_pantano', espinhos('pedra')), ('espinhos_cemiterio', espinhos('ferro')),
              ('orbe', gema('azul', 9, 9))]
    # empacota em linhas
    W = 256; x = y = alt = 0; pos = {}
    for nome, a in itens:
        h, w = a.shape[:2]
        if x + w > W: x = 0; y += alt + 1; alt = 0
        pos[nome] = [x, y, w, h]; x += w + 1; alt = max(alt, h)
    folha = Image.new('RGBA', (W, y + alt + 1))
    for nome, a in itens:
        folha.alpha_composite(Image.fromarray(a), (pos[nome][0], pos[nome][1]))
    folha.save(os.path.join(SAIDA, 'objetos.png'))
    js = ('// gerado por ferramentas/gerar_objetos.py — recortes [x, y, largura, altura] de objetos.png (desenho em 1x, o jogo mostra em 2x)\n'
          'const OBJETOS = { imagem: \'assets/objetos/objetos.png\', escala: 2, runas: ' + json.dumps(NOMES_RUNAS) + ',\n  r: ' +
          json.dumps(pos, separators=(',', ':')).replace('],"', '],\n    "') + ' };\n')
    open(os.path.join(SAIDA, 'objetos.js'), 'w').write(js)
    print('ok', len(itens), 'desenhos', folha.size)

if __name__ == '__main__':
    main()
