#!/usr/bin/env python3
"""
montar_cenarios.py — gera o FUNDO de cada época para cada estilo do jogo.

Cada fundo mistura uma FOTO REAL da época (ferramentas/fotos/01.jpg … 28.jpg, do Wikimedia
Commons — créditos em fotos/creditos.json) com o céu e as camadas de fundo do estilo:

  1. o céu e as camadas distantes do estilo (assets/estilos/<estilo>/imagens) ocupam a tela
  2. a foto é recortada e encaixada no centro, encostada no chão
  3. o céu da foto é removido (detecção automática) para aparecer o céu do estilo
  4. a foto recebe a luz do estilo (tarde pastel no pântano, luar no cemitério),
     é pixelizada (pixel 2x2) e tem as cores puxadas para a paleta do pacote
  5. uma névoa leve é aplicada embaixo

Saída: assets/estilos/<estilo>/fundos/eN.webp (N = 0..27), 1536x540.
As camadas da frente (cogumelos, cipós, colinas, arbustos) NÃO entram aqui: o jogo desenha
essas camadas por cima, com parallax, a partir do arquivo assets/estilos/<estilo>/estilo.js.

Precisa de: pip install pillow numpy scipy
Uso:  python3 ferramentas/montar_cenarios.py                  todas as épocas, os dois estilos
      python3 ferramentas/montar_cenarios.py 4 6              só as épocas de índice 4 e 6
      python3 ferramentas/montar_cenarios.py --estilo cemiterio
Ajustes finos por época (recorte, zoom, altura): tabela ERAS abaixo ou fotos/ajustes.json
"""
import os, sys, json
import numpy as np
from PIL import Image
from scipy import ndimage as nd

AQUI = os.path.dirname(os.path.abspath(__file__))
W, H, PX = 1536, 540, 2                      # tamanho do cenário e tamanho do "pixel" da foto
GW, GH = W // PX, H // PX                    # grade da foto (768 x 270)
RAIZ = os.path.dirname(AQUI)                            # pasta do jogo
P1 = os.path.join(RAIZ, 'assets/estilos/pantano/imagens/')
P2 = os.path.join(RAIZ, 'assets/estilos/cemiterio/imagens/')
FOTOS = os.path.join(AQUI, 'fotos')
SAIDA = os.path.join(RAIZ, 'assets/estilos')

# ---------------------------------------------------------------------------
# Ajustes por época
#   modo   : 'encaixe' (foto inteira no centro, laterais com o ambiente do pacote)
#            'cheio'   (foto ocupa a largura toda — cavernas, multidões, paredes)
#   cx, cy : centro do recorte na foto (0..1)      zoom : >1 aproxima
#   altura : altura da foto no cenário (0..1 da tela)
#   x      : deslocamento horizontal do centro (-0.5..0.5)
#   ceu    : 'auto' | 'nao' (sem céu) | número 0..1 (linha do horizonte na foto)
#   quente : 0..1 quanto da cor original da foto fica (deserto, pedra dourada)
#   largura: largura da foto no cenário (0..1)     textura: tolerância da detecção do céu (nuvens)
# ---------------------------------------------------------------------------
ERAS = [
 dict(nome='Paleolítico',              modo='cheio', ceu='nao', quente=.75, cy=.45),
 dict(nome='Neolítico',                largura=.75, quente=.35),
 dict(nome='Idade dos Metais',         altura=.86, zoom=1.15, cy=.55, quente=.45),
 dict(nome='Escrita na Mesopotâmia',   altura=.86, zoom=1.5, cy=.33, quente=.65),
 dict(nome='Civilizações do Nilo',     altura=.9, zoom=1.15, cy=.55, quente=.7),
 dict(nome='Grécia Antiga',            largura=.8, quente=.5),
 dict(nome='Roma Antiga',              largura=.78, quente=.5),
 dict(nome='Feudalismo',               altura=.92, quente=.4),
 dict(nome='Expansão Islâmica',        x=-.06, quente=.6, textura=.06),
 dict(nome='Cruzadas',                 altura=.8, zoom=1.35, cx=.6, cy=.45, quente=.55),
 dict(nome='Peste Negra',              modo='cheio', ceu='nao', quente=.3, cy=.45),
 dict(nome='Queda de Constantinopla',  altura=.86, quente=.5),
 dict(nome='Renascimento',             altura=.92, zoom=1.1, quente=.5),
 dict(nome='Grandes Navegações',       altura=.95, quente=.45),
 dict(nome='Reforma Protestante',      largura=.7, quente=.55),
 dict(nome='Absolutismo',              largura=.82, zoom=1.15, cy=.45, quente=.5),
 dict(nome='Iluminismo',               altura=.95, quente=.5),
 dict(nome='Revolução Francesa',       altura=.85, zoom=1.2, cy=.42, quente=.45),
 dict(nome='Era Napoleônica',          altura=.95, quente=.55),
 dict(nome='Independência das Américas', largura=.55, altura=.95, quente=.55),
 dict(nome='Revolução Industrial',     altura=.88, quente=.45),
 dict(nome='Primavera dos Povos',      altura=.92, quente=.45),
 dict(nome='Neocolonialismo',          altura=.92, quente=.6),
 dict(nome='Primeira Guerra',          modo='cheio', quente=.3, cy=.55),
 dict(nome='Revolução Russa',          largura=.92, quente=.45),
 dict(nome='Crise de 1929',            modo='cheio', ceu='nao', quente=.3, cy=.5),
 dict(nome='Totalitarismo',            altura=.95, quente=.3),
 dict(nome='Segunda Guerra',           altura=.88, zoom=1.1, cy=.6, quente=.35),
]
AJUSTES = os.path.join(FOTOS, 'ajustes.json')   # opcional: {"4": {"zoom": 1.3}, ...}
if os.path.exists(AJUSTES):
    for k, v in json.load(open(AJUSTES)).items():
        ERAS[int(k)].update(v)

# ------------------------------------------------------------------ utilidades
def rgba(path):
    return Image.open(path).convert('RGBA')

def arr(im):
    return np.asarray(im).astype(np.float32) / 255.0

def img(a):
    return Image.fromarray((np.clip(a, 0, 1) * 255 + .5).astype(np.uint8))

def nearest(im, sc):
    """Escala pixel art sem borrar."""
    return im.resize((max(1, round(im.width * sc)), max(1, round(im.height * sc))), Image.NEAREST)

def lum(a):
    return a[..., 0] * .3 + a[..., 1] * .59 + a[..., 2] * .11

def tile_x(layer, width):
    """Repete uma camada na horizontal (espelhando) até cobrir 'width'."""
    out = Image.new('RGBA', (width, layer.height))
    x, k = 0, 0
    while x < width:
        t = layer if k % 2 == 0 else layer.transpose(Image.FLIP_LEFT_RIGHT)
        out.alpha_composite(t, (x, 0)); x += layer.width; k += 1
    return out

def recortar(foto, cfg, alvo_w, alvo_h):
    """Recorta a foto (zoom em torno de cx, cy) e escala para alvo_w x alvo_h (cobrindo)."""
    iw, ih = foto.size
    s = max(alvo_w / iw, alvo_h / ih) * cfg.get('zoom', 1.0)
    cw, ch = min(iw, alvo_w / s), min(ih, alvo_h / s)
    cx, cy = cfg.get('cx', .5), cfg.get('cy', .5)
    x0 = max(0, min(cx * iw - cw / 2, iw - cw))
    y0 = max(0, min(cy * ih - ch / 2, ih - ch))
    return foto.resize((alvo_w, alvo_h), Image.LANCZOS, box=(x0, y0, x0 + cw, y0 + ch))

# ------------------------------------------------------------------ céu
def mascara_ceu(foto, modo, tex_max=.025):
    """Máscara 0..1 do céu da foto (1 = céu)."""
    a = arr(foto.convert('RGB'))
    h, w = a.shape[:2]
    if modo == 'nao':
        return np.zeros((h, w), np.float32)
    if isinstance(modo, (int, float)):
        m = np.zeros((h, w), np.float32); m[:int(h * modo)] = 1
        return m
    L = lum(a)
    r, g, b = a[..., 0], a[..., 1], a[..., 2]
    mx, mn = a.max(-1), a.min(-1)
    sat = (mx - mn) / (mx + 1e-4)
    gy, gx = np.gradient(nd.gaussian_filter(L, 1.0))
    tex = nd.gaussian_filter(np.hypot(gx, gy), 1.5)
    azul = (b >= r - .02) & (b >= g - .07)
    cinza = sat < .14
    cand = (((L > .40) & (azul | cinza)) | ((L > .26) & azul & (sat > .25))) & (tex < tex_max)
    cand = nd.binary_opening(cand, iterations=1)
    lab, n = nd.label(cand)
    topo = set(np.unique(lab[:max(2, h // 30)])) - {0}
    m = np.isin(lab, list(topo))
    m &= (np.arange(h)[:, None] < h * .8)
    m = nd.binary_closing(m, iterations=3)
    m = nd.binary_fill_holes(m)
    m[:4] |= m[4]                                     # borda de cima da foto
    m = nd.binary_dilation(m, iterations=2)           # evita contorno claro de céu nas bordas
    return nd.gaussian_filter(m.astype(np.float32), .7)

# ------------------------------------------------------------------ paletas
def paleta_pacote(paths, n):
    big = []
    for p in paths:
        a = np.asarray(rgba(p))
        px = a[a[..., 3] > 200][:, :3]
        if len(px): big.append(px)
    px = np.concatenate(big)
    if len(px) > 200000:
        px = px[np.random.default_rng(1).choice(len(px), 200000, replace=False)]
    q = Image.fromarray(px.reshape(1, -1, 3)).quantize(n, method=Image.MEDIANCUT)
    return np.array(q.getpalette()[:n * 3]).reshape(-1, 3) / 255.0

def reduzir_cores(a, pal_pacote, n_foto=20, puxa=.4):
    """Paleta da própria foto, puxada em direção à paleta do pacote; sem pontilhado."""
    q = img(a[..., :3]).quantize(n_foto, method=Image.MEDIANCUT, dither=Image.Dither.NONE)
    fp = np.array(q.getpalette()[:n_foto * 3]).reshape(-1, 3) / 255.0
    d = ((fp[:, None, :] - pal_pacote[None, :, :]) ** 2).sum(-1)
    novo = fp * (1 - puxa) + pal_pacote[d.argmin(1)] * puxa
    return novo[np.asarray(q)]

# ------------------------------------------------------------------ estilos
class Pantano:
    nome = 'pantano'
    def __init__(self):
        self.pal = paleta_pacote([P1 + 'terreno_e_objetos.png', P1 + 'fundo_1.png', P1 + 'fundo_2.png'], 28)
        bg3 = rgba(P1 + 'fundo_3.png')
        amb = nearest(bg3, H / bg3.height).crop((0, 0, W, H))
        b2 = rgba(P1 + 'fundo_2.png')                   # usa as partes sem o tronco gigante
        e, d = b2.crop((0, 0, 640, b2.height)), b2.crop((930, 0, b2.width, b2.height))
        junto = Image.new('RGBA', (e.width + d.width, b2.height)); junto.alpha_composite(e, (0, 0)); junto.alpha_composite(d, (e.width, 0))
        longe = tile_x(nearest(junto, 1.4), W)
        amb.alpha_composite(longe, (0, H - longe.height + 30))
        v = np.zeros((H, W, 4), np.float32); v[..., :3] = [.55, .5, .7]; v[..., 3] = .16
        amb.alpha_composite(img(v))                      # véu lilás no céu do pacote
        self.amb = amb

    def luz(self, a, quente):
        """Tarde pastel: sombras roxas, luzes lilás e um pouco de névoa embaixo."""
        L = lum(a)[..., None]
        roxo = np.array([.36, .30, .52]); lilas = np.array([.92, .86, .95])
        tint = roxo * (1 - L) + lilas * L
        a = (a - .5) * 1.12 + .5
        a = a * (.62 + .22 * quente) + tint * L * (.38 - .22 * quente) + roxo * .04
        y = np.linspace(0, 1, a.shape[0])[:, None, None]
        nevoa = np.array([.62, .62, .78])
        return a * (1 - .04 - .1 * y) + nevoa * (.04 + .1 * y)

    def enfeitar(self, cena, i, pc, pw):
        n = np.zeros((H, W, 4), np.float32); y = np.linspace(0, 1, H)[:, None]
        n[..., :3] = [.80, .78, .92]; n[..., 3] = np.clip((y - .66) * 1.2, 0, .32)
        cena.alpha_composite(img(n))                   # névoa baixa
        return cena

class Cemiterio:
    nome = 'cemiterio'
    def __init__(self):
        self.pal = paleta_pacote([P2 + 'blocos.png', P2 + 'ceu.png', P2 + 'mausoleus.png',
                                  P2 + 'colina_1.png', P2 + 'arbustos.png'], 28)
        b0 = rgba(P2 + 'ceu.png')
        amb = nearest(b0, W / b0.width).crop((0, 0, W, H))
        mau = tile_x(rgba(P2 + 'mausoleus.png'), W)
        amb.alpha_composite(mau, (0, H - mau.height + 120))
        self.amb = amb
    def luz(self, a, quente):
        """Luar: tira saturação, puxa para azul-esverdeado, guarda um pouco da cor quente."""
        L = lum(a)[..., None]
        cinza = np.repeat(L, 3, -1)
        a = a * (.25 + .4 * quente) + cinza * (.75 - .4 * quente)
        a = np.clip((a - .45) * 1.25 + .5, 0, 1)
        a = a * np.array([.58, .72, .88]) * .85 + np.array([.02, .04, .08])
        y = np.linspace(0, 1, a.shape[0])[:, None, None]
        return a * (1 - .1 * y) + np.array([.10, .14, .22]) * .1 * y

    def enfeitar(self, cena, i, pc, pw):
        n = np.zeros((H, W, 4), np.float32); y = np.linspace(0, 1, H)[:, None]
        n[..., :3] = [.55, .66, .80]; n[..., 3] = np.clip((y - .66) * 1.2, 0, .32)
        cena.alpha_composite(img(n))                   # névoa baixa
        return cena

# ------------------------------------------------------------------ montagem
def foto_da_era(i):
    for ext in ('jpg', 'jpeg', 'png', 'webp'):
        p = os.path.join(FOTOS, '%02d.%s' % (i + 1, ext))
        if os.path.exists(p):
            return Image.open(p).convert('RGB')
    return None

def montar(estilo, i, foto=None):
    cfg = ERAS[i]
    foto = foto or foto_da_era(i)
    if foto is None:
        return None
    if cfg.get('modo') == 'cheio':
        fw, fh = GW, GH
    else:
        fw = int(GW * cfg.get('largura', .62))
        asp = foto.width / foto.height
        fh = min(int(GH * cfg.get('altura', 1.0)), int(fw / asp * cfg.get('zoom', 1.0)))
        if fw > GW * .92: fw = GW
    f = recortar(foto, cfg, fw, fh)
    ceu = mascara_ceu(f, cfg.get('ceu', 'auto'), cfg.get('textura', .025))
    a = reduzir_cores(estilo.luz(arr(f), cfg.get('quente', .45)), estilo.pal)
    alpha = (ceu < .5).astype(np.float32)             # recorte do céu: borda de pixel nítida
    if fw < GW:                                       # some nas laterais (degradê suave)
        x = np.linspace(0, 1, fw)[None, :]
        alpha = alpha * np.clip(np.minimum(x, 1 - x) / .13, 0, 1) ** 1.5
    camada = nearest(img(np.concatenate([a, alpha[..., None]], -1)), PX)
    cena = estilo.amb.copy()
    x0 = int((W - camada.width) / 2 + cfg.get('x', 0) * W)
    x0 = max(0, min(W - camada.width, x0))
    cena.alpha_composite(camada, (x0, H - camada.height))
    return estilo.enfeitar(cena, i, x0 + camada.width / 2, camada.width if fw < GW else 0).convert('RGB')

def main():
    args = [x for x in sys.argv[1:] if not x.startswith('--')]
    so = None
    if '--estilo' in sys.argv:
        so = sys.argv[sys.argv.index('--estilo') + 1]; args = [x for x in args if x != so]
    eras = [int(x) for x in args] if args else range(28)
    for e in (Pantano(), Cemiterio()):
        if so not in (None, e.nome): continue
        os.makedirs(os.path.join(SAIDA, e.nome, 'fundos'), exist_ok=True)
        for i in eras:
            cena = montar(e, i)
            if cena is None:
                print('sem foto para a época %d (%s) — coloque ferramentas/fotos/%02d.jpg' % (i + 1, ERAS[i]['nome'], i + 1)); continue
            out = os.path.join(SAIDA, e.nome, 'fundos', 'e%d.webp' % i)
            cena.save(out, 'WEBP', quality=90, method=6)
            print('ok', e.nome, i, ERAS[i]['nome'], os.path.getsize(out) // 1024, 'KB')

if __name__ == '__main__':
    main()
