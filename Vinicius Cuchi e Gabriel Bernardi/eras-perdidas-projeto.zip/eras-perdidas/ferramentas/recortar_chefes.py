# Recorta os chefes da folha de arte (ferramentas/chefes_folha.webp) e gera as imagens do jogo:
#   assets/chefes/<chefe>/<animação>.png   (quadros lado a lado, todos do mesmo tamanho)
#   assets/chefes/chefes.js                (tamanho dos quadros, ponto de apoio, velocidade)
# Uso:  python3 ferramentas/recortar_chefes.py     (precisa de: pip install pillow numpy scipy)
#
# Como funciona: em cada caixa [x0, y0, x1, y1] da folha, o fundo escuro do painel é retirado,
# cada desenho vira um quadro (da esquerda para a direita) e "pegar" escolhe quais quadros usar
# ("6+7" junta dois pedaços no mesmo quadro). Os quadros de uma animação são alinhados pelos pés
# (chefes de chão) ou pelo centro (chefes que voam e efeitos).
import os, json
import numpy as np
from PIL import Image
from scipy import ndimage

AQUI = os.path.dirname(os.path.abspath(__file__))
RAIZ = os.path.dirname(AQUI)
FOLHA = np.array(Image.open(os.path.join(AQUI, 'chefes_folha.webp')).convert('RGB')).astype(int)
SAIDA = os.path.join(RAIZ, 'assets', 'chefes')

# ------------------------------------------------------------------ o que recortar
# anim: caixa, pegar (índices ou 'todos'), fps, laco (repete?), limiar (contraste com o fundo)
CHEFES = {
  'legionario': {
    'escala': 3, 'apoio': 'pe', 'direita': True, 'limiar': 34,
    'anims': {
      'parado':  {'caixa': (215, 84, 585, 130),  'pegar': [3, 4, 5, 6, 7, 8], 'fps': 6},
      'andar':   {'caixa': (215, 146, 585, 186), 'pegar': 'todos', 'fps': 10},
      'correr':  {'caixa': (215, 205, 585, 250), 'pegar': [1, 2, 3, 4], 'fps': 12},
      'lanca':   {'caixa': (215, 268, 585, 312), 'pegar': [0, 1, 2, 3, 4], 'fps': 11, 'laco': False},
      'salto':   {'caixa': (215, 316, 585, 388), 'pegar': [1, 3, 4, 5, '6+7', 8], 'fps': 7, 'laco': False},
      'dano':    {'caixa': (215, 405, 390, 450), 'pegar': 'todos', 'fps': 6},
      'morte':   {'caixa': (395, 410, 575, 450), 'pegar': 'todos', 'fps': 4, 'laco': False},
      'escudo':  {'caixa': (600, 90, 745, 170),  'pegar': 'todos', 'fps': 10, 'altura_de': 'parado'},
    },
    'extras': {
      'lanca_voando': {'caixa': (605, 240, 730, 320), 'pegar': [1], 'largura': 34, 'apoio': 'centro'},
    },
    'retrato': {'caixa': (15, 65, 210, 355), 'limiar': 30},
  },
  'espectro': {
    'escala': 2.5, 'apoio': 'centro', 'direita': True, 'limiar': 34,
    'anims': {
      'parado':   {'caixa': (955, 84, 1305, 152),  'pegar': 'todos', 'fps': 7},
      'voar':     {'caixa': (955, 168, 1305, 230), 'pegar': 'todos', 'fps': 9},
      'mergulho': {'caixa': (955, 248, 1305, 306), 'pegar': [0, 1, 2, 3, 4], 'fps': 9, 'laco': False},
      'canhao':   {'caixa': (790, 322, 1295, 382), 'pegar': [0, 1, 3, 4, 6, 7], 'fps': 12, 'laco': False},
      'sumir':    {'caixa': (1095, 405, 1300, 462), 'pegar': 'todos', 'fps': 6, 'laco': False},
    },
    'extras': {
      'bala':     {'caixa': (1320, 255, 1515, 335), 'pegar': [0], 'apoio': 'centro'},
      'onda':     {'caixa': (790, 400, 1092, 462), 'pegar': 'todos', 'fps': 8, 'apoio': 'pe'},
      'respingo': {'caixa': (955, 248, 1305, 306), 'pegar': [5], 'apoio': 'pe'},
      'jato':     {'caixa': (1315, 375, 1515, 462), 'pegar': [0, 2], 'apoio': 'pe'},
      'morcego':  {'caixa': (1325, 80, 1515, 205), 'pegar': [1, 2, 5, 3, 0, 4], 'fps': 9, 'apoio': 'centro'},
      'tiro':     {'caixa': (790, 322, 1295, 382), 'pegar': [9], 'apoio': 'centro'},
    },
    'retrato': {'caixa': (785, 68, 945, 275), 'limiar': 22},
  },
  'colosso': {
    'escala': 3.5, 'apoio': 'pe', 'direita': True, 'limiar': 30,
    'anims': {
      'parado':  {'caixa': (240, 552, 565, 598), 'pegar': 'todos', 'fps': 6},
      'andar':   {'caixa': (243, 611, 562, 657), 'pegar': 'todos', 'fps': 8},
      'pisao':   {'caixa': (240, 672, 565, 722), 'pegar': [0, 1, 2], 'fps': 5, 'laco': False},
      'arremesso': {'caixa': (243, 797, 562, 838), 'pegar': [0, 1, 2, 4], 'fps': 8, 'laco': False},
      'quente':  {'caixa': (240, 853, 565, 902), 'pegar': 'todos', 'fps': 8},
      'dano':    {'caixa': (243, 910, 562, 948), 'pegar': [0, 1, 2, 3, 4, 5], 'fps': 8},
      'morte':   {'caixa': (243, 961, 562, 1000), 'pegar': 'todos', 'fps': 5, 'laco': False},
    },
    'extras': {
      'engrenagem': {'caixa': (578, 555, 740, 635), 'pegar': [4], 'apoio': 'centro'},
      'vapor':      {'caixa': (585, 665, 722, 752), 'pegar': 'todos', 'apoio': 'pe'},
      'jato_vapor': {'caixa': (243, 737, 562, 782), 'pegar': [0, 1, 2, 3], 'fps': 10, 'apoio': 'pe'},
      'fumaca':     {'caixa': (582, 775, 725, 847), 'pegar': 'todos', 'apoio': 'pe'},
    },
    'retrato': {'caixa': (20, 532, 238, 838), 'limiar': 16},
  },
  'enigma': {
    'escala': 2.5, 'apoio': 'centro', 'direita': True, 'limiar': 18,
    'anims': {
      'parado': {'caixa': (960, 556, 1290, 612), 'pegar': 'todos', 'fps': 6},
      'voar':   {'caixa': (960, 636, 1290, 692), 'pegar': 'todos', 'fps': 6},
      'raio':   {'caixa': (960, 716, 1290, 780), 'pegar': 'todos', 'fps': 6, 'laco': False},
      'bombas': {'caixa': (790, 796, 1010, 862), 'pegar': 'todos', 'fps': 6, 'laco': False},
      'dano':   {'caixa': (790, 882, 1085, 930), 'pegar': 'todos', 'fps': 8},
      'morte':  {'caixa': (810, 942, 1085, 995), 'pegar': [0, 2], 'fps': 3, 'laco': False},
    },
    'extras': {
      'rotor':     {'caixa': (1305, 556, 1512, 612), 'pegar': [0, 1], 'apoio': 'centro'},
      'rotor_quebrado': {'caixa': (1305, 556, 1512, 612), 'pegar': [2], 'apoio': 'centro'},
      'drone':     {'caixa': (1305, 650, 1512, 710), 'pegar': [1, 5, 7, 3, 0], 'apoio': 'centro'},
      'missil':    {'caixa': (1305, 745, 1512, 795), 'pegar': [1], 'apoio': 'centro'},
      'explosao':  {'caixa': (1305, 825, 1512, 872), 'pegar': [1, 2, 0, 3], 'fps': 12, 'apoio': 'centro'},
      'fogo':      {'caixa': (790, 796, 1285, 862), 'pegar': [3, 4, 5], 'fps': 10, 'apoio': 'pe', 'limiar': 34},
      'alvo':      {'caixa': (1238, 882, 1512, 1004), 'pegar': [2], 'apoio': 'centro'},
      'raio_base': {'caixa': (1238, 882, 1512, 1004), 'pegar': [0], 'apoio': 'pe'},
      'destrocos': {'caixa': (1238, 882, 1512, 1004), 'pegar': [3], 'apoio': 'pe'},
    },
    'retrato': {'caixa': (780, 540, 955, 700), 'limiar': 18, 'pegar': [0]},
  },
}

# ------------------------------------------------------------------ recorte
def cor_fundo(reg):
    px = reg.reshape(-1, 3); esc = px[px.max(axis=1) < 45]
    return np.median(esc, axis=0) if len(esc) > 50 else np.median(px, axis=0)

def pedacos(caixa, limiar):
    x0, y0, x1, y1 = caixa
    reg = FOLHA[y0:y1, x0:x1]
    dif = np.abs(reg - cor_fundo(reg)).max(axis=2)
    m = ndimage.binary_opening(dif > limiar, iterations=1)
    lab, n = ndimage.label(ndimage.binary_dilation(m, iterations=3))
    out = []
    for i in range(1, n + 1):
        core = m & (lab == i)
        if core.sum() < 60: continue
        ys, xs = np.where(core)
        if ys.max() - ys.min() < 5 and xs.max() - xs.min() > 150: continue   # linha da moldura
        out.append(core)
    out.sort(key=lambda c: np.where(c)[1].min())
    return reg, out

def imagem(reg, core):
    mask = ndimage.binary_dilation(ndimage.binary_fill_holes(core), iterations=1)   # 1 px de contorno escuro
    ys, xs = np.where(mask)
    y0, y1, x0, x1 = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
    rgba = np.zeros((y1 - y0, x1 - x0, 4), np.uint8)
    rgba[..., :3] = np.clip(reg[y0:y1, x0:x1], 0, 255)
    rgba[..., 3] = mask[y0:y1, x0:x1] * 255
    im = Image.fromarray(rgba, 'RGBA')
    # ponto de apoio: centro das pernas (parte de baixo) e centro de massa
    m = mask[y0:y1, x0:x1]; h = m.shape[0]
    ysb, xsb = np.where(m[int(h * .6):])
    pe_x = float(xsb.mean()) if len(xsb) else m.shape[1] / 2
    yy, xx = np.where(m)
    return im, pe_x, float(xx.mean()), float(yy.mean())

def escolher(lista, pegar):
    if pegar == 'todos': return lista
    out = []
    for p in pegar:
        if isinstance(p, str):
            idx = [int(q) for q in p.split('+')]; c = lista[idx[0]].copy()
            for q in idx[1:]: c |= lista[q]
            out.append(c)
        else: out.append(lista[p])
    return out

def tira(cfg, padrao_apoio, limiar, escala_alt=None):
    reg, cs = pedacos(cfg['caixa'], cfg.get('limiar', limiar))
    quadros = [imagem(reg, c) for c in escolher(cs, cfg['pegar'])]
    if escala_alt or cfg.get('largura'):
        k = escala_alt or cfg['largura'] / max(q[0].width for q in quadros)
        novos = []
        for im, px, cx, cy in quadros:
            w, h = max(1, round(im.width * k)), max(1, round(im.height * k))
            im2 = im.resize((w, h), Image.LANCZOS); a = np.array(im2); a[..., 3] = np.where(a[..., 3] > 110, 255, 0); im2 = Image.fromarray(a, 'RGBA')
            novos.append((im2, px * k, cx * k, cy * k))
        quadros = novos
    apoio = cfg.get('apoio', padrao_apoio)
    # célula comum: alinha todos pelo ponto de apoio
    if apoio == 'pe':
        esq = max(px for im, px, cx, cy in quadros); dir_ = max(im.width - px for im, px, cx, cy in quadros)
        alt = max(im.height for im, *_ in quadros); W = int(np.ceil(esq + dir_)); H = alt
        cel = Image.new('RGBA', (W * len(quadros), H))
        for k, (im, px, cx, cy) in enumerate(quadros): cel.alpha_composite(im, (int(round(k * W + esq - px)), H - im.height))
        ponto = [round(esq, 1), H]
    else:
        esq = max(cx for im, px, cx, cy in quadros); dir_ = max(im.width - cx for im, px, cx, cy in quadros)
        cima = max(cy for im, px, cx, cy in quadros); baixo = max(im.height - cy for im, px, cx, cy in quadros)
        W = int(np.ceil(esq + dir_)); H = int(np.ceil(cima + baixo))
        cel = Image.new('RGBA', (W * len(quadros), H))
        for k, (im, px, cx, cy) in enumerate(quadros): cel.alpha_composite(im, (int(round(k * W + esq - cx)), int(round(cima - cy))))
        ponto = [round(esq, 1), round(cima, 1)]
    return cel, [W, H], ponto, len(quadros), [q[0].height for q in quadros]

def main():
    manifesto = {'pasta': 'assets/chefes/'}
    for nome, c in CHEFES.items():
        pasta = os.path.join(SAIDA, nome); os.makedirs(pasta, exist_ok=True)
        info = {'escala': c['escala'], 'apoio': c['apoio'], 'direita': c['direita'], 'anim': {}, 'extra': {}}
        alturas = {}
        for an, cfg in c['anims'].items():
            k = None
            if cfg.get('altura_de'):
                k = float(np.median(alturas[cfg['altura_de']])) / float(np.median(tira(cfg, c['apoio'], c['limiar'])[4]))
            cel, q, ponto, n, alts = tira(cfg, c['apoio'], c['limiar'], k)
            alturas[an] = alts
            cel.save(os.path.join(pasta, an + '.png'))
            info['anim'][an] = {'arquivo': an + '.png', 'quadro': q, 'ponto': ponto, 'n': n, 'fps': cfg.get('fps', 8), 'laco': cfg.get('laco', True)}
        for ex, cfg in c.get('extras', {}).items():
            cel, q, ponto, n, _ = tira(cfg, cfg.get('apoio', 'centro'), c['limiar'])
            cel.save(os.path.join(pasta, ex + '.png'))
            info['extra'][ex] = {'arquivo': ex + '.png', 'quadro': q, 'ponto': ponto, 'n': n, 'fps': cfg.get('fps', 8)}
        if c.get('retrato'):
            r = c['retrato']; reg, cs = pedacos(r['caixa'], r['limiar'])
            cs = escolher(cs, r.get('pegar', [int(np.argmax([x.sum() for x in cs]))]))
            core = cs[0]
            for x in cs[1:]: core = core | x
            im = imagem(reg, core)[0]; im.save(os.path.join(pasta, 'retrato.png'))
            info['retrato'] = 'retrato.png'
        manifesto[nome] = info
        print(nome, {k: (v['n'], v['quadro']) for k, v in info['anim'].items()})
    with open(os.path.join(SAIDA, 'chefes.js'), 'w', encoding='utf-8') as f:
        f.write('// gerado por ferramentas/recortar_chefes.py a partir de ferramentas/chefes_folha.webp\n')
        f.write('// quadro = [largura, altura] de cada quadro; ponto = pés (ou centro) dentro do quadro; escala = tamanho na tela\n')
        linhas = ['registrarChefes({', '  pasta: ' + json.dumps(manifesto['pasta']) + ',']
        for nome, info in manifesto.items():
            if nome == 'pasta': continue
            linhas.append('  ' + nome + ': {')
            linhas.append('    escala: %s, apoio: %s, direita: %s, retrato: %s,' % (info['escala'], json.dumps(info['apoio']), 'true' if info['direita'] else 'false', json.dumps(info.get('retrato'))))
            for grupo in ('anim', 'extra'):
                linhas.append('    ' + grupo + ': {')
                for k, v in info[grupo].items():
                    linhas.append('      ' + k + ': ' + json.dumps(v, ensure_ascii=False) + ',')
                linhas.append('    },')
            linhas.append('  },')
        linhas.append('});')
        f.write('\n'.join(linhas) + '\n')

if __name__ == '__main__':
    main()
