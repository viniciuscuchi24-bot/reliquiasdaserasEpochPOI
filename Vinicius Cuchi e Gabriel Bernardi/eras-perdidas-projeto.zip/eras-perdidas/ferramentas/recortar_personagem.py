# Recorta o personagem de cada época da folha de arte (ferramentas/personagem_folha.webp) e gera:
#   assets/personagem/eraNN.png   uma folha por época: cada linha é uma animação, cada coluna um quadro
#   assets/personagem/impactos.png   o efeito de impacto de cada época (um quadro por época)
#   assets/personagem/personagem.js  tamanho dos quadros, ponto dos pés, animações
# Uso:  python3 ferramentas/recortar_personagem.py     (precisa de: pip install pillow numpy scipy)
#
# A folha tem uma linha por personagem e as colunas Idle, Walk, Jump, Attack, Hurt, Land e Impact.
# Os quadros encostam uns nos outros: o corte entre dois quadros segue o caminho mais escuro (o contorno).
# Depois o brilho da borda é tirado, um contorno escuro novo é desenhado e tudo é alinhado pelos pés.
import os, json
import numpy as np
from PIL import Image
from scipy import ndimage

AQUI = os.path.dirname(os.path.abspath(__file__))
RAIZ = os.path.dirname(AQUI)
A = np.array(Image.open(os.path.join(AQUI, 'personagem_folha.webp')).convert('RGB')).astype(int)
MX = A.max(axis=2)
FG = MX > 10                                         # o fundo da folha é quase preto
for x in [138, 239, 324, 455, 456, 535, 536, 656, 657]: FG[:, x - 1:x + 2] = False   # linhas entre as colunas
# limites das linhas da folha (31 personagens)
LIMITES = [30, 97, 162, 227, 294, 360, 427, 494, 562, 629, 696, 764, 833, 901, 968, 1036, 1106, 1174, 1242,
           1310, 1379, 1447, 1514, 1581, 1647, 1716, 1785, 1852, 1920, 1988, 2055, 2140]
# qual linha da folha vira cada época do jogo (0 = Paleolítico ... 27 = 2ª Guerra).
# As linhas 28, 29 e 30 sobram (soldados extras); para usar uma delas, troque o número aqui.
LINHA_DA_ERA = list(range(28))
# centro (x) de cada quadro na folha; 'x...' = pedaço descartado (o golpe já desenhado no quadro 0 do ataque)
COLUNAS = {
  'parado':  ([84, 106, 128], 63, 136),
  'andar':   ([158, 176, 194, 212, 230], 141, 237),
  'pulo':    ([260, 280, 298, 316], 242, 322),
  'ataque':  ([347, 'x370', 393, 411, 428, 446], 327, 453),
  'dano':    ([476, 500, 523], 459, 533),
  'pouso':   ([558, 586, 608, 628, 646], 539, 654),
  'impacto': ([690], 659, 724),
}
ANIMS = ['parado', 'andar', 'pulo', 'ataque', 'dano', 'pouso']
FPS = {'parado': 4, 'andar': 11, 'pulo': 10, 'ataque': 25, 'dano': 10, 'pouso': 22}
# quadros usados em cada animação (o 1º quadro das animações que repetem tem o brilho de seleção da folha)
USAR = {'parado': [1, 2], 'andar': [1, 2, 3, 4], 'pulo': [0, 1, 2, 3], 'ataque': [0, 1, 2, 3, 4], 'dano': [1, 2, 1], 'pouso': [0, 1, 2, 3, 4]}
IMPACTO_DE = {0: 1}     # a linha 0 da folha não tem um impacto (tem um desenho do personagem): usa o da linha 1
ESCALA = 1.25           # tamanho na tela (o personagem fica com ~44 px de altura)

def costura(y0, y1, xa, xb):
    """caminho vertical mais escuro entre as colunas xa e xb (um x por linha)"""
    sub = MX[y0:y1, xa:xb].astype(float); h, w = sub.shape
    cost = sub + np.abs(np.arange(w) - (w - 1) / 2)[None, :] * 6     # fica perto do meio (roupas escuras não desviam o corte)
    acc = cost.copy(); back = np.zeros((h, w), int)
    for y in range(1, h):
        for x in range(w):
            best, bv = x, acc[y - 1, x]
            for dx in (-1, 1):
                if 0 <= x + dx < w and acc[y - 1, x + dx] < bv: bv, best = acc[y - 1, x + dx], x + dx
            acc[y, x] += bv; back[y, x] = best
    x = int(np.argmin(acc[-1])); path = [0] * h
    for y in range(h - 1, -1, -1): path[y] = x + xa; x = back[y, x]
    return path

def quadros(linha, anim):
    y0, y1 = LIMITES[linha] + 2, LIMITES[linha + 1] - 2
    cs, L0, R0 = COLUNAS[anim]; cx = [int(str(c).lstrip('x')) for c in cs]; h = y1 - y0
    cortes = [[L0] * h]
    for i in range(len(cs) - 1):
        m = (cx[i] + cx[i + 1]) // 2; cortes.append(costura(y0, y1, m - 3, m + 4))
    cortes.append([R0] * h)
    out = []
    for i, c in enumerate(cs):
        if str(c).startswith('x'): continue
        m = np.zeros((h, A.shape[1]), bool)
        for y in range(h):
            l, r = cortes[i][y], cortes[i + 1][y]; m[y, l + 1:r] = FG[y0 + y, l + 1:r]
        out.append((m, y0))
    return out

def limpar(m, efeito=False):
    m = ndimage.binary_fill_holes(m)
    if not efeito:
        m = ndimage.binary_opening(m, structure=np.ones((2, 2)))
        m = ndimage.binary_erosion(m, structure=[[0, 1, 0], [1, 1, 1], [0, 1, 0]])   # tira o brilho da borda
    if efeito:   # o impacto é redondo: fica só o que está no círculo em volta do centro mais claro (tira a ponta da lâmina)
        ys, xs = np.where(m)
        if len(ys):
            r = (ys.max() - ys.min()) / 2 + 2; cy = (ys.max() + ys.min()) / 2; cx = np.median(xs[np.abs(ys - cy) < 3]) if np.any(np.abs(ys - cy) < 3) else xs.mean()
            cx = xs.max() - r + 2 if xs.max() - cx > r else cx
            yy, xx = np.mgrid[0:m.shape[0], 0:m.shape[1]]
            m &= (yy - cy) ** 2 + (xx - cx) ** 2 <= r * r
    lab, n = ndimage.label(m, structure=np.ones((3, 3)))
    if n > 1:
        tam = ndimage.sum(m, lab, range(1, n + 1))
        m = (lab == int(np.argmax(tam)) + 1) if efeito else np.isin(lab, [k + 1 for k, t in enumerate(tam) if t >= tam.max() * .08])
    return m

def sprite(m, y0, efeito=False):
    """recorte RGBA com contorno escuro novo + ponto de apoio (x do corpo, y dos pés)"""
    m = limpar(m, efeito); ys, xs = np.where(m)
    if not len(ys): return None
    t, b, l, r = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
    rgba = np.zeros((b - t, r - l, 4), np.uint8)
    rgba[..., :3] = np.clip(A[y0 + t:y0 + b, l:r], 0, 255); rgba[..., 3] = m[t:b, l:r] * 255
    if not efeito:   # contorno de 1 px
        al = np.pad(rgba[..., 3] > 0, 1); rgba = np.pad(rgba, ((1, 1), (1, 1), (0, 0)))
        viz = ndimage.binary_dilation(al, structure=[[0, 1, 0], [1, 1, 1], [0, 1, 0]]) & ~al
        rgba[viz, :3] = (20, 13, 15); rgba[viz, 3] = 255
        l -= 1; t -= 1
    mm = rgba[..., 3] > 0; yy, xx = np.where(mm)
    corpo = mm[: max(1, int(mm.shape[0] * .75))]          # o centro do corpo vem da parte de cima (sem a lâmina)
    cy, cxs = np.where(corpo)
    return {'img': rgba, 'ax': float(np.median(cxs)) if len(cxs) else rgba.shape[1] / 2, 'ay': float(yy.max() + 1), 'h': rgba.shape[0]}

def main():
    pasta = os.path.join(RAIZ, 'assets', 'personagem')
    eras = []
    for era, linha in enumerate(LINHA_DA_ERA):
        animas = {}
        for an in ANIMS:
            animas[an] = [s for s in (sprite(m, y0) for m, y0 in quadros(linha, an)) if s]
        # no ar, os quadros encolhidos ficam centrados na altura do corpo (não grudados nos pés)
        hp = np.median([s['h'] for s in animas['parado']])
        for s in animas['pulo']: s['ay'] += (hp - s['h']) / 2 if s['h'] < hp else 0
        (m, y0), = quadros(linha, 'impacto' if linha not in IMPACTO_DE else 'impacto')
        if linha in IMPACTO_DE: (m, y0), = quadros(IMPACTO_DE[linha], 'impacto')
        eras.append((animas, sprite(m, y0, efeito=True)))
    # célula comum a todas as folhas
    esq = max(s['ax'] for an, _ in eras for l in an.values() for s in l)
    dir_ = max(s['img'].shape[1] - s['ax'] for an, _ in eras for l in an.values() for s in l)
    cima = max(s['ay'] for an, _ in eras for l in an.values() for s in l)
    baixo = max(s['img'].shape[0] - s['ay'] for an, _ in eras for l in an.values() for s in l)
    W, H = int(np.ceil(esq + dir_)) + 2, int(np.ceil(cima + baixo)) + 2
    AX, AY = int(np.ceil(esq)) + 1, int(np.ceil(cima)) + 1
    ncol = max(len(eras[0][0][an]) for an in ANIMS)
    for era, (animas, imp) in enumerate(eras):
        folha = Image.new('RGBA', (W * ncol, H * len(ANIMS)))
        for j, an in enumerate(ANIMS):
            for i, s in enumerate(animas[an]):
                folha.alpha_composite(Image.fromarray(s['img'], 'RGBA'), (i * W + int(round(AX - s['ax'])), j * H + int(round(AY - s['ay']))))
        folha.quantize(colors=200, method=Image.Quantize.FASTOCTREE).save(os.path.join(pasta, 'era%02d.png' % era), optimize=True)   # paleta: arquivo pequeno
    # impactos: um quadro por época, centrados
    IW = max(e[1]['img'].shape[1] for e in eras if e[1]) + 2; IH = max(e[1]['img'].shape[0] for e in eras if e[1]) + 2
    imp = Image.new('RGBA', (IW * len(eras), IH))
    for era, (_, s) in enumerate(eras):
        if s: imp.alpha_composite(Image.fromarray(s['img'], 'RGBA'), (era * IW + (IW - s['img'].shape[1]) // 2, (IH - s['img'].shape[0]) // 2))
    imp.quantize(colors=250, method=Image.Quantize.FASTOCTREE).save(os.path.join(pasta, 'impactos.png'), optimize=True)
    anims = {an: {'linha': j, 'quadros': USAR[an], 'fps': FPS[an]} for j, an in enumerate(ANIMS)}
    with open(os.path.join(pasta, 'personagem.js'), 'w', encoding='utf-8') as f:
        f.write('''// =====================================================================
//  PERSONAGEM (o cronista) — gerado por ferramentas/recortar_personagem.py
//  Uma folha por época: era00.png … era27.png. Cada LINHA da folha é uma animação e cada COLUNA um quadro,
//  todos do mesmo tamanho (quadro). "pes" é o ponto dos pés dentro do quadro; "escala" é o tamanho na tela.
//  impactos.png: o efeito de impacto do golpe de cada época (um quadro por época).
//  asas.png: as asas do pulo duplo (feitas por ferramentas/gerar_asas.py).
//  cortes.png: o rastro do golpe (uma linha por arma, 5 quadros, em meia resolução: aparece em 2x);
//  laminas.png: a espada na mão durante o golpe. Feitos por ferramentas/gerar_cortes.py.
//  bainha.png: a espada embainhada na cintura (uma coluna por melhoria da arma; linha 0 = bainha,
//    linha 1 = cabo). 'cinto' = ponto do cinto no quadro; 'cintura' = onde ele fica no corpo
//    (px para a frente e para cima a partir dos pés). Feita por ferramentas/gerar_bainha.py.
//  Para mudar uma roupa: edite eraNN.png mantendo o tamanho dos quadros.
// =====================================================================
registrarPersonagem({
  pasta: 'assets/personagem/',
  arquivoEra: 'era{nn}.png',
  quadro: [%d, %d],
  pes: [%d, %d],
  escala: %s,
  anim: {
%s
  },
  impactos: { arquivo: 'impactos.png', quadro: [%d, %d] },
  asas: { arquivo: 'asas.png', quadro: [40, 38], ombro: [33, 21], n: 4, fps: 16, escala: 1.5 },
  cortes: { arquivo: 'cortes.png', quadro: [147, 56], ombro: [4, 28], n: 5, escala: 2 },
  laminas: { arquivo: 'laminas.png', quadro: [38, 9], mao: [6, 4] },
  bainha: { arquivo: 'bainha.png', quadro: [34, 18], cinto: [15, 5], cintura: [-3, 14] }
});
''' % (W, H, AX, AY, ESCALA, ',\n'.join('    %s: %s' % (k, json.dumps(v)) for k, v in anims.items()), IW, IH))
    print('folhas: quadro %dx%d, pés em (%d,%d), %d colunas' % (W, H, AX, AY, ncol), {an: anims[an]['quadros'] for an in ANIMS})

if __name__ == '__main__':
    main()
