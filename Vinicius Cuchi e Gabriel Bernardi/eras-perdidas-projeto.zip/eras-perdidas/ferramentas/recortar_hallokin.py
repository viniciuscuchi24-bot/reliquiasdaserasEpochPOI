# Recorta o Hallokin (SHADOW Series - Hallokin, free) para o jogo, sem redesenhar os sprites.
# Entrada: ferramentas/hallokin_folha.png (a folha original: 12 colunas x 9 linhas de quadros 192x128).
# Saídas em assets/hallokin/:
#   hallokin.png  o corpo: uma linha por animação (parado, andar, pulo, queda, ataque, ataque no ar,
#                 ataque para cima, dano, morte, ataque para baixo) e um quadro por coluna.
#   golpes.png    só o rastro laranja dos golpes, na mesma grade (as linhas sem golpe ficam vazias).
#                 Separado do corpo para o jogo esticar o rastro até o alcance de cada arma.
#   impactos.png  faíscas do golpe acertando (tiradas da explosão da abóbora na animação de morte).
#   hallokin.js   as medidas (gerado aqui; registrarPersonagem).
# O ataque para baixo (pogo) não existe na folha original: é montado aqui com o corpo da queda e o rastro
# do ataque para cima espelhado para baixo, saindo dos pés.
# Uso: python3 ferramentas/recortar_hallokin.py
import os, json
import numpy as np
from PIL import Image

AQUI = os.path.dirname(os.path.abspath(__file__))
PASTA = os.path.join(os.path.dirname(AQUI), 'assets', 'hallokin')
FW, FH = 192, 128                       # quadro da folha original
X0, Y0, QW, QH = 24, 16, 96, 96         # recorte de cada quadro (o corpo fica no meio, os pés em y=80)
PES = (57.5 - X0, 80 - Y0)
SOLTA = {'ataque': 2, 'ataque_ar': 1, 'ataque_cima': 2, 'ataque_baixo': 2}   # quadro em que o corte está formado
ESPELHO = 69                            # eixo (y na folha) para virar o ataque para cima em ataque para baixo

ESCURO = {(0, 0, 0), (0, 1, 0), (53, 56, 43), (89, 94, 72)}       # contorno e capa
LINHAS = {   # nome: (linha na folha, quadros)
    'parado': (0, 6), 'andar': (1, 4), 'pulo': (2, 3), 'queda': (3, 3), 'ataque': (4, 7),
    'ataque_ar': (5, 5), 'ataque_cima': (6, 6), 'dano': (7, 1), 'morte': (8, 12),
}
ORDEM = ['parado', 'andar', 'pulo', 'queda', 'ataque', 'ataque_ar', 'ataque_cima', 'dano', 'morte', 'ataque_baixo']
FPS = {'parado': 8, 'andar': 10, 'pulo': 10, 'queda': 10, 'ataque': 28, 'ataque_ar': 24, 'ataque_cima': 26,
       'dano': 1, 'morte': 12, 'ataque_baixo': 26}


def quadro(a, r, c):
    return a[r * FH:(r + 1) * FH, c * FW:(c + 1) * FW].copy()


def cores(q):
    return [[tuple(int(v) for v in q[y, x, :3]) for x in range(FW)] for y in range(FH)]


def separar(q, molde, mal, oy):
    """corpo x rastro: a cabeça (achada pelo molde da abóbora) e a capa escura são corpo; o resto laranja é rastro"""
    al = q[..., 3] > 0
    melhor, pos = -1, (0, 0)
    mh, mw = molde.shape[:2]
    for dy in range(-6, 7):
        for dx in range(-8, 9):
            y, x = oy + dy, 50 + dx
            if y < 0 or x < 0: continue
            j = q[y:y + mh, x:x + mw]
            if j.shape[:2] != (mh, mw): continue
            igual = mal & (j[..., 3] > 0) & np.all(j[..., :3] == molde[..., :3], axis=-1)
            s = int(igual.sum())
            if s > melhor: melhor, pos = s, (dy, dx)
    cab = np.zeros(al.shape, bool)
    y, x = oy + pos[0], 50 + pos[1]
    cab[y:y + mh, x:x + mw] = mal
    yy, xx = np.mgrid[0:FH, 0:FW]
    esc = np.array([[tuple(int(v) for v in q[i, j, :3]) in ESCURO for j in range(FW)] for i in range(FH)])
    capa = esc & (xx >= 44) & (xx <= 74) & (yy >= y + mh - 1)
    corpo = al & (cab | capa)
    if capa.any():                                   # o laranja que passa na frente da capa (pernas) fica no corpo
        ys, xs = np.nonzero(capa)
        corpo |= al & (yy >= ys.min()) & (yy <= ys.max()) & (xx >= xs.min()) & (xx <= xs.max())
    laranja = al & ~esc
    # o corpo perde só o laranja que está fora dele; o rastro leva todo o laranja que não é a cabeça
    # (inclusive o que passa na frente das pernas), para poder voar inteiro nas armas de alcance maior
    return al & ~(laranja & ~corpo), laranja & ~cab


def recorte(q):
    return q[Y0:Y0 + QH, X0:X0 + QW]


def main():
    a = np.array(Image.open(os.path.join(AQUI, 'hallokin_folha.png')).convert('RGBA'))
    a[a[..., 3] == 0] = 0
    parado = quadro(a, 0, 0)
    molde = parado[57:71, 50:65]; mal = molde[..., 3] > 0          # a abóbora com o cabinho
    corpo_f = np.zeros((QH * len(ORDEM), QW * 12, 4), np.uint8)
    golpe_f = np.zeros_like(corpo_f)
    medidas = {}
    rastros = {}
    for li, nome in enumerate(ORDEM):
        if nome == 'ataque_baixo':
            continue
        r, n = LINHAS[nome]
        for c in range(n):
            q = quadro(a, r, c)
            if nome.startswith('ataque'):
                corpo, rastro = separar(q, molde, mal, 57)
                cq = q.copy(); cq[~corpo] = 0
                rq = q.copy(); rq[~rastro] = 0
                rastros[(nome, c)] = rq
            else:
                cq, rq = q, None
            corpo_f[li * QH:(li + 1) * QH, c * QW:(c + 1) * QW] = recorte(cq)
            if rq is not None:
                golpe_f[li * QH:(li + 1) * QH, c * QW:(c + 1) * QW] = recorte(rq)
    # ---- pogo (ataque para baixo): corpo da queda + rastro do ataque para cima virado para baixo
    li = ORDEM.index('ataque_baixo')
    corpos = [0, 0, 1, 1, 2, 2]
    for c in range(6):
        cq = quadro(a, LINHAS['queda'][0], corpos[c])
        rq = rastros[('ataque_cima', c)]
        vira = np.zeros_like(rq)
        for y in range(FH):
            ys = 2 * ESPELHO - y
            if 0 <= ys < FH: vira[y] = rq[ys]
        corpo_f[li * QH:(li + 1) * QH, c * QW:(c + 1) * QW] = recorte(cq)
        golpe_f[li * QH:(li + 1) * QH, c * QW:(c + 1) * QW] = recorte(vira)
    # ---- medidas dos rastros: até onde vão (no recorte)
    def extensao(nome):
        li = ORDEM.index(nome); n = 6 if nome == 'ataque_baixo' else LINHAS[nome][1]
        tira = golpe_f[li * QH:(li + 1) * QH, :n * QW, 3] > 0
        ys, xs = np.nonzero(tira); xs = xs % QW
        return int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1
    for nome, eixo in [('ataque', 'x'), ('ataque_ar', 'x'), ('ataque_cima', '-y'), ('ataque_baixo', 'y')]:
        x0, y0, x1, y1 = extensao(nome)
        ponta = x1 if eixo == 'x' else y0 if eixo == '-y' else y1
        medidas[nome] = {'eixo': eixo, 'ponta': ponta, 'solta': SOLTA[nome]}
    # ---- impactos: a explosão laranja da abóbora (morte, quadros 2..4) sem o corpo
    imp_q = []
    for c in (2, 3, 4):
        q = quadro(a, LINHAS['morte'][0], c)
        m = (q[..., 3] > 0)
        for y in range(FH):
            for x in range(FW):
                if m[y, x] and (tuple(int(v) for v in q[y, x, :3]) in ESCURO or y >= 68): m[y, x] = False
        q[~m] = 0
        imp_q.append(q[44:69, 34:82])                                   # 48x25 em volta da cabeça (57, 63)
    imp = np.concatenate(imp_q, axis=1)
    os.makedirs(PASTA, exist_ok=True)
    Image.fromarray(corpo_f, 'RGBA').save(os.path.join(PASTA, 'hallokin.png'), optimize=True)
    Image.fromarray(golpe_f, 'RGBA').save(os.path.join(PASTA, 'golpes.png'), optimize=True)
    Image.fromarray(imp, 'RGBA').save(os.path.join(PASTA, 'impactos.png'), optimize=True)
    anim = {}
    for li, nome in enumerate(ORDEM):
        n = 6 if nome == 'ataque_baixo' else LINHAS[nome][1]
        anim[nome] = {'linha': li, 'quadros': list(range(n)), 'fps': FPS[nome]}
    linhas_anim = ',\n'.join('    %s: %s' % (k, json.dumps(v)) for k, v in anim.items())
    linhas_golpe = ',\n'.join('    %s: %s' % (k, json.dumps(v)) for k, v in medidas.items())
    js = """// =====================================================================
//  PERSONAGEM: Hallokin (SHADOW Series - Hallokin, free) — gerado por ferramentas/recortar_hallokin.py
//  hallokin.png: uma LINHA por animação e um quadro por COLUNA (%dx%d cada); "pes" é o ponto dos pés no quadro.
//  golpes.png: o rastro laranja dos golpes, na mesma grade. Nas armas de alcance maior o corte se solta e voa
//    na direção do golpe ('eixo': x = para a frente, -y = para cima, y = para baixo) até onde a arma acerta;
//    'ponta' é até onde o rastro vai no quadro e 'solta' é o quadro em que ele começa a voar.
//  ataque_baixo (pogo) foi montado a partir do ataque para cima (não existe na folha original).
//  impactos.png: o estouro do golpe acertando (3 quadros de 48x25, centro em 'centro').
//  Mesmo personagem em todas as épocas.
// =====================================================================
registrarPersonagem({
  nome: 'Hallokin',
  pasta: 'assets/hallokin/',
  arquivo: 'hallokin.png',
  quadro: [%d, %d],
  pes: [%s, %d],
  escala: 2,
  anim: {
%s
  },
  golpes: { arquivo: 'golpes.png',
%s
  },
  impactos: { arquivo: 'impactos.png', quadro: [48, 25], centro: [23, 19], n: 3, escala: 1.5 },
  asas: { arquivo: 'asas.png', quadro: [40, 38], ombro: [33, 21], n: 4, fps: 16, escala: 1.25, costas: [-6, 15] }
});
""" % (QW, QH, QW, QH, PES[0], PES[1], linhas_anim, linhas_golpe)
    open(os.path.join(PASTA, 'hallokin.js'), 'w').write(js)
    print('ok', corpo_f.shape, json.dumps(medidas))


if __name__ == '__main__':
    main()
