# Desenha as asas do pulo duplo (as "Asas de Dédalo": penas presas com cera) em pixel art.
# Gera assets/personagem/asas.png: 4 quadros de 40x38 (bater de asas), com o ombro em (33, 21).
# Cada quadro tem as duas asas: a de trás (mais escura) e a da frente.
# Uso: python3 ferramentas/gerar_asas.py
import os, math
import numpy as np
from PIL import Image
from scipy import ndimage

AQUI = os.path.dirname(os.path.abspath(__file__))
SAIDA = os.path.join(os.path.dirname(AQUI), 'assets', 'personagem', 'asas.png')
QW, QH, OX, OY = 40, 38, 33, 21                 # quadro e ombro (onde a asa nasce, nas costas)
CORES = {'pena': (244, 236, 214), 'pena2': (222, 210, 182), 'sombra': (184, 166, 136), 'ponta': (200, 186, 158),
         'cera': (232, 188, 84), 'cera2': (190, 140, 52), 'linha': (40, 30, 30)}
# ângulo da asa em cada quadro (graus; 0 = para trás na horizontal, positivo = para cima)
ANGULOS = [58, 22, -16, 22]

def asa(ang, escala=1.0, escura=False):
    """máscara de cores (índices) de uma asa aberta no ângulo dado"""
    img = np.zeros((QH, QW, 3), np.uint8); al = np.zeros((QH, QW), bool)
    def ponto(x, y, cor):
        xi, yi = int(round(x)), int(round(y))
        if 0 <= xi < QW and 0 <= yi < QH: img[yi, xi] = cor; al[yi, xi] = True
    base = math.radians(ang)
    # osso/cera: um arco do ombro até a "mão" da asa
    comp = 15 * escala
    for k in range(int(comp) + 1):
        u = k / comp
        x = OX - math.cos(base) * k; y = OY - math.sin(base) * k - math.sin(u * math.pi) * 2
        for d in (0, 1): ponto(x, y + d, CORES['cera2' if escura else 'cera'])
    mao = (OX - math.cos(base) * comp, OY - math.sin(base) * comp)
    # penas: saem do osso e apontam para trás/baixo, mais compridas na ponta (primárias)
    n = 9
    for i in range(n):
        u = (i + 1) / n
        ox = OX - math.cos(base) * comp * u; oy = OY - math.sin(base) * comp * u
        dir_ = base + math.radians(-75 + 50 * u)          # leque: perto do ombro aponta para baixo
        L = (5 + 9 * u ** 1.4) * escala
        for k2 in range(int(L * 2) + 1):
            k = k2 / 2
            x = ox - math.cos(dir_) * k; y = oy - math.sin(dir_) * k
            cor = CORES['ponta'] if k > L - 2 else (CORES['pena2'] if (i % 2) else CORES['pena'])
            if escura: cor = tuple(int(c * .72) for c in cor)
            ponto(x, y, cor); ponto(x + .5, y + .5, cor)
    buracos = ndimage.binary_fill_holes(al) & ~al          # tapa os furinhos entre as penas
    img[buracos] = CORES['pena2'] if not escura else tuple(int(c * .72) for c in CORES['pena2']); al |= buracos
    return img, al, mao

def contorno(img, al):
    viz = ndimage.binary_dilation(al, structure=[[0, 1, 0], [1, 1, 1], [0, 1, 0]]) & ~al
    img = img.copy(); img[viz] = CORES['linha']
    return img, al | viz

def main():
    folha = Image.new('RGBA', (QW * len(ANGULOS), QH))
    for q, ang in enumerate(ANGULOS):
        tras, at, _ = asa(ang + 14, .85, escura=True)       # asa de trás: um pouco mais alta e menor
        tras, at = contorno(tras, at)
        frente, af, _ = asa(ang, 1.0)
        frente, af = contorno(frente, af)
        rgba = np.zeros((QH, QW, 4), np.uint8)
        rgba[at, :3] = tras[at]; rgba[at, 3] = 255
        rgba[af, :3] = frente[af]; rgba[af, 3] = 255
        folha.alpha_composite(Image.fromarray(rgba, 'RGBA'), (q * QW, 0))
    folha.save(SAIDA); print('ok', SAIDA, folha.size)

if __name__ == '__main__':
    main()
