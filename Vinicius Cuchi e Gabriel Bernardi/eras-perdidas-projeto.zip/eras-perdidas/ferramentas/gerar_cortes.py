# Desenha o golpe da espada em pixel art:
#   assets/personagem/cortes.png  o rastro do corte (meia-lua), 7 linhas (uma por arma) x 5 quadros.
#                                 Desenhado em meia resolução: o jogo mostra em 2x (pixels de 2 px, como os cenários).
#                                 O corte varre de cima para baixo, na frente do ombro (ponto OMBRO do quadro).
#   assets/personagem/laminas.png a espada na mão durante o golpe, 7 linhas (uma por arma), apontando para a direita;
#                                 a mão fica no ponto MAO.
# O tamanho do corte acompanha o alcance de cada arma (js/nucleo.js, lista SW).
# Uso: python3 ferramentas/gerar_cortes.py
import os, math
import numpy as np
from PIL import Image

AQUI = os.path.dirname(os.path.abspath(__file__))
PASTA = os.path.join(os.path.dirname(AQUI), 'assets', 'personagem')
# alcance (px na tela) e cor de cada arma — iguais às do jogo
ARMAS = [(70, '#d8c9a0'), (100, '#e6e2d6'), (135, '#cfd6de'), (170, '#bfe3ff'), (205, '#ffe2a0'), (240, '#ffb27a'), (280, '#a0ffe0')]
BAYER = np.array([[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]]) / 16 + 1 / 32
# janela do arco visível em cada quadro (ângulos em radianos; negativo = em cima) e espessura
QUADROS = [(-1.45, -.45, .55), (-1.45, .35, 1.0), (-1.05, 1.05, 1.0), (-.15, 1.45, .8), (.65, 1.45, .45)]
OMBRO_X = 4

def rgb(h): h = h.lstrip('#'); return np.array([int(h[i:i + 2], 16) for i in (0, 2, 4)], float)
def mistura(a, b, t): return np.clip(a * (1 - t) + b * t, 0, 255)

def corte(R, ry, cor, janela, esp, W, H):
    a0, a1, espessura = janela[0], janela[1], esp
    yy, xx = np.mgrid[0:H, 0:W].astype(float)
    x = xx - OMBRO_X + .5; y = yy - H / 2 + .5
    rho = np.hypot(x / R, y / ry)
    ang = np.arctan2(y / ry, x / R)
    # elipse de dentro, empurrada para trás: a meia-lua fica grossa no meio e fina nas pontas
    fino = 1 - .42 * espessura
    rho_i = np.hypot((x + R * (.22 + .2 * (1 - espessura))) / (R * (.78 + .14 * (1 - espessura))), y / (ry * (.62 + .3 * fino)))
    dentro = (rho <= 1) & (rho_i >= 1) & (x > -1) & (ang >= a0) & (ang <= a1)
    # posição dentro da faixa: 0 = borda de fora (brilho), 1 = borda de dentro
    larg = np.clip((1 - rho) / np.maximum(1e-3, (1 - rho) + (rho_i - 1)), 0, 1)
    # rastro: perto do fim da janela (o começo do golpe) ele vai sumindo em pontilhado
    cauda = np.clip((ang - a0) / max(.01, (a1 - a0)), 0, 1)
    dens = np.clip(cauda * 3.2, 0, 1) * np.clip((1 - larg) * 6, 0, 1)      # pontilhado só no rastro e na borda de dentro
    bay = BAYER[(yy.astype(int)) % 4, (xx.astype(int)) % 4]
    vis = dentro & (dens > bay)
    c = rgb(cor); claro = mistura(c, np.array([255, 255, 255.]), .55); escuro = mistura(c, np.array([30, 24, 40.]), .45)
    img = np.zeros((H, W, 4), np.uint8)
    vivo = mistura(c, np.array([255, 255, 255.]), -.25)                 # a cor da lâmina um pouco mais forte
    camadas = [(larg < .16, np.array([255, 255, 255.])), ((larg >= .16) & (larg < .38), claro), ((larg >= .38) & (larg < .72), vivo), (larg >= .72, escuro)]
    for m, col in camadas:
        sel = vis & m; img[sel, :3] = col.astype(np.uint8); img[sel, 3] = 255
    # ponta da frente do golpe: um brilho branco no ângulo que está avançando
    frente = dentro & (np.abs(ang - a1) < .12) & (larg < .5)
    img[frente, :3] = 255; img[frente, 3] = 255
    # leque do golpe: um véu pontilhado entre a mão e a meia-lua + dois arcos finos de velocidade,
    # para o rastro sair da espada (as armas longas cortam longe do corpo; sem isso o corte parece solto no ar)
    perto = np.hypot(x, y)
    fim = a1 - (a1 - a0) * .1
    trilha = np.clip((ang - a0) / max(.01, fim - a0), 0, 1)
    leque = (rho < 1) & ~dentro & (x > -1) & (ang >= a0) & (ang <= fim) & (perto > 6)
    veu = leque & (np.clip(rho, 0, 1) ** 1.6 * trilha * .42 * espessura > bay)
    img[veu, :3] = escuro.astype(np.uint8); img[veu, 3] = 255
    for i, rk in enumerate((.48, .74)):
        lin = leque & (np.abs(rho - rk) < .55 / R + .006) & (trilha * 1.4 - .15 * i > bay)
        img[lin, :3] = claro.astype(np.uint8); img[lin, 3] = 255
    return img

def lamina(n, cor, W, H, mao):
    """espada apontando para a direita, com a mão (punho) em 'mao'"""
    img = np.zeros((H, W, 4), np.uint8)
    def p(x, y, c):
        if 0 <= x < W and 0 <= y < H: img[y, x, :3] = c; img[y, x, 3] = 255
    c = rgb(cor).astype(int); claro = mistura(c, np.array([255, 255, 255.]), .6).astype(int); esc = mistura(c, np.array([30, 24, 40.]), .5).astype(int)
    linha = (20, 13, 15); madeira = (110, 70, 40); metal = (200, 170, 90) if n >= 4 else (150, 150, 160)
    mx, my = mao; L = 12 + n * 2                      # comprimento da lâmina
    for x in range(mx - 3, mx + 2): p(x, my, (70, 44, 26)); p(x, my - 1, linha); p(x, my + 1, linha)   # punho
    p(mx - 4, my, metal); p(mx - 4, my - 1, linha); p(mx - 4, my + 1, linha); p(mx - 5, my, linha)       # pomo
    for y in range(my - 3, my + 4): p(mx + 2, y, metal if abs(y - my) < 3 else linha)                     # guarda
    p(mx + 1, my - 3, linha); p(mx + 1, my + 3, linha); p(mx + 3, my - 3, linha); p(mx + 3, my + 3, linha)
    for k in range(L):
        x = mx + 3 + k
        p(x, my - 1, claro); p(x, my, c if k < L - 1 else claro); p(x, my + 1, esc)
        p(x, my - 2, linha); p(x, my + 2, linha)
    p(mx + 3 + L, my, linha); p(mx + 3 + L, my - 1, linha); p(mx + 3 + L, my + 1, linha)
    p(mx + 4 + L, my, linha)
    for k in range(2, L - 2, 5): p(mx + 3 + k, my - 1, (255, 255, 255))                                 # brilho
    return img

def main():
    Rmax = ARMAS[-1][0] // 2
    W = Rmax + OMBRO_X + 3; H = 2 * 27 + 2
    folha = Image.new('RGBA', (W * len(QUADROS), H * len(ARMAS)))
    for i, (r, cor) in enumerate(ARMAS):
        R = r / 2; ry = min(26, max(17, R * .5))
        for k, jan in enumerate(QUADROS):
            folha.alpha_composite(Image.fromarray(corte(R, ry, cor, jan, jan[2], W, H), 'RGBA'), (k * W, i * H))
    folha.save(os.path.join(PASTA, 'cortes.png'), optimize=True)
    LW, LH, MAO = 38, 9, (6, 4)
    lam = Image.new('RGBA', (LW, LH * len(ARMAS)))
    for i, (r, cor) in enumerate(ARMAS):
        lam.alpha_composite(Image.fromarray(lamina(i, cor, LW, LH, MAO), 'RGBA'), (0, i * LH))
    lam.save(os.path.join(PASTA, 'laminas.png'), optimize=True)
    print('cortes: quadro %dx%d, ombro (%d,%d) | laminas: quadro %dx%d, mao %s' % (W, H, OMBRO_X, H // 2, LW, LH, MAO))

if __name__ == '__main__':
    main()
