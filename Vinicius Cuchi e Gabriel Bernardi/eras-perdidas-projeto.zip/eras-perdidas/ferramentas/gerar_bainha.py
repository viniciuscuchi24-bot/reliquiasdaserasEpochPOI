# Desenha a espada embainhada na cintura do personagem, em pixel art (uma para cada melhoria da arma).
# Gera assets/personagem/bainha.png com 7 colunas (armas 0..6) e 2 linhas:
#   linha 0 = bainha (presa no quadril, descendo para trás)
#   linha 1 = cabo da espada (saindo da bainha para a frente; some na hora do golpe, quando a espada está na mão)
# O ponto do cinto (onde a bainha encosta) fica em CINTO dentro de cada quadro.
# Uso: python3 ferramentas/gerar_bainha.py
import os, math
import numpy as np
from PIL import Image
from scipy import ndimage

AQUI = os.path.dirname(os.path.abspath(__file__))
SAIDA = os.path.join(os.path.dirname(AQUI), 'assets', 'personagem', 'bainha.png')
QW, QH = 34, 18
CINTO = (15, 5)                      # ponto do cinto dentro do quadro
ANG = math.radians(30)               # inclinação da bainha (para trás e para baixo)
LINHA = (20, 13, 15)
COURO = [(92, 52, 30), (122, 72, 40), (66, 36, 20)]          # meio, luz, sombra
# por arma: metal das peças (boca e ponteira da bainha, guarda e pomo), cor do punho, comprimento
ARMAS = [
  {'nome': 'Espada de Madeira',   'metal': [(150, 104, 60), (190, 140, 86)],  'punho': (96, 62, 34),  'L': 10},
  {'nome': 'Lâmina de Pedra',     'metal': [(150, 146, 136), (196, 192, 182)], 'punho': (90, 60, 40),  'L': 11},
  {'nome': 'Espada de Ferro',     'metal': [(128, 136, 146), (184, 192, 202)], 'punho': (70, 46, 30),  'L': 12},
  {'nome': 'Aço de Damasco',      'metal': [(96, 140, 178), (170, 210, 238)],  'punho': (60, 40, 70),  'L': 13},
  {'nome': 'Aço Temperado',       'metal': [(196, 150, 60), (248, 214, 120)],  'punho': (110, 40, 30), 'L': 14},
  {'nome': 'Liga Bessemer',       'metal': [(190, 110, 60), (250, 170, 110)],  'punho': (50, 50, 56),  'L': 15},
  {'nome': 'Liga de Duralumínio', 'metal': [(90, 180, 160), (170, 246, 220)],  'punho': (40, 56, 64),  'L': 16},
]

def segmento(px, py, a, b):
    """distância de cada pixel ao segmento a-b e posição ao longo dele (0..1)"""
    ax, ay = a; bx, by = b; dx, dy = bx - ax, by - ay; L2 = dx * dx + dy * dy
    t = np.clip(((px - ax) * dx + (py - ay) * dy) / L2, 0, 1)
    return np.hypot(px - (ax + t * dx), py - (ay + t * dy)), t

def contorno(rgb, al):
    viz = ndimage.binary_dilation(al, structure=[[0, 1, 0], [1, 1, 1], [0, 1, 0]]) & ~al
    rgb = rgb.copy(); rgb[viz] = LINHA
    return rgb, al | viz

def main():
    yy, xx = np.mgrid[0:QH, 0:QW].astype(float) + .5
    cx, cy = CINTO[0] + .5, CINTO[1] + .5
    d = (-math.cos(ANG), math.sin(ANG))        # para trás e para baixo
    n = (-d[1], d[0])                          # perpendicular (para "cima" da bainha)
    folha = Image.new('RGBA', (QW * len(ARMAS), QH * 2))
    for i, A in enumerate(ARMAS):
        m0, m1 = A['metal']; L = A['L']
        # ---- bainha: tubo de couro com boca e ponteira de metal
        ponta = (cx + d[0] * L, cy + d[1] * L)
        dist, t = segmento(xx, yy, (cx, cy), ponta)
        lado = (xx - cx) * n[0] + (yy - cy) * n[1]                       # de que lado do eixo está o pixel
        larg = 1.6 - .5 * t                                              # afina um pouco na ponta
        al = dist <= larg
        rgb = np.zeros((QH, QW, 3), np.uint8)
        rgb[al] = COURO[0]
        rgb[al & (lado < -.6)] = COURO[1]                                # luz em cima
        rgb[al & (lado > .6)] = COURO[2]                                 # sombra embaixo
        anel = lambda t0, t1: al & (t >= t0) & (t <= t1)
        for t0, t1 in [(0, 1.6 / L), (.45, .45 + 1.2 / L)]: rgb[anel(t0, t1)] = m0          # boca e uma braçadeira
        rgb[anel(1 - 2.6 / L, 1)] = m0; rgb[anel(1 - 2.6 / L, 1) & (lado < 0)] = m1         # ponteira
        rgb[anel(0, 1.6 / L) & (lado < 0)] = m1
        b_rgb, b_al = contorno(rgb, al)
        # ---- cabo: guarda atravessada, punho enrolado e pomo, saindo para a frente e para cima
        f = (-d[0], -d[1])
        g0 = (cx + f[0] * .6, cy + f[1] * .6)
        dg, _ = segmento(xx, yy, (g0[0] + n[0] * 2.1, g0[1] + n[1] * 2.1), (g0[0] - n[0] * 2.1, g0[1] - n[1] * 2.1))
        guarda = dg <= .6
        p1 = (cx + f[0] * 4.4, cy + f[1] * 4.4)
        dp, tp = segmento(xx, yy, g0, p1); punho = (dp <= .75) & ~guarda
        dpo = np.hypot(xx - (cx + f[0] * 5.3), yy - (cy + f[1] * 5.3)); pomo = dpo <= 1.05
        al2 = guarda | punho | pomo
        rgb2 = np.zeros((QH, QW, 3), np.uint8)
        rgb2[punho] = A['punho']
        faixa = punho & (((tp * 5).astype(int) % 2) == 1); rgb2[faixa] = tuple(min(255, int(c * 1.45)) for c in A['punho'])   # tiras do punho
        rgb2[guarda] = m0; rgb2[guarda & (((xx - cx) * f[0] + (yy - cy) * f[1]) < .2)] = m1
        rgb2[pomo] = m0; rgb2[pomo & (dpo < .7)] = m1
        c_rgb, c_al = contorno(rgb2, al2)
        for linha, (r, a) in enumerate([(b_rgb, b_al), (c_rgb, c_al)]):
            q = np.zeros((QH, QW, 4), np.uint8); q[a, :3] = r[a]; q[a, 3] = 255
            folha.alpha_composite(Image.fromarray(q, 'RGBA'), (i * QW, linha * QH))
    folha.save(SAIDA, optimize=True); print('ok', SAIDA, folha.size)

if __name__ == '__main__':
    main()
