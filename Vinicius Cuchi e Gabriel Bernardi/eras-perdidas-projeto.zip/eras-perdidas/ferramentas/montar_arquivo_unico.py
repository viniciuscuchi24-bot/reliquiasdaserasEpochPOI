# Monta o jogo inteiro num arquivo HTML só (scripts, imagens e sons embutidos).
# Serve para abrir no celular sem servidor: é só copiar o arquivo e abrir no navegador (Chrome, Safari...).
# Saída: ../eras-perdidas-celular.html (ao lado da pasta do projeto, para não pesar o zip do projeto).
# A música é recomprimida (mono, 32 kbps) se o ffmpeg estiver instalado, para o arquivo ficar menor.
# Uso: python3 ferramentas/montar_arquivo_unico.py [saida.html]
import os, re, sys, json, base64, shutil, subprocess, tempfile

AQUI = os.path.dirname(os.path.abspath(__file__))
RAIZ = os.path.dirname(AQUI)
SAIDA = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(RAIZ), 'eras-perdidas-celular.html')
TIPOS = {'.png': 'image/png', '.webp': 'image/webp', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif',
         '.mp3': 'audio/mpeg', '.ogg': 'audio/ogg', '.wav': 'audio/wav'}
FORA = ('assets/personagem/',)        # o personagem antigo não é usado


def musica_menor(caminho):
    if not shutil.which('ffmpeg') or os.path.getsize(caminho) < 1_500_000:
        return open(caminho, 'rb').read()
    tmp = tempfile.mktemp(suffix='.mp3')
    try:
        subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', caminho, '-ac', '1', '-ar', '22050', '-b:a', '32k', tmp], check=True)
        return open(tmp, 'rb').read()
    except Exception:
        return open(caminho, 'rb').read()
    finally:
        if os.path.exists(tmp): os.remove(tmp)


def main():
    html = open(os.path.join(RAIZ, 'index.html'), encoding='utf-8').read()
    embutido = {}
    for pasta, _, arqs in os.walk(os.path.join(RAIZ, 'assets')):
        for a in sorted(arqs):
            ext = os.path.splitext(a)[1].lower()
            if ext not in TIPOS: continue
            rel = os.path.relpath(os.path.join(pasta, a), RAIZ).replace(os.sep, '/')
            if rel.startswith(FORA): continue
            dados = musica_menor(os.path.join(pasta, a)) if ext == '.mp3' else open(os.path.join(pasta, a), 'rb').read()
            embutido[rel] = 'data:%s;base64,%s' % (TIPOS[ext], base64.b64encode(dados).decode())
    def script(m):
        cod = open(os.path.join(RAIZ, m.group(1)), encoding='utf-8').read().replace('</script', '<\\/script')
        return '<script>/* %s */\n%s\n</script>' % (m.group(1), cod)
    primeiro = html.index('<script src=')
    html = html[:primeiro] + '<script>window.EMBUTIDO=' + json.dumps(embutido) + ';</script>\n' + html[primeiro:]
    html = re.sub(r'<script src="([^"]+)"></script>', script, html)
    html = html.replace('href="creditos.html"', 'href="#" onclick="return false" title="veja creditos.html no projeto"')
    open(SAIDA, 'w', encoding='utf-8').write(html)
    print('ok', SAIDA, '%.1f MB' % (os.path.getsize(SAIDA) / 1048576), len(embutido), 'arquivos embutidos')


if __name__ == '__main__':
    main()
